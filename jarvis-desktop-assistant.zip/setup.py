from setuptools import setup, find_packages

setup(
    name="jarvis-desktop-assistant",
    version="1.0.0",
    description="Lightweight background AI voice assistant inspired by JARVIS with computer control",
    author="JARVIS Core Engineering",
    packages=find_packages(),
    install_requires=[
        "SpeechRecognition>=3.10.4",
        "pyttsx3>=2.90",
        "PyAudio>=0.2.14",
        "pyautogui>=0.9.54",
        "Pillow>=10.2.0",
        "psutil>=5.9.8",
        "pystray>=0.19.5",
        "python-dotenv>=1.0.1",
    ],
    entry_points={
        "console_scripts": [
            "jarvis=jarvis.main:main",
        ],
    },
    python_requires=">=3.10",
)
