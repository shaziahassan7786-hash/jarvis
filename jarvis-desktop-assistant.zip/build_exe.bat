@echo off
echo ===================================================
echo   JARVIS Desktop Assistant - Executable Builder
echo   Target: Windows 10 / 11 64-bit
echo ===================================================

echo [1/3] Checking virtual environment...
python --version
pip install --upgrade pyinstaller -r requirements.txt

echo [2/3] Building standalone executable with PyInstaller...
pyinstaller --noconfirm --onedir --windowed ^
    --name "JARVIS" ^
    --add-data "jarvis;jarvis" ^
    --hidden-import "pycaw" ^
    --hidden-import "comtypes" ^
    --hidden-import "pystray" ^
    --hidden-import "PIL" ^
    jarvis/main.py

echo [3/3] Build finished!
echo Output located in dist/JARVIS/JARVIS.exe
pause
