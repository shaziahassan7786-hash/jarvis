import os
import time
from datetime import datetime
from pathlib import Path
import logging
from typing import Dict, Any
from jarvis.config import SCREENSHOTS_DIR

logger = logging.getLogger("JARVIS.Tools.Screenshots")


def take_screenshot() -> Dict[str, Any]:
    """Captures the full screen and saves it to Pictures/Screenshots."""
    try:
        from PIL import ImageGrab

        SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        filename = f"Screenshot_{timestamp}.png"
        filepath = SCREENSHOTS_DIR / filename

        # Grab screenshot
        screenshot = ImageGrab.grab()
        screenshot.save(filepath, "PNG")

        logger.info(f"Saved screenshot to: {filepath}")
        return {
            "success": True,
            "output": f"Screenshot captured and saved to {filename}.",
            "filepath": str(filepath)
        }
    except ImportError:
        # Fallback to pyautogui or cross platform
        try:
            import pyautogui
            timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
            filename = f"Screenshot_{timestamp}.png"
            filepath = SCREENSHOTS_DIR / filename
            pyautogui.screenshot(str(filepath))
            return {
                "success": True,
                "output": f"Screenshot captured and saved to {filename}.",
                "filepath": str(filepath)
            }
        except Exception as e:
            return {"success": False, "output": f"Screenshot failed: {str(e)}"}
    except Exception as e:
        logger.error(f"Failed to capture screenshot: {e}")
        return {"success": False, "output": f"Failed to take screenshot: {str(e)}"}
