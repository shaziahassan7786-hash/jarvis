import logging
import time
from typing import Dict, Any, List

logger = logging.getLogger("JARVIS.Tools.Keyboard")


def type_text(text: str, interval: float = 0.02) -> Dict[str, Any]:
    """Safely types text into the currently focused window."""
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        time.sleep(0.2)  # Brief pause to allow target window to retain focus
        pyautogui.write(text, interval=interval)
        return {
            "success": True,
            "output": f"Typed '{text[:20]}...' into focused application."
        }
    except ImportError:
        return {
            "success": False,
            "output": "pyautogui package is required for keyboard typing."
        }
    except Exception as e:
        logger.error(f"Error during typing: {e}")
        return {"success": False, "output": f"Keyboard typing error: {str(e)}"}


def press_key(key: str) -> Dict[str, Any]:
    """Presses a single key (e.g., 'enter', 'esc', 'tab', 'volumeup')."""
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        clean_key = key.lower().strip()
        pyautogui.press(clean_key)
        return {"success": True, "output": f"Pressed key '{clean_key}'."}
    except Exception as e:
        return {"success": False, "output": f"Error pressing key: {str(e)}"}


def hotkey(keys: List[str]) -> Dict[str, Any]:
    """Executes a key combination (e.g., ['ctrl', 'c'], ['win', 'd'])."""
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        clean_keys = [k.lower().strip() for k in keys]
        pyautogui.hotkey(*clean_keys)
        return {"success": True, "output": f"Executed hotkey: {' + '.join(clean_keys)}."}
    except Exception as e:
        return {"success": False, "output": f"Hotkey error: {str(e)}"}
