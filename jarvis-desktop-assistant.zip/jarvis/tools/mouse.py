import logging
from typing import Dict, Any, Optional

logger = logging.getLogger("JARVIS.Tools.Mouse")


def move_mouse(x: int, y: int, duration: float = 0.3) -> Dict[str, Any]:
    """Moves the mouse cursor to screen coordinates (x, y)."""
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        pyautogui.moveTo(int(x), int(y), duration=duration)
        return {"success": True, "output": f"Moved mouse to ({x}, {y})."}
    except ImportError:
        return {"success": False, "output": "pyautogui package required for mouse movement."}
    except Exception as e:
        return {"success": False, "output": f"Mouse move error: {str(e)}"}


def click(x: Optional[int] = None, y: Optional[int] = None, button: str = "left") -> Dict[str, Any]:
    """Clicks at current or specified screen coordinates."""
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        if x is not None and y is not None:
            pyautogui.click(int(x), int(y), button=button)
            return {"success": True, "output": f"Clicked {button} at ({x}, {y})."}
        else:
            pyautogui.click(button=button)
            return {"success": True, "output": f"Clicked {button} at current position."}
    except Exception as e:
        return {"success": False, "output": f"Mouse click error: {str(e)}"}
