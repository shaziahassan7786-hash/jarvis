import os
import subprocess
import shutil
import logging
from typing import Dict, Any

logger = logging.getLogger("JARVIS.Tools.Apps")

KNOWN_WINDOWS_APPS: Dict[str, str] = {
    "notepad": "notepad.exe",
    "calc": "calc.exe",
    "calculator": "calc.exe",
    "chrome": "chrome.exe",
    "google chrome": "chrome.exe",
    "edge": "msedge.exe",
    "microsoft edge": "msedge.exe",
    "explorer": "explorer.exe",
    "file explorer": "explorer.exe",
    "cmd": "cmd.exe",
    "command prompt": "cmd.exe",
    "powershell": "powershell.exe",
    "code": "code.cmd",
    "vs code": "code.cmd",
    "vscode": "code.cmd",
    "spotify": "spotify.exe",
    "vlc": "vlc.exe",
    "word": "winword.exe",
    "excel": "excel.exe",
    "paint": "mspaint.exe",
    "task manager": "taskmgr.exe",
    "settings": "ms-settings:",
}


def open_application(app_name: str) -> Dict[str, Any]:
    """Safely launches a recognized desktop application on Windows/OS."""
    clean_name = app_name.lower().strip()
    target_exe = KNOWN_WINDOWS_APPS.get(clean_name, clean_name)

    logger.info(f"Attempting to launch application: '{clean_name}' (Target: {target_exe})")

    try:
        if os.name == "nt":
            # On Windows, use os.startfile or safe subprocess
            if target_exe.endswith(":") or target_exe.startswith("ms-"):
                os.startfile(target_exe)
            else:
                subprocess.Popen([target_exe], shell=False)
        else:
            # Cross-platform fallback for testing/dev environments
            resolved = shutil.which(target_exe) or shutil.which(clean_name)
            if resolved:
                subprocess.Popen([resolved])
            elif clean_name in ("browser", "chrome"):
                import webbrowser
                webbrowser.open("https://www.google.com")
            else:
                return {
                    "success": False,
                    "output": f"Application '{app_name}' not found in system PATH."
                }

        return {
            "success": True,
            "output": f"Successfully launched {app_name}."
        }
    except Exception as e:
        logger.error(f"Failed to launch application '{app_name}': {e}")
        return {
            "success": False,
            "output": f"Could not launch application '{app_name}': {str(e)}"
        }


def close_application(app_name: str) -> Dict[str, Any]:
    """Gracefully terminates a running application by process name."""
    clean_name = app_name.lower().strip()
    target_exe = KNOWN_WINDOWS_APPS.get(clean_name, clean_name)
    if not target_exe.endswith(".exe") and os.name == "nt":
        target_exe += ".exe"

    try:
        import psutil
        closed_count = 0
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                proc_name = proc.info['name'] or ""
                if clean_name in proc_name.lower() or target_exe.lower() == proc_name.lower():
                    proc.terminate()
                    closed_count += 1
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if closed_count > 0:
            return {"success": True, "output": f"Closed {closed_count} instance(s) of {app_name}."}
        else:
            return {"success": False, "output": f"No running instance of {app_name} found."}
    except ImportError:
        # Fallback to taskkill on Windows
        if os.name == "nt":
            subprocess.run(["taskkill", "/IM", target_exe, "/F"], capture_output=True)
            return {"success": True, "output": f"Sent termination signal to {app_name}."}
        return {"success": False, "output": "psutil library required for process termination."}
    except Exception as e:
        return {"success": False, "output": f"Error closing {app_name}: {str(e)}"}
