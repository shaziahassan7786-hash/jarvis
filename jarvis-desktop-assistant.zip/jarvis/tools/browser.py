import urllib.parse
import webbrowser
import logging
from typing import Dict, Any

logger = logging.getLogger("JARVIS.Tools.Browser")


def open_url(url: str) -> Dict[str, Any]:
    """Navigates to a specific URL in the system's default browser."""
    clean_url = url.strip()
    if not clean_url.startswith(("http://", "https://")):
        clean_url = f"https://{clean_url}"

    logger.info(f"Opening browser URL: {clean_url}")
    try:
        webbrowser.open(clean_url, new=2)
        return {
            "success": True,
            "output": f"Opened {clean_url} in default browser."
        }
    except Exception as e:
        logger.error(f"Failed to open URL '{clean_url}': {e}")
        return {
            "success": False,
            "output": f"Failed to open browser URL: {str(e)}"
        }


def search_web(query: str, engine: str = "google") -> Dict[str, Any]:
    """Performs a web search using the default or specified search engine."""
    clean_query = query.strip()
    encoded = urllib.parse.quote_plus(clean_query)

    if engine.lower() == "youtube" or "youtube" in clean_query.lower():
        # Music / YouTube search handling
        search_url = f"https://www.youtube.com/results?search_query={encoded}"
    else:
        search_url = f"https://www.google.com/search?q={encoded}"

    logger.info(f"Executing web search: '{clean_query}' -> {search_url}")
    try:
        webbrowser.open(search_url, new=2)
        return {
            "success": True,
            "output": f"Searched for '{clean_query}' on {engine.capitalize()}."
        }
    except Exception as e:
        logger.error(f"Search failed: {e}")
        return {
            "success": False,
            "output": f"Could not perform web search: {str(e)}"
        }


def browser_search_bar(query: str, target: str = "browser_address_bar") -> Dict[str, Any]:
    """
    Simulates navigating to the address/search bar (Ctrl+L),
    typing the query (e.g. 'fast client'), and pressing Enter to open it.
    If target is 'windows_search', triggers Windows search (Win+S).
    """
    clean_query = query.strip()
    logger.info(f"Navigating to search bar for: '{clean_query}'")
    try:
        import pyautogui
        import time
        pyautogui.FAILSAFE = True

        if target == "windows_search":
            pyautogui.hotkey("win", "s")
            time.sleep(0.4)
            pyautogui.write(clean_query, interval=0.03)
            time.sleep(0.3)
            pyautogui.press("enter")
            return {
                "success": True,
                "output": f"Opened Windows search, typed '{clean_query}', and launched."
            }
        else:
            # Focus browser address/search bar
            pyautogui.hotkey("ctrl", "l")
            time.sleep(0.3)
            pyautogui.write(clean_query, interval=0.03)
            time.sleep(0.2)
            pyautogui.press("enter")
            return {
                "success": True,
                "output": f"Navigated to search bar, typed '{clean_query}', and opened it."
            }
    except Exception as e:
        logger.warning(f"PyAutoGUI hotkey failed: {e}. Falling back to default browser search.")
        return search_web(clean_query, "google")

