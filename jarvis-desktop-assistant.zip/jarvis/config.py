import os
import json
import logging
from pathlib import Path
from typing import Dict, Any, List

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("JARVIS.Config")

APP_DIR = Path.home() / ".jarvis_assistant"
CONFIG_FILE = APP_DIR / "config.json"
HISTORY_FILE = APP_DIR / "command_history.json"
SCREENSHOTS_DIR = Path.home() / "Pictures" / "Screenshots"

DEFAULT_CONFIG: Dict[str, Any] = {
    "wake_word": "hey jarvis",
    "wake_word_sensitivity": 0.5,
    "ai_provider": "gemini",
    "language": "en-US",
    "conversation_mode": False,
    "voice_index": 0,
    "speech_rate": 185,
    "volume": 1.0,
    "start_with_windows": False,
    "confirm_high_risk": True,
    "allowed_applications": [
        "notepad",
        "chrome",
        "calc",
        "explorer",
        "spotify",
        "code",
        "cmd",
        "powershell",
        "edge",
        "vlc"
    ],
    "allowed_websites": [
        "https://www.google.com",
        "https://www.youtube.com",
        "https://github.com",
        "https://reddit.com",
        "https://en.wikipedia.org"
    ],
    "permissions": {
        "apps_launch": True,
        "browser_open": True,
        "system_volume": True,
        "screenshot_capture": True,
        "keyboard_type": True,
        "mouse_click": True,
        "file_search": True,
        "high_risk_actions": False
    }
}


class ConfigManager:
    """Manages application configurations with persistence and security defaults."""

    def __init__(self):
        self._ensure_directories()
        self.config: Dict[str, Any] = self._load_config()

    def _ensure_directories(self) -> None:
        APP_DIR.mkdir(parents=True, exist_ok=True)
        SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)

    def _load_config(self) -> Dict[str, Any]:
        if not CONFIG_FILE.exists():
            self._save_config_file(DEFAULT_CONFIG)
            return DEFAULT_CONFIG.copy()
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                saved = json.load(f)
                # Merge defaults for any missing keys
                merged = DEFAULT_CONFIG.copy()
                merged.update(saved)
                return merged
        except Exception as e:
            logger.error(f"Failed to read config file, restoring defaults: {e}")
            return DEFAULT_CONFIG.copy()

    def _save_config_file(self, data: Dict[str, Any]) -> None:
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)
        except Exception as e:
            logger.error(f"Failed to save config: {e}")

    def get(self, key: str, default: Any = None) -> Any:
        return self.config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self.config[key] = value
        self._save_config_file(self.config)

    def get_api_key(self) -> str:
        """Retrieve Gemini API Key from environment or config without exposing to logs."""
        return os.environ.get("GEMINI_API_KEY", self.config.get("gemini_api_key", ""))

    def is_permission_granted(self, permission_key: str) -> bool:
        return bool(self.config.get("permissions", {}).get(permission_key, False))

    def update_permissions(self, perm_dict: Dict[str, bool]) -> None:
        perms = self.config.get("permissions", {})
        perms.update(perm_dict)
        self.config["permissions"] = perms
        self._save_config_file(self.config)

    def set_start_with_windows(self, enable: bool) -> bool:
        """Configure Windows Run registry key for automatic startup."""
        try:
            import winreg
            key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
            app_name = "JARVISDesktopAssistant"
            exe_path = os.path.abspath(sys.argv[0])

            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
                if enable:
                    winreg.SetValueEx(key, app_name, 0, winreg.REG_SZ, f'"{exe_path}" --minimized')
                    logger.info("Registered JARVIS in Windows startup registry.")
                else:
                    try:
                        winreg.DeleteValue(key, app_name)
                        logger.info("Removed JARVIS from Windows startup registry.")
                    except FileNotFoundError:
                        pass
            self.set("start_with_windows", enable)
            return True
        except Exception as e:
            logger.warning(f"Could not update Windows registry (likely non-Windows host or permission limited): {e}")
            self.set("start_with_windows", enable)
            return False


config = ConfigManager()
