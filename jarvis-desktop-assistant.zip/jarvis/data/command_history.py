import json
import logging
from datetime import datetime
from typing import List, Dict, Any
from jarvis.config import HISTORY_FILE

logger = logging.getLogger("JARVIS.Data.History")


class CommandHistory:
    """Stores execution logs persistently in JSON format."""

    def __init__(self):
        self.history: List[Dict[str, Any]] = self._load()

    def _load(self) -> List[Dict[str, Any]]:
        if not HISTORY_FILE.exists():
            return []
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load command history: {e}")
            return []

    def _save(self) -> None:
        try:
            with open(HISTORY_FILE, "w", encoding="utf-8") as f:
                json.dump(self.history, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to write history: {e}")

    def add_entry(self, user_command: str, intent: str, tool: str, result: str, success: bool = True) -> Dict[str, Any]:
        entry = {
            "id": f"cmd_{len(self.history) + 1}_{int(datetime.now().timestamp())}",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "command": user_command,
            "interpreted_intent": intent,
            "tool": tool,
            "result": result,
            "status": "SUCCESS" if success else "FAILED"
        }
        self.history.append(entry)
        # Cap at last 500 records to keep storage lightweight
        if len(self.history) > 500:
            self.history = self.history[-500:]
        self._save()
        return entry

    def get_all(self) -> List[Dict[str, Any]]:
        return list(reversed(self.history))

    def clear(self) -> None:
        self.history = []
        self._save()
        logger.info("Command history cleared.")


command_history = CommandHistory()
