import sys
import time
import os
import signal
import threading
import logging
from typing import Optional

from jarvis.config import config
from jarvis.voice.wake_word import WakeWordDetector
from jarvis.voice.speech_to_text import SpeechToText
from jarvis.voice.text_to_speech import TextToSpeech
from jarvis.ai.agent import agent
from jarvis.data.command_history import command_history

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] JARVIS: %(message)s")
logger = logging.getLogger("JARVIS.Main")


class JarvisCore:
    """
    Main background orchestrator for JARVIS Desktop Assistant.
    Coordinates local wake-word listener, STT, AI routing, TTS output, and system tray.
    """

    def __init__(self):
        self.tts = TextToSpeech()
        self.stt = SpeechToText()
        self.wake_detector: Optional[WakeWordDetector] = None
        self.is_running = False
        self.mic_enabled = True
        self.voice_activation_enabled = True
        self.conversation_mode = config.get("conversation_mode", False)
        self._is_busy = False

    def start(self) -> None:
        """Launches background workers and announces readiness."""
        self.is_running = True
        logger.info("Initializing JARVIS Core Systems...")

        # Initialize wake-word detector with callback
        self.wake_detector = WakeWordDetector(on_wake_detected=self.handle_wake_word_triggered)
        if self.voice_activation_enabled and self.mic_enabled:
            self.wake_detector.start()

        # Startup greeting
        self.tts.speak("JARVIS system online and standing by.", block=False)
        print("\n" + "=" * 50)
        print("  JARVIS DESKTOP ASSISTANT ONLINE")
        print(f"  Wake word: '{config.get('wake_word', 'hey jarvis')}'")
        print("  Press [Enter] in this terminal for Push-to-Talk")
        print("  Type 'exit' to quit")
        print("=" * 50 + "\n")

    def handle_wake_word_triggered(self, attached_command: Optional[str] = None) -> None:
        """
        Callback invoked when 'Jarvis' is heard in the continuous audio stream.
        If user said 'Jarvis open Google' in one sentence, executes command immediately!
        If user said only 'Jarvis', prompts 'Yes sir?' and listens for follow-up command.
        """
        if self._is_busy or not self.mic_enabled:
            return

        self._is_busy = True
        logger.info(f"Wake word 'Jarvis' triggered. Attached command: '{attached_command}'")

        # If user gave the command in the same sentence as the wake word
        if attached_command and len(attached_command.strip()) > 1:
            try:
                self.execute_user_command(attached_command)
            finally:
                self._is_busy = False
            return

        # Otherwise prompt user and listen
        self.tts.speak("Yes sir?", block=True)

        # Temporary pause wake detector while taking command
        if self.wake_detector:
            self.wake_detector.pause()

        try:
            command_text = self.stt.listen_command(timeout=5.0, phrase_time_limit=7.0)
            if command_text:
                self.execute_user_command(command_text)

                # If conversation mode is on, keep listening until silence
                while self.conversation_mode and self.is_running:
                    follow_up = self.stt.listen_command(timeout=4.0, phrase_time_limit=6.0)
                    if follow_up:
                        self.execute_user_command(follow_up)
                    else:
                        break
            else:
                self.tts.speak("Standing by, sir.", block=False)
        finally:
            self._is_busy = False
            if self.wake_detector and self.voice_activation_enabled and self.mic_enabled:
                self.wake_detector.resume()

    def execute_user_command(self, command_text: str) -> None:
        """Processes and logs a natural language command."""
        logger.info(f"Executing: '{command_text}'")
        res = agent.process_command(command_text)

        # Log to history
        command_history.add_entry(
            user_command=command_text,
            intent=res.get("interpreted_intent", "Unknown"),
            tool=res.get("tool", "none"),
            result=res.get("output", ""),
            success=res.get("success", False)
        )

        # Voice feedback
        spoken = res.get("speech_response")
        if spoken:
            self.tts.speak(spoken, block=True)

    def trigger_push_to_talk(self) -> None:
        """Push-to-talk manual invocation."""
        if self._is_busy:
            print("JARVIS is currently busy processing another task.")
            return

        self._is_busy = True
        print("\n[PUSH-TO-TALK ACTIVE]: Speak your command now...")
        self.tts.speak("Listening.", block=True)
        try:
            cmd = self.stt.listen_command(timeout=5.0)
            if cmd:
                self.execute_user_command(cmd)
            else:
                print("No speech detected.")
        finally:
            self._is_busy = False

    def toggle_microphone(self, enabled: bool) -> None:
        self.mic_enabled = enabled
        if self.wake_detector:
            if enabled and self.voice_activation_enabled:
                self.wake_detector.resume()
            else:
                self.wake_detector.pause()
        logger.info(f"Microphone set to: {'ACTIVE' if enabled else 'MUTED'}")

    def toggle_voice_activation(self, enabled: bool) -> None:
        self.voice_activation_enabled = enabled
        if self.wake_detector:
            if enabled and self.mic_enabled:
                self.wake_detector.resume()
            else:
                self.wake_detector.pause()
        logger.info(f"Voice activation set to: {'ENABLED' if enabled else 'DISABLED'}")

    def setup_system_tray(self) -> None:
        """Creates Windows notification area system tray icon with context menu."""
        try:
            import pystray
            from PIL import Image, ImageDraw

            # Create circular cyan JARVIS arc reactor icon
            img = Image.new('RGBA', (64, 64), color=(0, 0, 0, 0))
            draw = ImageDraw.Draw(img)
            draw.ellipse((4, 4, 60, 60), outline=(0, 229, 255, 255), width=3)
            draw.ellipse((16, 16, 48, 48), outline=(0, 150, 255, 255), width=2)
            draw.ellipse((26, 26, 38, 38), fill=(0, 229, 255, 255))

            def on_toggle_voice(icon, item):
                self.toggle_voice_activation(not self.voice_activation_enabled)

            def on_toggle_mic(icon, item):
                self.toggle_microphone(not self.mic_enabled)

            def on_toggle_convo(icon, item):
                self.conversation_mode = not self.conversation_mode
                config.set("conversation_mode", self.conversation_mode)

            def on_clear_history(icon, item):
                command_history.clear()
                self.tts.speak("Command history has been cleared.", block=False)

            def on_exit(icon, item):
                icon.stop()
                self.shutdown()

            menu = pystray.Menu(
                pystray.MenuItem("Open JARVIS", lambda: print("Focusing JARVIS...")),
                pystray.MenuItem("Voice Activation", on_toggle_voice, checked=lambda item: self.voice_activation_enabled),
                pystray.MenuItem("Microphone Mute", on_toggle_mic, checked=lambda item: not self.mic_enabled),
                pystray.MenuItem("Conversation Mode", on_toggle_convo, checked=lambda item: self.conversation_mode),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Clear Command History", on_clear_history),
                pystray.MenuItem("Exit JARVIS", on_exit)
            )

            icon = pystray.Icon("JARVIS", img, "JARVIS Desktop Assistant", menu)
            threading.Thread(target=icon.run, daemon=True, name="TrayThread").start()
            logger.info("Windows System Tray icon initialized.")
        except ImportError:
            logger.info("pystray/Pillow not installed; running in CLI background mode.")
        except Exception as e:
            logger.warning(f"Could not initialize system tray: {e}")

    def shutdown(self) -> None:
        """Gracefully shuts down all threads and releases audio resources."""
        logger.info("Shutting down JARVIS...")
        self.is_running = False
        if self.wake_detector:
            self.wake_detector.stop()
        logger.info("JARVIS shut down completed.")
        sys.exit(0)


def main():
    jarvis = JarvisCore()
    jarvis.setup_system_tray()
    jarvis.start()

    # CLI event loop for Push-to-Talk and terminal controls
    def signal_handler(sig, frame):
        jarvis.shutdown()

    signal.signal(signal.SIGINT, signal_handler)

    while jarvis.is_running:
        try:
            user_input = input().strip()
            if user_input.lower() in ("exit", "quit", "q"):
                jarvis.shutdown()
                break
            elif user_input == "":
                # Enter triggers push to talk
                jarvis.trigger_push_to_talk()
            else:
                # Text input typed directly
                jarvis.execute_user_command(user_input)
        except (KeyboardInterrupt, EOFError):
            jarvis.shutdown()
            break


if __name__ == "__main__":
    main()
