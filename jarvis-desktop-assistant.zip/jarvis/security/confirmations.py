import logging
from typing import Callable, Optional
from jarvis.security.permissions import RiskLevel, security_manager
from jarvis.config import config

logger = logging.getLogger("JARVIS.Confirmations")


class ConfirmationManager:
    """Handles explicit user authorization for high-risk system operations."""

    def __init__(self):
        self._custom_prompt_callback: Optional[Callable[[str, str], bool]] = None

    def register_ui_callback(self, callback: Callable[[str, str], bool]) -> None:
        """Register a GUI modal confirmation handler."""
        self._custom_prompt_callback = callback

    def request_confirmation(self, action_name: str, description: str) -> bool:
        """
        Requests explicit confirmation if the action is HIGH RISK.
        Returns True if authorized or LOW/MEDIUM risk, False if rejected.
        """
        risk = security_manager.get_risk_level(action_name)
        if risk != RiskLevel.HIGH or not config.get("confirm_high_risk", True):
            return True

        prompt_text = f"Security Authorization Required: Are you sure you want me to execute '{action_name}' ({description})?"
        logger.warning(f"HIGH RISK PROMPT: {prompt_text}")

        # If a GUI callback is registered, use it
        if self._custom_prompt_callback:
            try:
                return self._custom_prompt_callback(action_name, description)
            except Exception as e:
                logger.error(f"Error in confirmation callback: {e}")
                return False

        # Fallback to console prompt
        try:
            print(f"\n[JARVIS SECURITY WARNING] HIGH RISK ACTION DETECTED:")
            print(f"Action: {action_name}")
            print(f"Description: {description}")
            choice = input("Are you sure you want me to do this? (yes/no): ").strip().lower()
            return choice in ("y", "yes")
        except Exception:
            return False


confirmation_manager = ConfirmationManager()
