from enum import Enum
from typing import Dict, Any, Tuple
import logging
from jarvis.config import config

logger = logging.getLogger("JARVIS.Security")


class RiskLevel(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


# Security classification map for tool actions
ACTION_RISK_MAP: Dict[str, RiskLevel] = {
    # Low Risk
    "open_application": RiskLevel.LOW,
    "close_application": RiskLevel.LOW,
    "open_url": RiskLevel.LOW,
    "search_web": RiskLevel.LOW,
    "get_system_volume": RiskLevel.LOW,
    "set_system_volume": RiskLevel.LOW,
    "mute_audio": RiskLevel.LOW,
    "unmute_audio": RiskLevel.LOW,
    "take_screenshot": RiskLevel.LOW,
    "get_current_time": RiskLevel.LOW,
    "get_system_info": RiskLevel.LOW,
    "search_files": RiskLevel.LOW,
    "open_folder": RiskLevel.LOW,

    # Medium Risk
    "type_text": RiskLevel.MEDIUM,
    "press_key": RiskLevel.MEDIUM,
    "hotkey": RiskLevel.MEDIUM,
    "move_mouse": RiskLevel.MEDIUM,
    "click": RiskLevel.MEDIUM,
    "download_file": RiskLevel.MEDIUM,

    # High Risk
    "delete_file": RiskLevel.HIGH,
    "execute_terminal_command": RiskLevel.HIGH,
    "modify_system_setting": RiskLevel.HIGH,
    "change_password": RiskLevel.HIGH,
    "send_financial_transaction": RiskLevel.HIGH,
    "upload_private_file": RiskLevel.HIGH,
}

PERMISSION_KEY_MAP: Dict[str, str] = {
    "open_application": "apps_launch",
    "close_application": "apps_launch",
    "open_url": "browser_open",
    "search_web": "browser_open",
    "open_folder": "file_search",
    "search_files": "file_search",
    "take_screenshot": "screenshot_capture",
    "get_system_volume": "system_volume",
    "set_system_volume": "system_volume",
    "mute_audio": "system_volume",
    "unmute_audio": "system_volume",
    "type_text": "keyboard_type",
    "press_key": "keyboard_type",
    "hotkey": "keyboard_type",
    "move_mouse": "mouse_click",
    "click": "mouse_click",
    "delete_file": "high_risk_actions",
    "execute_terminal_command": "high_risk_actions",
}


class SecurityManager:
    """Enforces fine-grained OS permissions and strict sandbox constraints."""

    @staticmethod
    def get_risk_level(action_name: str) -> RiskLevel:
        return ACTION_RISK_MAP.get(action_name, RiskLevel.HIGH)

    @classmethod
    def check_permission(cls, action_name: str, args: Dict[str, Any] = None) -> Tuple[bool, str]:
        """
        Validates if the specified action is allowed by user policies.
        Returns: (is_allowed, error_message_if_blocked)
        """
        risk = cls.get_risk_level(action_name)
        perm_key = PERMISSION_KEY_MAP.get(action_name)

        if perm_key and not config.is_permission_granted(perm_key):
            msg = f"I'm unable to perform that action because the '{perm_key}' permission is revoked in settings."
            logger.warning(f"Blocked action '{action_name}': {msg}")
            return False, msg

        # Validate app whitelist
        if action_name in ("open_application", "close_application") and args:
            app_name = str(args.get("app_name", "")).lower().strip()
            allowed = [a.lower() for a in config.get("allowed_applications", [])]
            if allowed and not any(a in app_name for a in allowed):
                msg = f"I'm unable to launch '{app_name}' because it is not on your allowed applications whitelist."
                logger.warning(msg)
                return False, msg

        # Validate URL whitelist / protocol
        if action_name == "open_url" and args:
            url = str(args.get("url", "")).strip()
            if not url.startswith(("http://", "https://")):
                msg = "I'm unable to open that URL because only secure web protocols (HTTP/HTTPS) are permitted."
                logger.warning(msg)
                return False, msg

        return True, ""


security_manager = SecurityManager()
