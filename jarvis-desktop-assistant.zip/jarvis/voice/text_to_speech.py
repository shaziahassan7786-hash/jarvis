import logging
import threading
from typing import Optional
from jarvis.config import config

logger = logging.getLogger("JARVIS.Voice.TTS")


class TextToSpeech:
    """
    Offline, low-resource Text-to-Speech synthesizer.
    Utilizes Microsoft SAPI5 on Windows via pyttsx3 with zero cloud latency.
    """

    def __init__(self):
        self._engine = None
        self._lock = threading.Lock()
        self._init_engine()

    def _init_engine(self) -> None:
        try:
            import pyttsx3
            self._engine = pyttsx3.init()
            # Set rate and volume
            rate = config.get("speech_rate", 185)
            volume = config.get("volume", 1.0)
            self._engine.setProperty("rate", rate)
            self._engine.setProperty("volume", volume)

            # Pick British / English voice if available for JARVIS persona
            voices = self._engine.getProperty("voices")
            if voices:
                chosen_voice = voices[0].id
                for v in voices:
                    name_lower = v.name.lower()
                    if "george" in name_lower or "david" in name_lower or "english" in name_lower:
                        chosen_voice = v.id
                        break
                self._engine.setProperty("voice", chosen_voice)
            logger.info("Local TTS engine initialized successfully.")
        except ImportError:
            logger.warning("pyttsx3 not installed; audio speech will be printed to console.")
            self._engine = None
        except Exception as e:
            logger.error(f"Failed to initialize pyttsx3: {e}")
            self._engine = None

    def speak(self, text: str, block: bool = True) -> None:
        """Speaks the response aloud."""
        if not text:
            return

        logger.info(f"JARVIS Speaking: \"{text}\"")

        def _run():
            with self._lock:
                if self._engine:
                    try:
                        self._engine.say(text)
                        self._engine.runAndWait()
                    except Exception as e:
                        logger.error(f"TTS playback error: {e}")
                else:
                    print(f"\n[JARVIS VOICE]: {text}\n")

        if block:
            _run()
        else:
            threading.Thread(target=_run, daemon=True).start()
