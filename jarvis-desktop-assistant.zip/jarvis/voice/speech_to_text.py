import logging
from typing import Optional
from jarvis.config import config

logger = logging.getLogger("JARVIS.Voice.STT")


class SpeechToText:
    """
    Handles speech-to-text conversion after wake word trigger or push-to-talk.
    Releases audio hardware immediately once speech segment is captured.
    """

    def __init__(self):
        self.language = config.get("language", "en-US")

    def listen_command(self, timeout: float = 6.0, phrase_time_limit: float = 8.0) -> Optional[str]:
        """
        Listens for a single user command through the microphone.
        Returns the transcribed text string or None if unintelligible/timed out.
        """
        try:
            import speech_recognition as sr
            recognizer = sr.Recognizer()
            recognizer.pause_threshold = 0.8
            recognizer.energy_threshold = 300

            logger.info("Listening for command...")
            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source, duration=0.3)
                audio = recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)

            logger.info("Audio captured, transcribing speech...")
            try:
                # Primary transcription
                text = recognizer.recognize_google(audio, language=self.language)
                logger.info(f"Transcribed command: '{text}'")
                return text
            except sr.UnknownValueError:
                logger.info("Speech was unintelligible.")
                return None
            except sr.RequestError as e:
                logger.error(f"Speech service error: {e}")
                return None

        except ImportError:
            logger.error("speech_recognition library not installed.")
            return None
        except Exception as e:
            logger.error(f"Error during command capture: {e}")
            return None
