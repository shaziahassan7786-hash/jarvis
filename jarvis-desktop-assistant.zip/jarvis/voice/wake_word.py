import time
import threading
import logging
import re
from typing import Callable, Optional
from jarvis.config import config

logger = logging.getLogger("JARVIS.Voice.WakeWord")


class WakeWordDetector:
    """
    Lightweight, continuous background listener.
    Listens to ambient microphone audio, but ONLY triggers action when 'Jarvis'
    is spoken. If followed by a command in the same phrase (e.g. 'Jarvis open Google'),
    it extracts and dispatches the command immediately with zero delay.
    """

    def __init__(self, on_wake_detected: Callable[[Optional[str]], None]):
        self.on_wake_detected = on_wake_detected
        self.is_running = False
        self.is_paused = False
        self._thread: Optional[threading.Thread] = None
        self.wake_phrase = config.get("wake_word", "jarvis").lower()

    def start(self) -> None:
        """Starts the low-resource background listening thread."""
        if self.is_running:
            return
        self.is_running = True
        self.is_paused = False
        self._thread = threading.Thread(target=self._listen_loop, daemon=True, name="WakeWordListener")
        self._thread.start()
        logger.info(f"Continuous background listener active. Wake phrase: '{self.wake_phrase}'")

    def stop(self) -> None:
        """Stops the engine and cleanly releases microphone hardware."""
        self.is_running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)
        logger.info("Wake word engine stopped. Microphone hardware released.")

    def pause(self) -> None:
        self.is_paused = True
        logger.info("Wake word detector paused.")

    def resume(self) -> None:
        self.is_paused = False
        logger.info("Wake word detector resumed.")

    def _listen_loop(self) -> None:
        """
        Continuous background listening loop.
        Processes audio locally and triggers strictly when 'Jarvis' is mentioned.
        """
        try:
            import speech_recognition as sr
            recognizer = sr.Recognizer()
            recognizer.energy_threshold = 280
            recognizer.dynamic_energy_threshold = True

            with sr.Microphone() as source:
                recognizer.adjust_for_ambient_noise(source, duration=0.6)
                logger.info("Continuous microphone listening active for wake word 'Jarvis'...")

                while self.is_running:
                    if self.is_paused:
                        time.sleep(0.2)
                        continue

                    try:
                        # Listen in short continuous chunks
                        audio = recognizer.listen(source, timeout=1.8, phrase_time_limit=4.0)
                        if not self.is_running or self.is_paused:
                            continue

                        try:
                            # Transcribe incoming phrase
                            text = recognizer.recognize_google(audio).lower().strip()

                            # Only trigger when wake word "jarvis" is explicitly present
                            if "jarvis" in text:
                                # Extract any trailing command in the same phrase
                                parts = re.split(r"\bjarvis\b", text, maxsplit=1)
                                command_part = parts[1].strip() if len(parts) > 1 else ""
                                command_part = re.sub(r"^[,.\s]+", "", command_part)
                                logger.info(f"Wake word 'Jarvis' detected! Attached command: '{command_part}'")
                                self.on_wake_detected(command_part if command_part else None)
                        except sr.UnknownValueError:
                            pass
                        except sr.RequestError:
                            time.sleep(0.5)

                    except sr.WaitTimeoutError:
                        continue
                    except Exception as e:
                        time.sleep(0.2)

        except ImportError:
            logger.error("speech_recognition library not installed; running wake word in simulated standby mode.")
            while self.is_running:
                time.sleep(0.5)
        except Exception as e:
            logger.error(f"Failed to initialize microphone for continuous listening: {e}")

            while self.is_running:
                time.sleep(1.0)
