"""
JARVIS Desktop Assistant
A fast, low-resource voice assistant for Windows 10/11 with local wake-word detection,
secure tool routing, and lightweight desktop control.
"""

__version__ = "1.0.0"
__author__ = "JARVIS Core Engineering"
