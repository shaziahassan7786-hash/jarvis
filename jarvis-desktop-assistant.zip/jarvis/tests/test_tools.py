import unittest
import os
from jarvis.ai.tool_router import ToolRouter
from jarvis.security.permissions import security_manager, RiskLevel
from jarvis.tools import system, browser, applications


class TestJarvisTools(unittest.TestCase):
    """Test suite verifying tool execution, intent matching, and security constraints."""

    def test_local_intent_matching(self):
        # YouTube
        match = ToolRouter.match_local_intent("Hey Jarvis, open YouTube")
        self.assertIsNotNone(match)
        tool, args, spoken = match
        self.assertEqual(tool, "open_url")
        self.assertEqual(args.get("url"), "https://www.youtube.com")

        # Calculator
        match = ToolRouter.match_local_intent("Can you open calculator?")
        self.assertIsNotNone(match)
        tool, args, _ = match
        self.assertEqual(tool, "open_application")
        self.assertEqual(args.get("app_name"), "calculator")

        # Time
        match = ToolRouter.match_local_intent("Hey Jarvis, what time is it?")
        self.assertIsNotNone(match)
        tool, _, _ = match
        self.assertEqual(tool, "get_current_time")

        # Screenshot
        match = ToolRouter.match_local_intent("Jarvis, take a screenshot")
        self.assertIsNotNone(match)
        tool, _, _ = match
        self.assertEqual(tool, "take_screenshot")

        # Volume
        match = ToolRouter.match_local_intent("mute the computer")
        self.assertIsNotNone(match)
        tool, _, _ = match
        self.assertEqual(tool, "mute_audio")

    def test_system_time_tool(self):
        res = system.get_current_time()
        self.assertTrue(res["success"])
        self.assertIn("The current time is", res["output"])

    def test_system_info_tool(self):
        res = system.get_system_info()
        self.assertTrue(res["success"])
        self.assertIn("cpu_usage_percent", res["data"])
        self.assertIn("ram_percent", res["data"])

    def test_security_risk_levels(self):
        self.assertEqual(security_manager.get_risk_level("open_application"), RiskLevel.LOW)
        self.assertEqual(security_manager.get_risk_level("open_url"), RiskLevel.LOW)
        self.assertEqual(security_manager.get_risk_level("take_screenshot"), RiskLevel.LOW)
        self.assertEqual(security_manager.get_risk_level("type_text"), RiskLevel.MEDIUM)
        self.assertEqual(security_manager.get_risk_level("delete_file"), RiskLevel.HIGH)

    def test_security_url_validation(self):
        # Valid URL
        ok, _ = security_manager.check_permission("open_url", {"url": "https://www.google.com"})
        self.assertTrue(ok)

        # Invalid protocol blocked
        ok, msg = security_manager.check_permission("open_url", {"url": "javascript:alert(1)"})
        self.assertFalse(ok)
        self.assertIn("only secure web protocols", msg)


if __name__ == "__main__":
    unittest.main()
