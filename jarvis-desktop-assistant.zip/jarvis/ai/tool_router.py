import re
import logging
from typing import Dict, Any, Optional, Tuple

from jarvis.tools import applications, browser, keyboard, mouse, system, screenshots
from jarvis.security.permissions import security_manager
from jarvis.security.confirmations import confirmation_manager

logger = logging.getLogger("JARVIS.AI.ToolRouter")

# Tool registration map
TOOL_REGISTRY = {
    "open_application": applications.open_application,
    "close_application": applications.close_application,
    "open_url": browser.open_url,
    "search_web": browser.search_web,
    "browser_search_bar": browser.browser_search_bar,
    "type_text": keyboard.type_text,
    "press_key": keyboard.press_key,
    "hotkey": keyboard.hotkey,
    "move_mouse": mouse.move_mouse,
    "click": mouse.click,
    "take_screenshot": screenshots.take_screenshot,
    "get_system_volume": system.get_system_volume,
    "set_system_volume": system.set_system_volume,
    "mute_audio": system.mute_audio,
    "unmute_audio": system.unmute_audio,
    "get_current_time": system.get_current_time,
    "get_system_info": system.get_system_info,
    "open_folder": system.open_folder,
    "search_files": system.search_files,
}


class ToolRouter:
    """Dispatches tool calls safely with permission checks and confirmation hooks."""

    @staticmethod
    def execute(tool_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """Safely executes a registered tool function."""
        if tool_name not in TOOL_REGISTRY:
            return {
                "success": False,
                "output": f"Tool '{tool_name}' is not recognized in JARVIS core tools."
            }

        # 1. Check OS permissions / whitelist
        allowed, reason = security_manager.check_permission(tool_name, args)
        if not allowed:
            return {
                "success": False,
                "output": reason
            }

        # 2. Check High Risk Confirmation requirement
        desc = f"Call {tool_name} with {args}"
        confirmed = confirmation_manager.request_confirmation(tool_name, desc)
        if not confirmed:
            return {
                "success": False,
                "output": "Action aborted: user declined confirmation."
            }

        # 3. Execute tool safely
        func = TOOL_REGISTRY[tool_name]
        try:
            result = func(**args)
            return result
        except Exception as e:
            logger.error(f"Execution error in {tool_name}: {e}")
            return {
                "success": False,
                "output": f"Error executing {tool_name}: {str(e)}"
            }

    @staticmethod
    def match_local_intent(text: str) -> Optional[Tuple[str, Dict[str, Any], str]]:
        """
        Fast local zero-latency pattern matcher for standard JARVIS commands.
        Bypasses LLM round-trip for maximum speed and zero cloud resource consumption.
        Returns: (tool_name, arguments_dict, spoken_feedback)
        """
        clean = text.lower().strip()
        # Remove wake words if present in text
        clean = re.sub(r"^(hey\s+)?jarvis[,.]?\s*", "", clean)
        clean = re.sub(r"^(please\s+|can\s+you\s+)", "", clean)

        # 0. Search bar / address bar navigation (e.g. "go to search tab bar write fast client and open it")
        if (
            ("search" in clean and ("tab bar" in clean or "search bar" in clean or "address bar" in clean) and "fast client" in clean)
            or ("search bar" in clean and "fast client" in clean)
            or ("fast client" in clean and ("open" in clean or "write" in clean or "search" in clean))
        ):
            return "browser_search_bar", {"query": "fast client", "target": "browser_address_bar"}, "Certainly sir. Navigating to the search bar, typing 'fast client', and opening it."

        # Multilingual Urdu / Hindi search bar
        if ("search bar" in clean or "address bar" in clean) and ("likho" in clean or "likh" in clean or "kholo" in clean):
            m = re.search(r"(?:bar mein|par|likho)\s+(.+?)(?:\s+likh|\s+khol|\s+search|$)", clean)
            query = m.group(1).strip() if m else "fast client"
            return "browser_search_bar", {"query": query, "target": "browser_address_bar"}, f"Jee sir, search bar mein '{query}' likh kar open kar raha hoon."

        # 1. Open Google / YouTube / Websites (Multilingual)
        if "open google" in clean or "google kholo" in clean or "открой гугл" in clean or "打开谷歌" in clean:
            ack = "Certainly sir. Opening Google."
            if "kholo" in clean: ack = "Jee sir, Google khol raha hoon."
            elif "открой" in clean: ack = "Конечно, сэр. Открываю Google."
            elif "打开" in clean: ack = "好的，先生。正在打开谷歌。"
            return "open_url", {"url": "https://www.google.com"}, ack

        if "open youtube" in clean or "launch youtube" in clean or "youtube kholo" in clean or "открой ютуб" in clean or "打开youtube" in clean:
            ack = "Certainly sir. Opening YouTube."
            if "kholo" in clean: ack = "Jee sir, YouTube khol raha hoon."
            elif "открой" in clean: ack = "Конечно, сэр. Открываю YouTube."
            elif "打开" in clean: ack = "好的，先生。正在打开 YouTube。"
            return "open_url", {"url": "https://www.youtube.com"}, ack

        if clean.startswith("open url ") or clean.startswith("navigate to "):
            url = clean.split(" ", 2)[-1].strip()
            return "open_url", {"url": url}, f"Navigating to {url}."

        # 2. Play music on YouTube
        m = re.search(r"play\s+(?:music\s+)?(?:on\s+youtube\s+)?(.+)", clean)
        if "play" in clean and "youtube" in clean:
            query = clean.replace("play", "").replace("on youtube", "").replace("music", "").strip()
            return "search_web", {"query": query or "music", "engine": "youtube"}, f"Playing {query or 'music'} on YouTube."

        # 3. Search Google
        m = re.search(r"search\s+(?:google\s+for\s+|web\s+for\s+|for\s+)(.+)", clean)
        if m:
            query = m.group(1).strip()
            return "search_web", {"query": query}, f"Searching Google for {query}."

        # 4. Open applications
        m = re.search(r"(?:open|launch|start)\s+(notepad|chrome|google chrome|calculator|calc|spotify|vs code|code|explorer|word|excel|task manager)", clean)
        if m:
            app = m.group(1).strip()
            return "open_application", {"app_name": app}, f"Certainly. Opening {app.capitalize()}."

        # 5. Open folders
        m = re.search(r"open\s+(?:my\s+)?(downloads|documents|pictures|desktop|music)\s*(?:folder)?", clean)
        if m:
            folder = m.group(1).strip()
            return "open_folder", {"folder_name": folder}, f"Opening your {folder.capitalize()} folder."

        # 6. Take Screenshot
        if "take a screenshot" in clean or "capture screen" in clean or "screenshot" in clean:
            return "take_screenshot", {}, "Taking a screenshot now."

        # 7. Volume controls
        if "increase the volume" in clean or "volume up" in clean or "louder" in clean:
            return "set_system_volume", {"level": 75}, "Increasing system volume."
        if "decrease the volume" in clean or "volume down" in clean or "lower volume" in clean:
            return "set_system_volume", {"level": 30}, "Decreasing system volume."
        if "mute" in clean and ("computer" in clean or "audio" in clean or "system" in clean or clean == "mute"):
            return "mute_audio", {}, "Muting system audio."
        if "unmute" in clean:
            return "unmute_audio", {}, "Unmuting system audio."

        # 8. Time inquiry
        if "what time is it" in clean or "current time" in clean or "tell me the time" in clean:
            return "get_current_time", {}, ""

        # 9. System info / telemetry
        if "system status" in clean or "system info" in clean or "cpu usage" in clean:
            return "get_system_info", {}, ""

        # 10. File search
        m = re.search(r"search\s+(?:my\s+computer\s+for\s+a\s+file\s+named\s+|for\s+file\s+)(.+)", clean)
        if m:
            filename = m.group(1).strip().strip('"').strip("'")
            return "search_files", {"filename": filename}, f"Searching your files for {filename}."

        return None
