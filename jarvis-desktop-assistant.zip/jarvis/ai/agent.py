import json
import logging
from typing import Dict, Any, Tuple, Optional
from jarvis.ai.tool_router import ToolRouter
from jarvis.config import config

logger = logging.getLogger("JARVIS.AI.Agent")

TOOL_SCHEMAS = [
    {
        "name": "open_application",
        "description": "Launch a desktop application by name (e.g. 'notepad', 'chrome', 'calc', 'spotify')",
        "parameters": {
            "type": "object",
            "properties": {
                "app_name": {"type": "string", "description": "The name of the desktop application"}
            },
            "required": ["app_name"]
        }
    },
    {
        "name": "close_application",
        "description": "Close a running application",
        "parameters": {
            "type": "object",
            "properties": {
                "app_name": {"type": "string", "description": "The name of the application to close"}
            },
            "required": ["app_name"]
        }
    },
    {
        "name": "open_url",
        "description": "Open a website URL in the default browser",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "The full website URL to navigate to"}
            },
            "required": ["url"]
        }
    },
    {
        "name": "search_web",
        "description": "Search the web on Google or YouTube",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search search terms"},
                "engine": {"type": "string", "enum": ["google", "youtube"], "description": "Search engine to use"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "take_screenshot",
        "description": "Take a screenshot and save it to the user's Pictures/Screenshots directory",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "set_system_volume",
        "description": "Set computer system volume level from 0 to 100",
        "parameters": {
            "type": "object",
            "properties": {
                "level": {"type": "integer", "description": "Volume percentage from 0 to 100"}
            },
            "required": ["level"]
        }
    },
    {
        "name": "mute_audio",
        "description": "Mute computer system audio",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "unmute_audio",
        "description": "Unmute computer system audio",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "get_current_time",
        "description": "Get the current time and date",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "get_system_info",
        "description": "Read CPU usage, RAM stats, and operating system information",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "open_folder",
        "description": "Open user folder like Downloads, Documents, Pictures, or Desktop",
        "parameters": {
            "type": "object",
            "properties": {
                "folder_name": {"type": "string", "description": "Name of the folder"}
            },
            "required": ["folder_name"]
        }
    },
    {
        "name": "search_files",
        "description": "Search user computer files for a specific filename",
        "parameters": {
            "type": "object",
            "properties": {
                "filename": {"type": "string", "description": "Name of the file to search"}
            },
            "required": ["filename"]
        }
    },
    {
        "name": "type_text",
        "description": "Type text into the currently active window",
        "parameters": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Text to type"}
            },
            "required": ["text"]
        }
    }
]


class JarvisAgent:
    """Interprets natural language commands into safe tool executions using Gemini AI or fast local patterns."""

    def __init__(self):
        self.api_key = config.get_api_key()

    def process_command(self, user_command: str) -> Dict[str, Any]:
        """
        Main reasoning entry point:
        1. Checks fast local pattern matching (instant, 0 ms latency, no cloud needed)
        2. If unmatched, queries Gemini with structured function calling
        3. Executes tool and returns speech response + details
        """
        clean_text = user_command.strip()
        logger.info(f"Processing command: '{clean_text}'")

        # Step 1: Fast local match
        local_match = ToolRouter.match_local_intent(clean_text)
        if local_match:
            tool_name, tool_args, voice_ack = local_match
            logger.info(f"Local intent matched: {tool_name}({tool_args})")
            exec_res = ToolRouter.execute(tool_name, tool_args)

            speech = voice_ack or exec_res.get("output", "Action completed.")
            return {
                "command": user_command,
                "tool": tool_name,
                "args": tool_args,
                "interpreted_intent": f"Call {tool_name}",
                "success": exec_res.get("success", True),
                "output": exec_res.get("output", ""),
                "speech_response": speech
            }

        # Step 2: Try Gemini API if key is present
        api_key = config.get_api_key()
        if api_key:
            try:
                from google import genai
                from google.genai import types

                client = genai.Client(api_key=api_key)
                system_prompt = (
                    "You are JARVIS, a highly competent, refined British desktop AI voice assistant. "
                    "Analyze the user's spoken request and decide which computer control tool to call. "
                    "Always call the appropriate function if a tool exists. "
                    "Never run arbitrary shell commands. Be concise and polite."
                )

                # Call Gemini with tools
                response = client.models.generate_content(
                    model="gemini-3.8-flash",
                    contents=clean_text,
                    config=types.GenerateContentConfig(
                        system_instruction=system_prompt,
                        tools=[{"function_declarations": TOOL_SCHEMAS}]
                    )
                )

                if response.function_calls:
                    fc = response.function_calls[0]
                    tool_name = fc.name
                    tool_args = fc.args or {}
                    logger.info(f"Gemini selected tool: {tool_name} with args {tool_args}")

                    exec_res = ToolRouter.execute(tool_name, tool_args)
                    speech = "Certainly sir. " + exec_res.get("output", "")
                    return {
                        "command": user_command,
                        "tool": tool_name,
                        "args": tool_args,
                        "interpreted_intent": f"Gemini called {tool_name}",
                        "success": exec_res.get("success", True),
                        "output": exec_res.get("output", ""),
                        "speech_response": speech
                    }
                else:
                    text_response = response.text or "I heard you, sir, but I could not find a suitable tool for that command."
                    return {
                        "command": user_command,
                        "tool": "none",
                        "args": {},
                        "interpreted_intent": "General conversational query",
                        "success": True,
                        "output": text_response,
                        "speech_response": text_response
                    }
            except Exception as e:
                logger.error(f"Gemini API processing failed: {e}")

        # Step 3: Polite fallback
        fallback_msg = "I'm sorry sir, I could not identify a valid computer command for that request."
        return {
            "command": user_command,
            "tool": "unknown",
            "args": {},
            "interpreted_intent": "Unrecognized request",
            "success": False,
            "output": fallback_msg,
            "speech_response": fallback_msg
        }


agent = JarvisAgent()
