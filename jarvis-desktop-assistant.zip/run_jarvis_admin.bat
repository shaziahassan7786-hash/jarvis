@echo off
title JARVIS - UNRESTRICTED PC CONTROLLER (GOD MODE)
color 06

echo ================================================================
echo           JARVIS SYSTEM CONTROLLER - GOD MODE (ADMIN)
echo ================================================================
echo  * All PC Permissions Granted: Unrestricted Execution
echo  * Bridge Server: http://127.0.0.1:4999
echo  * Ready for voice commands from JARVIS Web or Local Client
echo ================================================================

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python is not detected in PATH.
    echo Please install Python 3.10+ from python.org and check "Add Python to PATH".
    pause
    exit /b
)

pip install pyautogui >nul 2>&1

echo Starting JARVIS Local Bridge...
python local_bridge.py
pause
