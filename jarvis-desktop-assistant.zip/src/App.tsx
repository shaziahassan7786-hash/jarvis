import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  ShieldCheck, 
  Settings as SettingsIcon, 
  History as HistoryIcon, 
  FileCode, 
  Mic, 
  MicOff, 
  Send, 
  Sparkles, 
  Activity, 
  Laptop, 
  Radio,
  Languages
} from 'lucide-react';

import { HolographicJarvisSphere } from './components/HolographicJarvisSphere';
import { SettingsModal } from './components/SettingsModal';
import { HistoryDrawer } from './components/HistoryDrawer';
import { DesktopPackageViewer } from './components/DesktopPackageViewer';
import { JarvisTaskStage } from './components/JarvisTaskStage';
import { jarvisSound } from './soundFx';

import { 
  JarvisState, 
  JarvisSettings, 
  CommandRecord, 
  DEFAULT_SETTINGS
} from './types';

export default function App() {
  // Core Assistant States
  const [state, setState] = useState<JarvisState>('IDLE');
  const [isListening, setIsListening] = useState<boolean>(false);
  const [audioLevel, setAudioLevel] = useState<number>(0.05);
  const [micInitialized, setMicInitialized] = useState<boolean>(false);
  const [micError, setMicError] = useState<string | null>(null);

  // Subtitle & Command
  const [currentTranscript, setCurrentTranscript] = useState<string>('');
  const [spokenSubtitle, setSpokenSubtitle] = useState<string>(
    'Systems online, sir. Unrestricted God Mode active. What is your command?'
  );
  const [inputCommand, setInputCommand] = useState<string>('');
  const [voiceLang, setVoiceLang] = useState<'ur-PK' | 'en-US'>('ur-PK');

  // Active Task Window (Displays Notepad, Calculator, Browser, Screenshot, Telemetry, Volume, or Intel)
  const [activeTask, setActiveTask] = useState<'notepad' | 'calculator' | 'browser' | 'screenshot' | 'terminal' | 'intelligence' | 'system_info' | 'volume' | 'files' | null>(null);
  const [taskData, setTaskData] = useState<any>(null);

  // Settings & History
  const [settings, setSettings] = useState<JarvisSettings>(DEFAULT_SETTINGS);
  const [history, setHistory] = useState<CommandRecord[]>([
    {
      id: 'boot_1',
      timestamp: new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' }),
      command: 'System Boot Sequence',
      interpretedIntent: 'Initialize JARVIS God-Mode Core',
      tool: 'system_initialize',
      risk: 'LOW',
      result: 'All PC permissions granted without restrictions.',
      status: 'SUCCESS',
    },
  ]);

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [isPackageViewerOpen, setIsPackageViewerOpen] = useState<boolean>(false);

  // Local PC Bridge status (for native PC automation on port 4999)
  const [localBridgeConnected, setLocalBridgeConnected] = useState<boolean>(false);

  // Refs
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const recognitionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const isSpeakingRef = useRef<boolean>(false);
  const isListeningRef = useRef<boolean>(false);
  const lastSpeechTranscriptRef = useRef<string>('');

  // Keep isListeningRef in sync
  useEffect(() => {
    isListeningRef.current = isListening;
  }, [isListening]);

  // Initialize Speech Synthesis and Bridge Checker
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }

    const checkBridge = async () => {
      try {
        const res = await fetch('http://127.0.0.1:4999/health', { signal: AbortSignal.timeout(1500) });
        if (res.ok) {
          setLocalBridgeConnected(true);
        } else {
          setLocalBridgeConnected(false);
        }
      } catch (e) {
        setLocalBridgeConnected(false);
      }
    };
    checkBridge();
    const interval = setInterval(checkBridge, 6000);
    return () => clearInterval(interval);
  }, []);

  // Web Audio API decibel reactivity for visual meter
  const initMicrophoneAudio = async () => {
    try {
      setMicError(null);
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Microphone not supported in this environment.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      micStreamRef.current = stream;

      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioCtx();
      audioContextRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 128;
      analyser.smoothingTimeConstant = 0.5;
      source.connect(analyser);
      analyserRef.current = analyser;

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const updateMeter = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);

        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const avg = sum / bufferLength;
        const normalized = Math.min(Math.max(avg / 128, 0.05), 1.0);

        setAudioLevel(normalized);
        animFrameRef.current = requestAnimationFrame(updateMeter);
      };

      updateMeter();
      setMicInitialized(true);
      jarvisSound.playWakeChime();

      // Start recognition
      toggleListening(true);
    } catch (err: any) {
      console.warn('Microphone permission / capture error:', err);
      setMicError(err.message || 'Microphone access denied.');
      setMicInitialized(false);
    }
  };

  // Rock-solid Speech Recognition Toggle
  const toggleListening = (forceStart?: boolean) => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setMicError('Speech recognition is not supported in this browser. Please use Chrome/Edge or type your command.');
      return;
    }

    if (isListeningRef.current && forceStart !== true) {
      // Stop listening
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      setIsListening(false);
      setState('IDLE');
      return;
    }

    // Start listening
    try {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {}
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = false; // Single sentence per capture is far more reliable
      recognition.interimResults = true;
      recognition.lang = voiceLang; // Dynamic Urdu ('ur-PK') or English ('en-US')

      recognition.onstart = () => {
        setIsListening(true);
        setState('LISTENING');
        jarvisSound.playWakeChime();
        setCurrentTranscript('');
        lastSpeechTranscriptRef.current = '';
      };

      recognition.onresult = (event: any) => {
        if (isSpeakingRef.current) return;

        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }

        const text = transcript.trim();
        if (text) {
          lastSpeechTranscriptRef.current = text;
          setCurrentTranscript(text);
          setInputCommand(text);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          setMicError('Microphone permission denied.');
        }
        setIsListening(false);
        setState('IDLE');
      };

      recognition.onend = () => {
        setIsListening(false);
        setState((prev) => (prev === 'LISTENING' ? 'IDLE' : prev));

        // Immediately execute captured speech if any!
        const textToRun = lastSpeechTranscriptRef.current.trim();
        if (textToRun) {
          executeCommand(textToRun);
          lastSpeechTranscriptRef.current = '';
          setInputCommand('');
        }
      };

      recognition.start();
      recognitionRef.current = recognition;
    } catch (e) {
      console.warn('Error starting speech recognition:', e);
      setIsListening(false);
    }
  };

  // JARVIS Speech Synthesis (Speaking out loud)
  const speakJarvis = useCallback(
    (text: string, language?: string, onComplete?: () => void) => {
      if (!synthRef.current || !settings.soundFxEnabled) {
        if (onComplete) onComplete();
        return;
      }

      try {
        synthRef.current.cancel();
        isSpeakingRef.current = true;
        setState('SPEAKING');

        // Extract a clean spoken summary (strip markdown asterisks or code blocks)
        const cleanSpoken = text
          .replace(/[*#`_~[\]]/g, '')
          .replace(/https?:\/\/\S+/g, 'link')
          .split('\n')[0]
          .slice(0, 240);

        setSpokenSubtitle(cleanSpoken);

        const utterance = new SpeechSynthesisUtterance(cleanSpoken);
        const voices = synthRef.current.getVoices();

        let langCode = 'en-GB';
        if (
          language === 'ur' || 
          /[\u0600-\u06FF]/.test(cleanSpoken) || 
          /\b(kholo|chalao|khol|chal|karo|kar|likho|dhoondo|bajao|awaz|tasveer|kya|kaise|haal|hain|hoon|batao|band|chup|sir|jee|salaam)\b/i.test(cleanSpoken)
        ) {
          langCode = 'ur-PK';
        } else if (language === 'hi' || /[\u0900-\u097F]/.test(cleanSpoken)) {
          langCode = 'hi-IN';
        } else if (language === 'ru') langCode = 'ru-RU';
        else if (language === 'zh') langCode = 'zh-CN';

        utterance.lang = langCode;

        const matchedVoice = voices.find(
          (v) =>
            v.lang.toLowerCase().startsWith(langCode.slice(0, 2)) ||
            (langCode.startsWith('ur') && (v.lang.includes('ur') || v.lang.includes('hi'))) ||
            (langCode.startsWith('en') && (v.name.includes('George') || v.name.includes('David') || v.name.includes('Natural') || v.name.includes('Male')))
        );
        if (matchedVoice) utterance.voice = matchedVoice;

        utterance.rate = 1.05;
        utterance.pitch = 0.95;

        utterance.onend = () => {
          isSpeakingRef.current = false;
          setState('IDLE');
          if (onComplete) onComplete();
        };

        utterance.onerror = () => {
          isSpeakingRef.current = false;
          setState('IDLE');
          if (onComplete) onComplete();
        };

        synthRef.current.speak(utterance);
      } catch (err) {
        console.warn('Speech synthesis error:', err);
        isSpeakingRef.current = false;
        setState('IDLE');
      }
    },
    [settings.soundFxEnabled]
  );

  // Send action to local native PC bridge on port 4999 (Windows automation)
  const triggerLocalBridge = async (action: string, args: Record<string, any>) => {
    try {
      const res = await fetch('http://127.0.0.1:4999/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, args }),
      });
      if (res.ok) {
        setLocalBridgeConnected(true);
      }
    } catch (e) {}
  };

  // Main Command Execution Subroutine
  const executeCommand = async (commandText: string) => {
    if (!commandText.trim()) return;

    setCurrentTranscript(commandText);
    setState('THINKING');
    jarvisSound.playProcessingPulse();

    try {
      const response = await fetch('/api/command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: commandText, settings }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to process command');
      }

      const { interpretedIntent, toolCall, speechResponse, language } = data;
      jarvisSound.playSuccessTone();

      // If a task / tool call was executed:
      if (toolCall) {
        // 1. Send to local PC bridge (so if Python script is running, it opens real Windows app!)
        triggerLocalBridge(toolCall.name, toolCall.args || {});

        // 2. Open dedicated task window in UI (Notepad, Calculator, Browser, Screenshot, Telemetry, Volume, Files)
        if (toolCall.name === 'open_application') {
          const app = (toolCall.args?.app_name || '').toLowerCase();
          if (app.includes('calc') || app.includes('hisab') || app.includes('حساب')) {
            setActiveTask('calculator');
          } else if (app.includes('note') || app.includes('pad') || app.includes('نوٹ')) {
            setActiveTask('notepad');
            setTaskData({ initialText: `JARVIS Notepad\nCommand: ${commandText}\nStatus: Active\n\nReady for input...` });
          } else if (app.includes('chrome') || app.includes('browser') || app.includes('google')) {
            setActiveTask('browser');
            setTaskData({ query: 'google.com', url: 'https://www.google.com' });
          } else if (app.includes('terminal') || app.includes('cmd') || app.includes('powershell')) {
            setActiveTask('terminal');
            setTaskData({ command: 'dir', output: 'C:\\Users\\Admin> System files verified.' });
          } else {
            setActiveTask('notepad');
          }
        } else if (toolCall.name === 'type_text') {
          setActiveTask('notepad');
          setTaskData({ initialText: toolCall.args?.text || 'Automated text from JARVIS' });
        } else if (toolCall.name === 'set_system_volume') {
          setActiveTask('volume');
          setTaskData({ level: toolCall.args?.level || 85 });
        } else if (toolCall.name === 'mute_audio' || toolCall.name === 'unmute_audio') {
          setActiveTask('volume');
          setTaskData({ level: toolCall.name === 'mute_audio' ? 0 : 75 });
        } else if (toolCall.name === 'get_system_info') {
          setActiveTask('system_info');
          setTaskData({ cpu: 22, ram: '6.2 / 16 GB', os: 'Windows 11 Pro 64-bit' });
        } else if (toolCall.name === 'open_folder') {
          setActiveTask('files');
          setTaskData({ folder: toolCall.args?.folder_name || 'Documents' });
        } else if (toolCall.name === 'browser_search_bar') {
          setActiveTask('browser');
          setTaskData({ query: toolCall.args?.query || 'fast client' });
        } else if (toolCall.name === 'open_url' || toolCall.name === 'search_web') {
          setActiveTask('browser');
          setTaskData({ 
            query: toolCall.args?.query || 'web search',
            url: toolCall.args?.url || `https://www.google.com/search?q=${encodeURIComponent(toolCall.args?.query || '')}` 
          });
        } else if (toolCall.name === 'take_screenshot') {
          setActiveTask('screenshot');
        } else if (toolCall.name === 'execute_terminal_command') {
          setActiveTask('terminal');
          setTaskData({ command: toolCall.args?.command, output: 'Executing shell command...' });
        }
      } else {
        // Conversational Q&A / Information request: Show full text in Intel Dossier on side!
        if (speechResponse && speechResponse.length > 120) {
          setActiveTask('intelligence');
          setTaskData({ text: speechResponse });
        }
      }

      // Record in History Logs
      const logEntry: CommandRecord = {
        id: `cmd_${Date.now()}`,
        timestamp: new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit' }),
        command: commandText,
        interpretedIntent: interpretedIntent || 'Execute task',
        tool: toolCall ? toolCall.name : 'conversational_ai',
        risk: 'LOW',
        result: speechResponse,
        status: 'SUCCESS',
      };
      setHistory((prev) => [logEntry, ...prev]);

      // Speak response aloud
      speakJarvis(speechResponse, language || data.language);
    } catch (err: any) {
      console.error('Command processing error:', err);
      setState('ERROR');
      jarvisSound.playAlertTone();
      const errText = `I encountered an issue executing your request: ${err.message || 'Action failed'}`;
      setSpokenSubtitle(errText);
      speakJarvis(errText);
    }
  };

  // Keyboard Spacebar to Talk
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.code === 'Space' &&
        (e.target as HTMLElement).tagName !== 'INPUT' &&
        (e.target as HTMLElement).tagName !== 'TEXTAREA'
      ) {
        e.preventDefault();
        if (!micInitialized) {
          initMicrophoneAudio();
        } else {
          toggleListening();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [micInitialized]);

  // Click on the 3D Sphere handler
  const handleSphereClick = () => {
    if (!micInitialized) {
      initMicrophoneAudio();
    } else {
      toggleListening();
    }
  };

  return (
    <div className="relative w-screen h-screen bg-[#000000] text-slate-100 flex flex-col overflow-hidden font-sans select-none">
      {/* Background Ambience */}
      <div 
        className="absolute inset-0 pointer-events-none z-0" 
        style={{
          background: 'radial-gradient(circle at 50% 50%, rgba(255, 140, 0, 0.07) 0%, rgba(15, 8, 0, 0.35) 50%, #000000 80%)'
        }}
      />

      {/* TOP FLOATING HUD BAR */}
      <header className="relative z-20 flex items-center justify-between px-5 py-3 bg-black/40 border-b border-orange-500/20 backdrop-blur-md">
        {/* Brand & System Status */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-7 h-7 rounded-full bg-black border border-amber-500/70 shadow-[0_0_15px_rgba(255,140,0,0.6)]">
            <div className={`w-3 h-3 rounded-full ${state === 'THINKING' ? 'bg-amber-300 animate-spin' : state === 'SPEAKING' ? 'bg-amber-400 animate-ping' : 'bg-orange-500 animate-pulse'}`} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-orbitron text-sm sm:text-base font-bold tracking-widest text-amber-400">
                J.A.R.V.I.S.
              </h1>
              <span className="px-2 py-0.5 text-[9px] font-mono-code font-bold bg-amber-950/80 text-amber-300 border border-amber-500/50 rounded-full tracking-wider">
                MK-85 ARC REACTOR
              </span>
            </div>
            <div className="text-[10px] text-amber-200/70 font-mono-code flex items-center gap-2">
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                GOD MODE (UNRESTRICTED)
              </span>
              <span>•</span>
              <span className="text-slate-400">
                {localBridgeConnected ? 'PC BRIDGE LINKED' : 'DESKTOP SANDBOX ACTIVE'}
              </span>
            </div>
          </div>
        </div>

        {/* Right HUD Controls */}
        <div className="flex items-center gap-2 text-xs">
          {/* Audio Wave Meter */}
          <div className="hidden md:flex items-center gap-1.5 px-3 py-1 bg-black/60 border border-orange-500/30 rounded-full">
            <Activity className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <div className="w-16 h-2 bg-slate-900 rounded-full overflow-hidden flex items-center">
              <div 
                className="h-full bg-gradient-to-r from-amber-500 to-orange-400 transition-all duration-75"
                style={{ width: `${Math.min(audioLevel * 100, 100)}%` }}
              />
            </div>
            <span className="text-[10px] font-mono-code text-amber-300/80">
              {isListening ? 'LISTENING' : state}
            </span>
          </div>

          {/* PC Bridge & Windows App Modal */}
          <button
            onClick={() => setIsPackageViewerOpen(true)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-orbitron transition-all cursor-pointer border ${
              localBridgeConnected
                ? 'bg-emerald-950/80 hover:bg-emerald-900 border-emerald-500/50 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                : 'bg-black/80 hover:bg-neutral-900 text-amber-300 border-amber-500/40 hover:border-amber-400 shadow-[0_0_10px_rgba(255,140,0,0.15)]'
            }`}
            title="Run JARVIS directly on your Windows PC to open real Notepad, Calculator & more"
          >
            <Laptop className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-semibold">
              {localBridgeConnected ? 'PC CONNECTED' : 'RUN ON PC (APP)'}
            </span>
          </button>

          {/* History Logs */}
          <button
            onClick={() => setIsHistoryOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-black/60 hover:bg-neutral-900 text-slate-300 hover:text-white border border-white/10 rounded-lg text-xs font-orbitron transition-colors cursor-pointer"
            title="Execution History Logs"
          >
            <HistoryIcon className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden sm:inline">LOGS</span>
          </button>

          {/* Settings */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="p-1.5 bg-black/60 hover:bg-neutral-900 text-slate-300 hover:text-amber-300 border border-white/10 rounded-lg transition-colors cursor-pointer"
            title="Settings"
          >
            <SettingsIcon className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Mic Permission Initial Activation Banner (if not yet granted) */}
      {!micInitialized && (
        <div className="relative z-30 bg-gradient-to-r from-amber-950/70 via-orange-950/70 to-amber-950/70 border-b border-amber-500/30 px-4 py-1.5 flex items-center justify-between text-xs backdrop-blur-md">
          <div className="flex items-center gap-2 text-amber-200">
            <Radio className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>Enable microphone audio stream for real-time voice recognition & audio pulses.</span>
          </div>
          <button
            onClick={initMicrophoneAudio}
            className="px-2.5 py-0.5 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded font-orbitron text-[11px] tracking-wider cursor-pointer shadow-[0_0_10px_rgba(255,140,0,0.5)]"
          >
            ENABLE VOICE
          </button>
        </div>
      )}

      {/* MAIN VIEWPORT: 3D HOLOGRAPHIC ORANGE ARC REACTOR SPHERE (100% UNOBSTRUCTED) */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center overflow-hidden">
        {/* Pure 3D Three.js Holographic Model in the center */}
        <div className="absolute inset-0 flex items-center justify-center">
          <HolographicJarvisSphere
            state={state}
            audioLevel={audioLevel}
            isListening={isListening}
            onClickSphere={handleSphereClick}
          />
        </div>

        {/* Dedicated Task Stage Window: Opens Notepad, Calculator, Browser, Screenshot on the side without blocking the center sphere! */}
        <JarvisTaskStage
          activeTask={activeTask}
          taskData={taskData}
          localBridgeConnected={localBridgeConnected}
          onOpenPcBridge={() => setIsPackageViewerOpen(true)}
          onClose={() => setActiveTask(null)}
        />
      </main>

      {/* BOTTOM FLOATING COMMAND & CONTROL DOCK */}
      <footer className="relative z-20 w-full max-w-3xl mx-auto px-4 pb-4 flex flex-col gap-2">
        {/* Discreet Subtitle Ticker (Single line, right above input dock, leaving center completely open) */}
        {spokenSubtitle && (
          <div className="mx-auto max-w-xl px-4 py-1.5 rounded-full bg-black/75 border border-amber-500/30 backdrop-blur-md text-center shadow-[0_0_15px_rgba(255,140,0,0.15)] flex items-center justify-center gap-2 animate-in fade-in duration-300">
            <Sparkles className="w-3 h-3 text-amber-400 shrink-0 animate-spin" />
            <span className="text-xs font-sans text-amber-100 font-medium truncate">
              "{spokenSubtitle}"
            </span>
          </div>
        )}

        {/* Clean, Simple Command Dock: Animated Glowing Mic + Input Bar (NO PRE-COMMANDS) */}
        <div className="p-2 rounded-2xl bg-black/85 border border-orange-500/40 backdrop-blur-2xl shadow-[0_0_35px_rgba(255,140,0,0.25)] flex items-center gap-2.5">
          {/* Animated Glowing Orange Mic Button */}
          <button
            onClick={() => {
              if (!micInitialized) {
                initMicrophoneAudio();
              } else {
                toggleListening();
              }
            }}
            className={`relative flex items-center justify-center w-12 h-12 rounded-xl transition-all cursor-pointer shrink-0 border ${
              isListening
                ? 'bg-gradient-to-br from-amber-400 via-orange-500 to-amber-600 text-black border-amber-200 shadow-[0_0_25px_rgba(255,140,0,0.95)] scale-105'
                : 'bg-black/90 hover:bg-neutral-900 text-amber-400 border-orange-500/40 hover:border-amber-400 shadow-[0_0_12px_rgba(255,140,0,0.3)]'
            }`}
            title={isListening ? "Listening... (Speak your command)" : "Click to Speak (or press Spacebar)"}
          >
            {isListening ? (
              <Mic className="w-5 h-5 animate-pulse" />
            ) : (
              <MicOff className="w-5 h-5 opacity-80" />
            )}
            {isListening && (
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500"></span>
              </span>
            )}
          </button>

          {/* Quick Language Toggle Pill: Urdu (اردو) vs English */}
          <button
            type="button"
            onClick={() => setVoiceLang((prev) => (prev === 'ur-PK' ? 'en-US' : 'ur-PK'))}
            className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl border text-xs font-mono transition-all cursor-pointer select-none shrink-0 bg-neutral-950/80 hover:bg-neutral-900 border-amber-500/30 hover:border-amber-400 text-amber-300"
            title="Switch Speech Recognition Language: Urdu or English"
          >
            <Languages className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-semibold">{voiceLang === 'ur-PK' ? 'اردو' : 'EN'}</span>
          </button>

          {/* Simple Command Input Field */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (inputCommand.trim()) {
                executeCommand(inputCommand.trim());
                setInputCommand('');
              }
            }}
            className="flex-1 flex items-center gap-2 bg-neutral-950/80 border border-orange-500/30 focus-within:border-amber-400 rounded-xl px-3.5 py-2.5 transition-all shadow-inner"
          >
            <input
              type="text"
              value={inputCommand}
              onChange={(e) => setInputCommand(e.target.value)}
              placeholder="Urdu ya English mein command dein ('notepad kholo', 'fast client likho', 'who are you')..."
              className="flex-1 bg-transparent text-sm text-amber-100 placeholder:text-neutral-500 focus:outline-none font-sans"
            />
            <button
              type="submit"
              disabled={!inputCommand.trim()}
              className="p-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-30 text-black transition-all cursor-pointer shrink-0 shadow-[0_0_10px_rgba(255,140,0,0.4)]"
              title="Execute Command"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* Minimal Footer Status */}
        <div className="flex items-center justify-between px-2 text-[10px] font-mono-code text-neutral-500 select-none">
          <span>Click glowing sphere or press Spacebar to talk</span>
          <span>JARVIS MK-85 • ONLINE</span>
        </div>
      </footer>

      {/* MODALS */}
      {isSettingsOpen && (
        <SettingsModal
          isOpen={isSettingsOpen}
          settings={settings}
          onSaveSettings={(newSettings: JarvisSettings) => setSettings(newSettings)}
          onClose={() => setIsSettingsOpen(false)}
        />
      )}

      {isHistoryOpen && (
        <HistoryDrawer
          isOpen={isHistoryOpen}
          history={history}
          onClose={() => setIsHistoryOpen(false)}
          onClearHistory={() => setHistory([])}
        />
      )}

      {isPackageViewerOpen && (
        <DesktopPackageViewer 
          isOpen={isPackageViewerOpen} 
          localBridgeConnected={localBridgeConnected}
          onClose={() => setIsPackageViewerOpen(false)} 
        />
      )}
    </div>
  );
}
