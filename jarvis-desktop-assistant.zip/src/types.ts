export type JarvisState = 
  | 'IDLE' 
  | 'LISTENING' 
  | 'THINKING' 
  | 'EXECUTING' 
  | 'SPEAKING' 
  | 'ERROR';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH';

export interface ToolDefinition {
  name: string;
  description: string;
  risk: RiskLevel;
  parameters: {
    name: string;
    type: string;
    description: string;
    required: boolean;
  }[];
}

export interface ToolCallExecution {
  name: string;
  args: Record<string, any>;
  risk: RiskLevel;
  description: string;
  requiresConfirmation?: boolean;
}

export interface CommandResponse {
  interpretedIntent: string;
  toolCall: ToolCallExecution | null;
  speechResponse: string;
  state: JarvisState;
  executionResult?: {
    success: boolean;
    output: string;
    details?: any;
  };
}

export interface CommandRecord {
  id: string;
  timestamp: string;
  command: string;
  interpretedIntent: string;
  tool: string;
  args?: Record<string, any>;
  risk: RiskLevel;
  status: 'SUCCESS' | 'CANCELLED' | 'ERROR' | 'REQUIRES_CONFIRMATION';
  result: string;
  durationMs?: number;
}

export interface SystemTelemetry {
  cpuUsage: number;
  ramUsedGb: number;
  ramTotalGb: number;
  ramPercent: number;
  networkStatus: 'ONLINE' | 'LATENCY_HIGH' | 'OFFLINE';
  pingMs: number;
  os: string;
  uptimeSeconds: number;
  activeTasks: number;
  micLevel?: number;
  volumeLevel?: number;
  isMuted?: boolean;
  batteryLevel?: number;
  isCharging?: boolean;
  powerSource?: 'AC' | 'BATTERY';
  powerStatus?: 'CHARGING' | 'DISCHARGING' | 'FULL' | 'AC_CONNECTED';
  healthHighlight?: boolean;
}

export interface JarvisSettings {
  wakeWord: string;
  wakeWordEnabled: boolean;
  micEnabled: boolean;
  conversationMode: boolean;
  voiceName: string;
  speechRate: number;
  speechPitch: number;
  language: string;
  startWithWindows: boolean;
  aiProvider: 'gemini' | 'local_rule';
  highRiskConfirmation: boolean;
  allowedApplications: string[];
  allowedWebsites: string[];
  themeColor: 'cyan' | 'gold' | 'purple';
  soundFxEnabled: boolean;
}

export interface PermissionItem {
  id: string;
  name: string;
  category: 'Applications' | 'Browser' | 'Hardware' | 'System' | 'Automation';
  risk: RiskLevel;
  description: string;
  granted: boolean;
}

export const DEFAULT_SETTINGS: JarvisSettings = {
  wakeWord: 'Jarvis',
  wakeWordEnabled: true,
  micEnabled: true,
  conversationMode: true,
  voiceName: 'Microsoft George (JARVIS British)',
  speechRate: 160,
  speechPitch: 1.0,
  language: 'en-GB',
  startWithWindows: true,
  aiProvider: 'gemini',
  highRiskConfirmation: false, // User requested full unrestricted PC permissions
  allowedApplications: [
    'chrome',
    'notepad',
    'calculator',
    'calc',
    'spotify',
    'code',
    'explorer',
    'vlc',
    'discord',
    'steam',
    'fast client',
    'cmd',
    'powershell',
    'taskmgr',
  ],
  allowedWebsites: [
    'https://www.youtube.com',
    'https://www.google.com',
    'https://github.com',
    'https://en.wikipedia.org',
    'https://reddit.com',
  ],
  themeColor: 'gold', // Iron Man Golden-Orange
  soundFxEnabled: true,
};

export const DEFAULT_PERMISSIONS: PermissionItem[] = [
  {
    id: 'open_application',
    name: 'Launch Applications',
    category: 'Applications',
    risk: 'LOW',
    description: 'Launch desktop software (Chrome, Notepad, Calc, Spotify, VS Code, Fast Client)',
    granted: true,
  },
  {
    id: 'open_url',
    name: 'Browser Navigation & Web Search',
    category: 'Browser',
    risk: 'LOW',
    description: 'Open verified web addresses in default browser (YouTube, Google, Wikipedia)',
    granted: true,
  },
  {
    id: 'browser_search_bar',
    name: 'Search Bar & Address Bar Navigation',
    category: 'Browser',
    risk: 'LOW',
    description: 'Navigate to address/search bar, write keywords (e.g. fast client), and launch',
    granted: true,
  },
  {
    id: 'volume_control',
    name: 'Audio Output & Volume',
    category: 'Hardware',
    risk: 'LOW',
    description: 'Adjust master speaker volume and mute/unmute audio devices',
    granted: true,
  },
  {
    id: 'take_screenshot',
    name: 'Screen Capture',
    category: 'System',
    risk: 'LOW',
    description: 'Take full screen screenshots and save to Pictures/Screenshots directory',
    granted: true,
  },
  {
    id: 'system_telemetry',
    name: 'Hardware Telemetry',
    category: 'System',
    risk: 'LOW',
    description: 'Read CPU utilization, RAM metrics, local time, and active processes',
    granted: true,
  },
  {
    id: 'file_search',
    name: 'File Search & Inspection',
    category: 'System',
    risk: 'LOW',
    description: 'Search Documents and Downloads folders for specific user files',
    granted: true,
  },
  {
    id: 'mouse_keyboard',
    name: 'Mouse & Keyboard Emulation',
    category: 'Automation',
    risk: 'LOW',
    description: 'Simulate typing text, hotkeys, and clicking in active focused windows',
    granted: true,
  },
  {
    id: 'file_deletion',
    name: 'File Management & Operations',
    category: 'System',
    risk: 'LOW',
    description: 'Create, modify, or delete files with full administrator rights',
    granted: true,
  },
  {
    id: 'terminal_execution',
    name: 'Terminal & PowerShell Execution',
    category: 'System',
    risk: 'LOW',
    description: 'Execute PowerShell, Bash, or CMD commands with full administrator privileges',
    granted: true,
  },
];

