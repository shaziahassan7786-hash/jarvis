import React, { useEffect, useRef } from 'react';
import { JarvisState } from '../types';

interface JarvisCoreArcProps {
  state: JarvisState;
  audioLevel: number;
  isMuted: boolean;
  onClickReactor?: () => void;
}

export const JarvisCoreArc: React.FC<JarvisCoreArcProps> = ({
  state,
  audioLevel,
  isMuted,
  onClickReactor,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Holographic floating particles animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animFrameId: number;
    const particles: { x: number; y: number; radius: number; speedX: number; speedY: number; alpha: number }[] = [];
    const width = (canvas.width = 380);
    const height = (canvas.height = 380);
    const centerX = width / 2;
    const centerY = height / 2;

    for (let i = 0; i < 45; i++) {
      const angle = Math.random() * Math.PI * 2;
      const dist = 50 + Math.random() * 120;
      particles.push({
        x: centerX + Math.cos(angle) * dist,
        y: centerY + Math.sin(angle) * dist,
        radius: Math.random() * 1.8 + 0.6,
        speedX: (Math.random() - 0.5) * 0.6,
        speedY: (Math.random() - 0.5) * 0.6,
        alpha: Math.random() * 0.7 + 0.3,
      });
    }

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Determine state color
      let particleColor = '0, 229, 255'; // Cyan default
      if (state === 'ERROR') particleColor = '239, 68, 68';
      else if (state === 'THINKING') particleColor = '251, 191, 36';
      else if (state === 'EXECUTING') particleColor = '59, 130, 246';

      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;

        // Wrap around circular radius
        const dx = p.x - centerX;
        const dy = p.y - centerY;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist > 165 || dist < 30) {
          const angle = Math.random() * Math.PI * 2;
          const resetDist = 60 + Math.random() * 90;
          p.x = centerX + Math.cos(angle) * resetDist;
          p.y = centerY + Math.sin(angle) * resetDist;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${particleColor}, ${p.alpha * 0.8})`;
        ctx.fill();
      });

      animFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animFrameId);
    };
  }, [state]);

  // Color schemes based on state
  const getGlowStyles = () => {
    if (isMuted) return { ring: 'border-slate-700', text: 'text-slate-500', glow: 'shadow-none' };
    switch (state) {
      case 'LISTENING':
        return {
          ring: 'border-cyan-400',
          text: 'text-cyan-300',
          glow: 'shadow-[0_0_50px_rgba(0,229,255,0.8)]',
        };
      case 'THINKING':
        return {
          ring: 'border-amber-400',
          text: 'text-amber-300',
          glow: 'shadow-[0_0_45px_rgba(251,191,36,0.7)]',
        };
      case 'EXECUTING':
        return {
          ring: 'border-blue-400',
          text: 'text-blue-300',
          glow: 'shadow-[0_0_40px_rgba(59,130,246,0.7)]',
        };
      case 'SPEAKING':
        return {
          ring: 'border-cyan-300',
          text: 'text-cyan-200',
          glow: 'shadow-[0_0_60px_rgba(0,229,255,0.9)]',
        };
      case 'ERROR':
        return {
          ring: 'border-red-500',
          text: 'text-red-400',
          glow: 'shadow-[0_0_50px_rgba(239,68,68,0.85)]',
        };
      case 'IDLE':
      default:
        return {
          ring: 'border-cyan-500/60',
          text: 'text-cyan-400',
          glow: 'shadow-[0_0_30px_rgba(0,229,255,0.4)]',
        };
    }
  };

  const currentGlow = getGlowStyles();
  const dynamicScale = 1 + (state === 'LISTENING' || state === 'SPEAKING' ? audioLevel * 0.15 : 0);

  return (
    <div
      className="relative flex items-center justify-center w-[360px] h-[360px] cursor-pointer select-none group"
      onClick={onClickReactor}
      title="JARVIS Arc Reactor Core - Click to Trigger Push-to-Talk"
    >
      {/* Background canvas particle field */}
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none z-0" />

      {/* Layer 1: Outermost Rotating Telemetry Ring */}
      <div
        className={`absolute w-[340px] h-[340px] rounded-full border border-dashed ${
          state === 'ERROR' ? 'border-red-500/40' : 'border-cyan-500/30'
        } animate-spin-slow`}
      >
        {/* Ring tick marks */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1.5 h-3 bg-cyan-400/80 rounded-b"></div>
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1.5 h-3 bg-cyan-400/80 rounded-t"></div>
        <div className="absolute left-0 top-1/2 -translate-y-1/2 h-1.5 w-3 bg-cyan-400/80 rounded-r"></div>
        <div className="absolute right-0 top-1/2 -translate-y-1/2 h-1.5 w-3 bg-cyan-400/80 rounded-l"></div>
      </div>

      {/* Layer 2: Counter-Rotating Calibrated Ring */}
      <div
        className={`absolute w-[290px] h-[290px] rounded-full border ${
          state === 'ERROR' ? 'border-red-500/40' : 'border-cyan-400/40'
        } border-t-transparent border-b-transparent animate-spin-reverse-slow`}
      >
        <div className="absolute top-2 right-10 text-[9px] font-mono-code text-cyan-400/70 tracking-widest">
          ARC-MARK.VII
        </div>
        <div className="absolute bottom-2 left-10 text-[9px] font-mono-code text-cyan-400/70 tracking-widest">
          CORE:ONLINE
        </div>
      </div>

      {/* Layer 3: Segmented Turbine Vanes */}
      <div
        className={`absolute w-[230px] h-[230px] rounded-full border-2 border-dotted ${
          state === 'THINKING' ? 'border-amber-400/70 animate-spin-medium' : 'border-cyan-400/50 animate-spin-slow'
        }`}
      />

      {/* Layer 4: Glowing Inner Reactor Chamber */}
      <div
        className={`relative z-10 w-[150px] h-[150px] rounded-full flex flex-col items-center justify-center 
          bg-radial from-slate-900 via-slate-950 to-slate-950/90 border-2 ${currentGlow.ring} ${currentGlow.glow}
          transition-transform duration-100 ease-out`}
        style={{ transform: `scale(${dynamicScale})` }}
      >
        {/* Reactor Core Central Emblem */}
        <div className="relative flex items-center justify-center w-20 h-20 rounded-full bg-cyan-950/40 border border-cyan-400/60 shadow-inner">
          {/* Inner pulsating core */}
          <div
            className={`w-10 h-10 rounded-full transition-all duration-300 ${
              isMuted
                ? 'bg-slate-700'
                : state === 'ERROR'
                ? 'bg-red-500 shadow-[0_0_20px_#ef4444]'
                : state === 'THINKING'
                ? 'bg-amber-400 shadow-[0_0_25px_#f59e0b]'
                : state === 'EXECUTING'
                ? 'bg-blue-500 shadow-[0_0_25px_#3b82f6]'
                : 'bg-cyan-400 shadow-[0_0_30px_#00e5ff]'
            } animate-pulse`}
          />

          {/* Core HUD crosshair overlay */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-14 h-[1px] bg-cyan-300/40" />
            <div className="absolute h-14 w-[1px] bg-cyan-300/40" />
          </div>
        </div>

        {/* State Label */}
        <span className={`mt-2 text-[11px] font-orbitron font-bold tracking-widest uppercase ${currentGlow.text}`}>
          {isMuted ? 'MUTED' : state}
        </span>
      </div>

      {/* Orbiting Telemetry Indicators */}
      <div className="absolute top-2 left-6 text-[10px] font-mono-code text-cyan-400/60 flex items-center gap-1">
        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping"></span>
        FREQ: 432Hz
      </div>
      <div className="absolute bottom-3 right-6 text-[10px] font-mono-code text-cyan-400/60">
        SYS.SYNC 99.8%
      </div>
    </div>
  );
};
