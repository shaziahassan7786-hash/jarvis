import React, { useState } from 'react';
import { History, Trash2, Search, CheckCircle, AlertTriangle, XCircle, X } from 'lucide-react';
import { CommandRecord } from '../types';

interface HistoryDrawerProps {
  isOpen: boolean;
  history: CommandRecord[];
  onClearHistory: () => void;
  onClose: () => void;
}

export const HistoryDrawer: React.FC<HistoryDrawerProps> = ({
  isOpen,
  history,
  onClearHistory,
  onClose,
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const filtered = history.filter(
    (h) =>
      h.command.toLowerCase().includes(searchTerm.toLowerCase()) ||
      h.interpretedIntent.toLowerCase().includes(searchTerm.toLowerCase()) ||
      h.tool.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-slate-900 border-l border-cyan-500/40 h-full p-5 flex flex-col shadow-[-10px_0_30px_rgba(0,229,255,0.15)]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-cyan-950/60 border border-cyan-500/30 rounded text-cyan-400">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-orbitron font-bold text-white tracking-wide">
                Command History Log
              </h2>
              <span className="text-[10px] text-cyan-400/70 font-mono-code">
                {history.length} RECORDS LOGGED
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search and Clear Header */}
        <div className="flex items-center gap-2 my-3">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search commands or tools..."
              className="w-full bg-slate-950 border border-slate-700 focus:border-cyan-400 rounded-lg pl-8 pr-3 py-1.5 text-xs text-cyan-100 placeholder-slate-500 font-mono-code focus:outline-none"
            />
          </div>
          <button
            onClick={onClearHistory}
            disabled={history.length === 0}
            className="p-2 bg-red-950/60 hover:bg-red-900 border border-red-800 text-red-300 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            title="Clear all command logs"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-1">
          {filtered.length === 0 ? (
            <div className="text-center py-16 text-slate-500 text-xs font-mono-code">
              No command entries recorded yet.
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                className="p-3 bg-slate-950/70 border border-slate-800 hover:border-cyan-500/40 rounded-lg transition-all space-y-1.5"
              >
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono-code">
                  <span>{item.timestamp}</span>
                  <span
                    className={`px-1.5 py-0.5 rounded font-bold ${
                      item.status === 'SUCCESS'
                        ? 'bg-emerald-950 text-emerald-400'
                        : item.status === 'REQUIRES_CONFIRMATION'
                        ? 'bg-amber-950 text-amber-400'
                        : 'bg-red-950 text-red-400'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>

                <div className="text-xs font-semibold text-cyan-200 font-orbitron">
                  "{item.command}"
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-300 font-mono-code">
                  <span className="text-cyan-400">Tool: {item.tool}</span>
                  <span className="text-slate-500 text-[10px]">
                    Risk: {item.risk}
                  </span>
                </div>

                <div className="text-[11px] text-slate-400 bg-slate-900/60 p-1.5 rounded border border-slate-800/80">
                  <span className="text-slate-500 block text-[9px] uppercase">Result:</span>
                  {item.result}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
