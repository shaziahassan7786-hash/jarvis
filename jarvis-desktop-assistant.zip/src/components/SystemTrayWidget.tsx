import React, { useState, useEffect, useRef } from 'react';
import { 
  Minimize2, 
  Maximize2, 
  Radio, 
  Mic, 
  MicOff, 
  MessageSquare, 
  Settings, 
  ShieldCheck, 
  History, 
  Pause, 
  Play, 
  Power, 
  ChevronUp 
} from 'lucide-react';
import { JarvisState } from '../types';

interface SystemTrayWidgetProps {
  isMinimized: boolean;
  state: JarvisState;
  micEnabled: boolean;
  wakeWordEnabled: boolean;
  conversationMode: boolean;
  onRestore: () => void;
  onToggleMinimize: () => void;
  onToggleMic: () => void;
  onToggleWakeWord: () => void;
  onToggleConversationMode: () => void;
  onOpenSettings: () => void;
  onOpenPermissions: () => void;
  onOpenHistory: () => void;
}

export const SystemTrayWidget: React.FC<SystemTrayWidgetProps> = ({
  isMinimized,
  state,
  micEnabled,
  wakeWordEnabled,
  conversationMode,
  onRestore,
  onToggleMinimize,
  onToggleMic,
  onToggleWakeWord,
  onToggleConversationMode,
  onOpenSettings,
  onOpenPermissions,
  onOpenHistory,
}) => {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);

  // Close menu on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    };
    if (menuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [menuOpen]);

  return (
    <div className="fixed bottom-3 right-4 z-40" ref={menuRef}>
      {/* Context Menu (System Tray Menu) */}
      {menuOpen && (
        <div className="absolute bottom-12 right-0 w-64 bg-slate-900/95 border border-cyan-500/50 rounded-lg shadow-[0_0_30px_rgba(0,0,0,0.8)] p-2 backdrop-blur-lg animate-in slide-in-from-bottom-2 duration-150 text-xs font-mono-code z-50">
          <div className="px-2.5 py-1.5 border-b border-slate-800 text-[10px] font-orbitron font-bold text-cyan-400 tracking-wider flex items-center justify-between">
            <span>JARVIS SYSTEM TRAY</span>
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          </div>

          <div className="py-1 space-y-0.5">
            <button
              onClick={() => {
                onRestore();
                setMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded hover:bg-cyan-950/70 hover:text-cyan-200 text-slate-200 text-left cursor-pointer"
            >
              <Maximize2 className="w-3.5 h-3.5 text-cyan-400" />
              <span>Open JARVIS</span>
            </button>

            <button
              onClick={() => onToggleWakeWord()}
              className="w-full flex items-center justify-between px-2.5 py-1.5 rounded hover:bg-cyan-950/70 text-slate-200 text-left cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <Radio className="w-3.5 h-3.5 text-cyan-400" />
                <span>Voice Activation</span>
              </span>
              <span className={`text-[10px] px-1.5 rounded ${wakeWordEnabled ? 'bg-cyan-950 text-cyan-300' : 'bg-slate-800 text-slate-500'}`}>
                {wakeWordEnabled ? 'ON' : 'OFF'}
              </span>
            </button>

            <button
              onClick={() => onToggleMic()}
              className="w-full flex items-center justify-between px-2.5 py-1.5 rounded hover:bg-cyan-950/70 text-slate-200 text-left cursor-pointer"
            >
              <span className="flex items-center gap-2">
                {micEnabled ? <Mic className="w-3.5 h-3.5 text-cyan-400" /> : <MicOff className="w-3.5 h-3.5 text-red-400" />}
                <span>Microphone</span>
              </span>
              <span className={`text-[10px] px-1.5 rounded ${micEnabled ? 'bg-cyan-950 text-cyan-300' : 'bg-red-950 text-red-300'}`}>
                {micEnabled ? 'ON' : 'MUTED'}
              </span>
            </button>

            <button
              onClick={() => onToggleConversationMode()}
              className="w-full flex items-center justify-between px-2.5 py-1.5 rounded hover:bg-cyan-950/70 text-slate-200 text-left cursor-pointer"
            >
              <span className="flex items-center gap-2">
                <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
                <span>Conversation Mode</span>
              </span>
              <span className={`text-[10px] px-1.5 rounded ${conversationMode ? 'bg-emerald-950 text-emerald-300' : 'bg-slate-800 text-slate-500'}`}>
                {conversationMode ? 'ON' : 'OFF'}
              </span>
            </button>

            <div className="border-t border-slate-800 my-1" />

            <button
              onClick={() => {
                onOpenSettings();
                setMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded hover:bg-cyan-950/70 hover:text-cyan-200 text-slate-200 text-left cursor-pointer"
            >
              <Settings className="w-3.5 h-3.5 text-cyan-400" />
              <span>Settings</span>
            </button>

            <button
              onClick={() => {
                onOpenPermissions();
                setMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded hover:bg-cyan-950/70 hover:text-cyan-200 text-slate-200 text-left cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>Permissions</span>
            </button>

            <button
              onClick={() => {
                onOpenHistory();
                setMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded hover:bg-cyan-950/70 hover:text-cyan-200 text-slate-200 text-left cursor-pointer"
            >
              <History className="w-3.5 h-3.5 text-cyan-400" />
              <span>View Command History</span>
            </button>

            <button
              onClick={() => onToggleWakeWord()}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded hover:bg-cyan-950/70 hover:text-cyan-200 text-slate-200 text-left cursor-pointer"
            >
              {wakeWordEnabled ? <Pause className="w-3.5 h-3.5 text-amber-400" /> : <Play className="w-3.5 h-3.5 text-cyan-400" />}
              <span>{wakeWordEnabled ? 'Pause JARVIS' : 'Resume JARVIS'}</span>
            </button>

            <div className="border-t border-slate-800 my-1" />

            <button
              onClick={() => {
                setMenuOpen(false);
                onToggleMinimize();
              }}
              className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded hover:bg-red-950/70 text-red-300 text-left cursor-pointer"
            >
              <Power className="w-3.5 h-3.5 text-red-400" />
              <span>Exit / Close</span>
            </button>
          </div>
        </div>
      )}

      {/* Taskbar Tray Button Bar */}
      <div className="flex items-center gap-2 bg-slate-900/90 border border-cyan-500/40 rounded-full px-3 py-1.5 shadow-[0_0_20px_rgba(0,229,255,0.25)] backdrop-blur-md">
        {/* Glowing Arc Reactor Mini-Icon */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="relative flex items-center justify-center w-7 h-7 rounded-full bg-slate-950 border border-cyan-400 shadow-[0_0_10px_rgba(0,229,255,0.6)] cursor-pointer group"
          title="JARVIS System Tray Menu (Click for options)"
        >
          <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse group-hover:scale-110 transition-transform" />
          <div className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400" />
        </button>

        <span className="text-[11px] font-orbitron font-bold text-cyan-300 pr-1 hidden sm:inline">
          {isMinimized ? 'JARVIS (TRAY MODE)' : 'JARVIS ACTIVE'}
        </span>

        {/* Minimize / Restore Toggle */}
        <button
          onClick={onToggleMinimize}
          className="p-1 rounded text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition-colors cursor-pointer"
          title={isMinimized ? "Restore JARVIS Window" : "Minimize to System Tray"}
        >
          {isMinimized ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
        </button>
      </div>
    </div>
  );
};
