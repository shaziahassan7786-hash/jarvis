import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { JarvisState } from '../types';

interface HolographicJarvisSphereProps {
  state: JarvisState;
  audioLevel: number;
  isListening: boolean;
  onClickSphere?: () => void;
}

export const HolographicJarvisSphere: React.FC<HolographicJarvisSphereProps> = ({
  state,
  audioLevel,
  isListening,
  onClickSphere,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);

  // Dynamic state refs so the 60fps animation loop reads the latest props without re-mounting Three.js!
  const stateRef = useRef<JarvisState>(state);
  const audioLevelRef = useRef<number>(audioLevel);
  const isListeningRef = useRef<boolean>(isListening);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    audioLevelRef.current = audioLevel;
  }, [audioLevel]);

  useEffect(() => {
    isListeningRef.current = isListening;
  }, [isListening]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let width = container.clientWidth || window.innerWidth;
    let height = container.clientHeight || window.innerHeight;

    // 1. Scene & Camera setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.z = 8.2;

    // 2. WebGL Renderer with High Precision & Glow
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 1);
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Master Group
    const masterGroup = new THREE.Group();
    scene.add(masterGroup);

    // Core Colors
    const primaryColor = new THREE.Color(0xff8c00); // Glowing Dark Orange
    const brightColor = new THREE.Color(0xffa500); // Warm Orange
    const goldColor = new THREE.Color(0xffd700); // Arc Gold
    const hotCoreColor = new THREE.Color(0xfff0aa); // Radiant Core

    // 3. Central Arc Reactor Core
    const coreGeo = new THREE.SphereGeometry(0.85, 32, 32);
    const coreMat = new THREE.MeshBasicMaterial({
      color: 0xffa000,
      wireframe: true,
      transparent: true,
      opacity: 0.75,
    });
    const core = new THREE.Mesh(coreGeo, coreMat);
    masterGroup.add(core);

    // Inner bright core
    const innerGeo = new THREE.SphereGeometry(0.42, 24, 24);
    const innerMat = new THREE.MeshBasicMaterial({
      color: hotCoreColor,
      transparent: true,
      opacity: 0.95,
    });
    const innerCore = new THREE.Mesh(innerGeo, innerMat);
    masterGroup.add(innerCore);

    // 4. Concentric Holographic 3D Rings at various inclinations (Like Iron Man's holographic sphere)
    const ringList: { group: THREE.Group; speed: { x: number; y: number; z: number } }[] = [];

    const createHolographicRing = (
      radius: number,
      tiltX: number,
      tiltY: number,
      tiltZ: number,
      speed: { x: number; y: number; z: number },
      segmentsCount: number = 64,
      isDashed: boolean = false,
      color: number = 0xff9900
    ) => {
      const ringGroup = new THREE.Group();
      ringGroup.rotation.set(tiltX, tiltY, tiltZ);

      // Main circular spline
      const curve = new THREE.EllipseCurve(0, 0, radius, radius, 0, 2 * Math.PI, false, 0);
      const points = curve.getPoints(segmentsCount);
      const geometry = new THREE.BufferGeometry().setFromPoints(points);

      let material: THREE.Material;
      if (isDashed) {
        material = new THREE.LineDashedMaterial({
          color,
          dashSize: 0.25,
          gapSize: 0.15,
          transparent: true,
          opacity: 0.85,
        });
      } else {
        material = new THREE.LineBasicMaterial({
          color,
          transparent: true,
          opacity: 0.7,
        });
      }

      const ringLine = new THREE.Line(geometry, material);
      if (isDashed) {
        ringLine.computeLineDistances();
      }
      ringGroup.add(ringLine);

      // Add radial tick marks around the ring for high-tech HUD styling
      const ticksGroup = new THREE.Group();
      const tickCount = Math.floor(segmentsCount / 4);
      for (let t = 0; t < tickCount; t++) {
        const angle = (t / tickCount) * Math.PI * 2;
        const innerR = radius - 0.08;
        const outerR = radius + (t % 3 === 0 ? 0.16 : 0.08);

        const tickPts = [
          new THREE.Vector3(Math.cos(angle) * innerR, Math.sin(angle) * innerR, 0),
          new THREE.Vector3(Math.cos(angle) * outerR, Math.sin(angle) * outerR, 0),
        ];
        const tickGeo = new THREE.BufferGeometry().setFromPoints(tickPts);
        const tickMat = new THREE.LineBasicMaterial({
          color: t % 3 === 0 ? 0xffbb00 : 0xff7700,
          transparent: true,
          opacity: t % 3 === 0 ? 0.9 : 0.45,
        });
        const tickLine = new THREE.Line(tickGeo, tickMat);
        ticksGroup.add(tickLine);
      }
      ringGroup.add(ticksGroup);

      masterGroup.add(ringGroup);
      ringList.push({ group: ringGroup, speed });
    };

    // Construct concentric orbital rings
    createHolographicRing(1.2, 0.4, 0.2, 0, { x: 0.003, y: 0.006, z: 0.002 }, 48, false, 0xffbb00);
    createHolographicRing(1.6, -0.6, 0.8, 0.3, { x: -0.004, y: 0.005, z: -0.003 }, 64, true, 0xff8800);
    createHolographicRing(2.0, 0.8, -0.4, -0.5, { x: 0.005, y: -0.004, z: 0.002 }, 72, false, 0xffaa00);
    createHolographicRing(2.4, -0.2, 0.6, 0.8, { x: -0.003, y: 0.007, z: -0.004 }, 80, true, 0xff7700);
    createHolographicRing(2.8, 0.5, 0.5, -0.2, { x: 0.002, y: -0.005, z: 0.005 }, 96, false, 0xffcc00);
    createHolographicRing(3.1, -0.7, -0.3, 0.4, { x: -0.004, y: 0.003, z: -0.002 }, 64, true, 0xff6600);

    // 5. Curved Latitude/Longitude Data Filaments
    const arcsGroup = new THREE.Group();
    for (let i = 0; i < 7; i++) {
      const arcCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(Math.sin(i) * 2.2, -1.8, Math.cos(i) * 1.5),
        new THREE.Vector3(Math.sin(i + 1) * 2.6, 0, Math.cos(i + 1) * 2.4),
        new THREE.Vector3(Math.sin(i + 2) * 2.1, 1.8, Math.cos(i + 2) * 1.5),
      ]);
      const arcPts = arcCurve.getPoints(36);
      const arcGeo = new THREE.BufferGeometry().setFromPoints(arcPts);
      const arcMat = new THREE.LineBasicMaterial({
        color: 0xff8800,
        transparent: true,
        opacity: 0.35,
      });
      arcsGroup.add(new THREE.Line(arcGeo, arcMat));
    }
    masterGroup.add(arcsGroup);

    // 6. Holographic Swarming Particle Cloud
    const particleCount = 1400;
    const particlePositions = new Float32Array(particleCount * 3);
    const originalPositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = 1.0 + Math.pow(Math.random(), 0.8) * 2.3;

      const sinPhi = Math.sin(phi);
      const x = r * sinPhi * Math.cos(theta);
      const y = r * sinPhi * Math.sin(theta);
      const z = r * Math.cos(phi);

      const idx = i * 3;
      particlePositions[idx] = x;
      particlePositions[idx + 1] = y;
      particlePositions[idx + 2] = z;

      originalPositions[idx] = x;
      originalPositions[idx + 1] = y;
      originalPositions[idx + 2] = z;

      const pColor = Math.random() > 0.6 ? goldColor : Math.random() > 0.3 ? brightColor : primaryColor;
      particleColors[idx] = pColor.r;
      particleColors[idx + 1] = pColor.g;
      particleColors[idx + 2] = pColor.b;
    }

    const particleGeometry = new THREE.BufferGeometry();
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));

    // Particle Material
    const particleMaterial = new THREE.PointsMaterial({
      size: 0.05,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
    });
    const particles = new THREE.Points(particleGeometry, particleMaterial);
    masterGroup.add(particles);

    // Mouse Interaction
    const mouse = { x: 0, y: 0, targetX: 0, targetY: 0 };
    const handleMouseMove = (e: MouseEvent) => {
      mouse.targetX = (e.clientX / window.innerWidth - 0.5) * 0.8;
      mouse.targetY = (e.clientY / window.innerHeight - 0.5) * 0.8;
    };
    window.addEventListener('mousemove', handleMouseMove, { passive: true });

    // Resize Observer
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: newW, height: newH } = entry.contentRect;
        if (newW > 0 && newH > 0) {
          camera.aspect = newW / newH;
          camera.updateProjectionMatrix();
          renderer.setSize(newW, newH);
        }
      }
    });
    resizeObserver.observe(container);

    // Animation Loop
    const clock = new THREE.Clock();
    let animId: number;

    const animate = () => {
      animId = requestAnimationFrame(animate);

      const elapsedTime = clock.getElapsedTime();
      const currentState = stateRef.current;
      const currentAudio = audioLevelRef.current || 0.05;

      // Smooth mouse follow
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      masterGroup.rotation.y = mouse.x * 0.6;
      masterGroup.rotation.x = -mouse.y * 0.6;

      // Spin rate based on state
      let speedMultiplier = 1.0;
      if (currentState === 'THINKING') speedMultiplier = 3.2;
      else if (currentState === 'SPEAKING') speedMultiplier = 1.6;
      else if (currentState === 'LISTENING') speedMultiplier = 1.3;

      // Core pulse with audio reaction
      const corePulse = 1.0 + Math.sin(elapsedTime * 4) * 0.05 + currentAudio * 0.35;
      core.scale.set(corePulse, corePulse, corePulse);

      const innerScale = 1.0 + Math.sin(elapsedTime * 6) * 0.08 + currentAudio * 0.45;
      innerCore.scale.set(innerScale, innerScale, innerScale);

      // Core color shift on state
      if (currentState === 'THINKING') {
        coreMat.color.setHex(0xffea00);
      } else if (currentState === 'LISTENING') {
        coreMat.color.setHex(0xffaa00);
      } else if (currentState === 'SPEAKING') {
        coreMat.color.setHex(0xff8800);
      } else {
        coreMat.color.setHex(0xff9900);
      }

      // Rotate individual concentric rings
      ringList.forEach((item, idx) => {
        item.group.rotation.x += item.speed.x * speedMultiplier;
        item.group.rotation.y += item.speed.y * speedMultiplier;
        item.group.rotation.z += item.speed.z * speedMultiplier;

        if (currentAudio > 0.12) {
          const ringScale = 1.0 + Math.sin(elapsedTime * 8 + idx) * currentAudio * 0.07;
          item.group.scale.set(ringScale, ringScale, ringScale);
        } else {
          item.group.scale.set(1, 1, 1);
        }
      });

      // Rotate filaments
      arcsGroup.rotation.y -= 0.003 * speedMultiplier;
      arcsGroup.rotation.x += 0.0015 * speedMultiplier;

      // Swarm particles around
      const pos = particlePositions;
      const orig = originalPositions;
      const count = particleCount;

      for (let i = 0; i < count; i++) {
        const idx = i * 3;
        const origX = orig[idx];
        const origY = orig[idx + 1];
        const origZ = orig[idx + 2];

        const angle = elapsedTime * 0.12 * speedMultiplier + i * 0.002;
        const cosA = Math.cos(angle);
        const sinA = Math.sin(angle);

        let newX = origX * cosA - origZ * sinA;
        let newZ = origX * sinA + origZ * cosA;
        let newY = origY + Math.sin(elapsedTime * 2 + i) * 0.03;

        // Audio react expand
        if (currentAudio > 0.1) {
          const dist = Math.sqrt(newX * newX + newY * newY + newZ * newZ);
          const expand = 1.0 + currentAudio * 0.2 * Math.sin(dist * 3 - elapsedTime * 4);
          newX *= expand;
          newY *= expand;
          newZ *= expand;
        }

        pos[idx] = newX;
        pos[idx + 1] = newY;
        pos[idx + 2] = newZ;
      }

      particleGeometry.attributes.position.needsUpdate = true;

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', handleMouseMove);
      resizeObserver.disconnect();
      renderer.dispose();
    };
  }, []); // Run ONLY once on mount so it never tears down the canvas!

  return (
    <div
      ref={mountRef}
      onClick={onClickSphere}
      className="relative w-full h-full cursor-pointer select-none flex items-center justify-center pointer-events-auto"
      title="JARVIS Holographic Core (Click to speak)"
    />
  );
};
