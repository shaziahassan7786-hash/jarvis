import React, { useState } from 'react';
import { Settings, Sliders, Volume2, Mic, Globe, Cpu, Check, X, Shield, Plus, Trash2 } from 'lucide-react';
import { JarvisSettings } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  settings: JarvisSettings;
  onSaveSettings: (newSettings: JarvisSettings) => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  settings,
  onSaveSettings,
  onClose,
}) => {
  const [form, setForm] = useState<JarvisSettings>({ ...settings });
  const [newApp, setNewApp] = useState('');
  const [newSite, setNewSite] = useState('');

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveSettings(form);
    onClose();
  };

  const addApp = () => {
    if (!newApp.trim()) return;
    if (!form.allowedApplications.includes(newApp.trim().toLowerCase())) {
      setForm({ ...form, allowedApplications: [...form.allowedApplications, newApp.trim().toLowerCase()] });
    }
    setNewApp('');
  };

  const removeApp = (app: string) => {
    setForm({
      ...form,
      allowedApplications: form.allowedApplications.filter((a) => a !== app),
    });
  };

  const addSite = () => {
    if (!newSite.trim()) return;
    let url = newSite.trim();
    if (!url.startsWith('http')) url = `https://${url}`;
    if (!form.allowedWebsites.includes(url)) {
      setForm({ ...form, allowedWebsites: [...form.allowedWebsites, url] });
    }
    setNewSite('');
  };

  const removeSite = (site: string) => {
    setForm({
      ...form,
      allowedWebsites: form.allowedWebsites.filter((s) => s !== site),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-cyan-500/40 rounded-xl p-6 shadow-[0_0_40px_rgba(0,229,255,0.2)] max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-cyan-950/70 border border-cyan-500/40 rounded-lg text-cyan-400">
              <Sliders className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-orbitron font-bold text-white tracking-wide">
                JARVIS Core Configuration
              </h2>
              <p className="text-xs text-slate-400">
                Adjust speech engines, AI reasoning provider, security thresholds, and startup behavior.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="flex-1 overflow-y-auto space-y-5 py-4 pr-1 text-xs">
          {/* 1. Voice & Wake Word */}
          <div className="p-3.5 bg-slate-950/60 border border-cyan-500/20 rounded-lg space-y-3">
            <h3 className="font-orbitron font-bold text-cyan-300 flex items-center gap-2 text-xs">
              <Mic className="w-4 h-4 text-cyan-400" />
              VOICE & WAKE-WORD DETECTION
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Wake Word Phrase:</label>
                <input
                  type="text"
                  value={form.wakeWord}
                  onChange={(e) => setForm({ ...form, wakeWord: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-cyan-200 font-mono-code focus:border-cyan-400 focus:outline-none"
                  placeholder="Hey Jarvis"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Speech Recognition Language:</label>
                <select
                  value={form.language}
                  onChange={(e) => setForm({ ...form, language: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-cyan-200 font-mono-code focus:border-cyan-400 focus:outline-none"
                >
                  <option value="en-US">English (United States)</option>
                  <option value="en-GB">English (United Kingdom - JARVIS Classic)</option>
                  <option value="en-AU">English (Australia)</option>
                  <option value="en-CA">English (Canada)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div>
                <label className="text-slate-400 block mb-1">TTS Speech Rate ({form.speechRate} WPM):</label>
                <input
                  type="range"
                  min={120}
                  max={240}
                  value={form.speechRate}
                  onChange={(e) => setForm({ ...form, speechRate: parseInt(e.target.value) })}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">TTS Speech Pitch ({form.speechPitch}):</label>
                <input
                  type="range"
                  min={0.6}
                  max={1.4}
                  step={0.1}
                  value={form.speechPitch}
                  onChange={(e) => setForm({ ...form, speechPitch: parseFloat(e.target.value) })}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* 2. AI Reasoning Provider */}
          <div className="p-3.5 bg-slate-950/60 border border-cyan-500/20 rounded-lg space-y-3">
            <h3 className="font-orbitron font-bold text-cyan-300 flex items-center gap-2 text-xs">
              <Cpu className="w-4 h-4 text-cyan-400" />
              AI REASONING ENGINE
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">AI Reasoning Provider:</label>
                <select
                  value={form.aiProvider}
                  onChange={(e) => setForm({ ...form, aiProvider: e.target.value as any })}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-cyan-200 font-mono-code focus:border-cyan-400 focus:outline-none"
                >
                  <option value="gemini">Gemini 3.8 Flash (Cloud Function Calling)</option>
                  <option value="local_rule">Local Fast Rule Matcher (Zero Cloud / Offline)</option>
                </select>
              </div>
              <div className="flex flex-col justify-center">
                <span className="text-[11px] text-slate-400">
                  Gemini API is securely proxied on the server backend with tools. Local Rule Matcher provides zero latency and zero RAM usage.
                </span>
              </div>
            </div>
          </div>

          {/* 3. Startup & Interaction Behavior */}
          <div className="p-3.5 bg-slate-950/60 border border-cyan-500/20 rounded-lg space-y-3">
            <h3 className="font-orbitron font-bold text-cyan-300 flex items-center gap-2 text-xs">
              <Shield className="w-4 h-4 text-cyan-400" />
              SYSTEM BEHAVIOR & SECURITY POLICIES
            </h3>
            <div className="space-y-2">
              <label className="flex items-center justify-between p-2 bg-slate-900 rounded border border-slate-800 cursor-pointer">
                <div>
                  <span className="text-white font-medium block">Start JARVIS with Windows</span>
                  <span className="text-slate-400 text-[11px]">Automatically launch JARVIS minimized to system tray on Windows startup.</span>
                </div>
                <input
                  type="checkbox"
                  checked={form.startWithWindows}
                  onChange={(e) => setForm({ ...form, startWithWindows: e.target.checked })}
                  className="accent-cyan-400 w-4 h-4 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2 bg-slate-900 rounded border border-slate-800 cursor-pointer">
                <div>
                  <span className="text-white font-medium block">Always Require Confirmation for High-Risk Actions</span>
                  <span className="text-slate-400 text-[11px]">Prompt "Are you sure you want me to do this?" before deleting files or terminal actions.</span>
                </div>
                <input
                  type="checkbox"
                  checked={form.highRiskConfirmation}
                  onChange={(e) => setForm({ ...form, highRiskConfirmation: e.target.checked })}
                  className="accent-cyan-400 w-4 h-4 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2 bg-slate-900 rounded border border-slate-800 cursor-pointer">
                <div>
                  <span className="text-white font-medium block">Conversation Mode</span>
                  <span className="text-slate-400 text-[11px]">Continue listening for follow-up speech after responding.</span>
                </div>
                <input
                  type="checkbox"
                  checked={form.conversationMode}
                  onChange={(e) => setForm({ ...form, conversationMode: e.target.checked })}
                  className="accent-cyan-400 w-4 h-4 cursor-pointer"
                />
              </label>
            </div>
          </div>

          {/* 4. Whitelisted Applications */}
          <div className="p-3.5 bg-slate-950/60 border border-cyan-500/20 rounded-lg space-y-3">
            <h3 className="font-orbitron font-bold text-cyan-300 text-xs">
              ALLOWED APPLICATIONS WHITELIST
            </h3>
            <div className="flex gap-2">
              <input
                type="text"
                value={newApp}
                onChange={(e) => setNewApp(e.target.value)}
                placeholder="e.g. vlc, discord, steam..."
                className="flex-1 bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-cyan-200 font-mono-code focus:border-cyan-400 focus:outline-none"
              />
              <button
                type="button"
                onClick={addApp}
                className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
              {form.allowedApplications.map((app) => (
                <span
                  key={app}
                  className="flex items-center gap-1.5 px-2 py-0.5 bg-slate-900 border border-cyan-500/30 rounded text-cyan-300 font-mono-code text-[11px]"
                >
                  {app}
                  <button onClick={() => removeApp(app)} className="text-slate-500 hover:text-red-400">
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* 5. Whitelisted Websites */}
          <div className="p-3.5 bg-slate-950/60 border border-cyan-500/20 rounded-lg space-y-3">
            <h3 className="font-orbitron font-bold text-cyan-300 text-xs">
              ALLOWED WEBSITES WHITELIST
            </h3>
            <div className="flex gap-2">
              <input
                type="text"
                value={newSite}
                onChange={(e) => setNewSite(e.target.value)}
                placeholder="e.g. https://github.com..."
                className="flex-1 bg-slate-900 border border-slate-700 rounded px-3 py-1.5 text-cyan-200 font-mono-code focus:border-cyan-400 focus:outline-none"
              />
              <button
                type="button"
                onClick={addSite}
                className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
              {form.allowedWebsites.map((site) => (
                <span
                  key={site}
                  className="flex items-center gap-1.5 px-2 py-0.5 bg-slate-900 border border-cyan-500/30 rounded text-cyan-300 font-mono-code text-[11px]"
                >
                  {site}
                  <button onClick={() => removeSite(site)} className="text-slate-500 hover:text-red-400">
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 mt-2 border-t border-cyan-500/20 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-orbitron font-bold rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Check className="w-4 h-4" />
            Save Settings
          </button>
        </div>
      </div>
    </div>
  );
};
