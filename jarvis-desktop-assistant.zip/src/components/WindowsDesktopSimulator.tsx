import React, { useState } from 'react';
import { 
  X, 
  Minus, 
  Square, 
  ExternalLink, 
  FileText, 
  Calculator, 
  Camera, 
  Volume2, 
  VolumeX, 
  Globe, 
  Check, 
  Terminal,
  FolderOpen
} from 'lucide-react';
import { ToolCallExecution } from '../types';

interface WindowsDesktopSimulatorProps {
  activeApp: string | null;
  activeUrl: string | null;
  screenshotUrl: string | null;
  volumeLevel: number;
  isMuted: boolean;
  onCloseApp: () => void;
  onClearScreenshot: () => void;
  searchQuery?: string | null;
}

export const WindowsDesktopSimulator: React.FC<WindowsDesktopSimulatorProps> = ({
  activeApp,
  activeUrl,
  screenshotUrl,
  volumeLevel,
  isMuted,
  onCloseApp,
  onClearScreenshot,
  searchQuery,
}) => {
  const [notepadText, setNotepadText] = useState(
    '// JARVIS Automated Workspace Document\nSystem running in low-resource daemon mode.\nAll parameters nominal, sir.'
  );
  const [calcDisplay, setCalcDisplay] = useState('42');
  const [activeSearchTab, setActiveSearchTab] = useState(searchQuery || 'fast client');

  // Volume overlay alert
  const [showVolumeToast, setShowVolumeToast] = useState(false);

  if (!activeApp && !activeUrl && !screenshotUrl) {
    return null;
  }

  const isSearchBar = activeApp === 'browser_search_bar' || activeApp === 'search_bar';
  const isFastClient = activeApp === 'fast_client' || (searchQuery && searchQuery.toLowerCase().includes('fast client'));

  return (
    <div className="fixed inset-0 z-40 pointer-events-none flex items-center justify-center p-4">
      {/* Background Dim */}
      <div 
        onClick={onCloseApp} 
        className="absolute inset-0 bg-slate-950/60 backdrop-blur-[2px] pointer-events-auto"
      />

      {/* Simulated Windows Window */}
      <div className="relative z-50 pointer-events-auto w-full max-w-xl bg-slate-900 border-2 border-cyan-400/80 rounded-xl shadow-[0_0_50px_rgba(0,229,255,0.4)] overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Windows 11 Style Titlebar */}
        <div className="flex items-center justify-between px-3 py-2 bg-slate-950 border-b border-cyan-500/30 select-none">
          <div className="flex items-center gap-2">
            {activeApp === 'notepad' && <FileText className="w-4 h-4 text-cyan-400" />}
            {activeApp === 'calculator' && <Calculator className="w-4 h-4 text-amber-400" />}
            {isSearchBar && <Globe className="w-4 h-4 text-cyan-400" />}
            {isFastClient && <Terminal className="w-4 h-4 text-emerald-400" />}
            {activeUrl && !isSearchBar && <Globe className="w-4 h-4 text-blue-400" />}
            {screenshotUrl && <Camera className="w-4 h-4 text-emerald-400" />}
            
            <span className="text-xs font-mono-code font-bold text-slate-200">
              {activeApp === 'notepad' && 'Windows Notepad — Untilted.txt'}
              {activeApp === 'calculator' && 'Windows Calculator'}
              {isSearchBar && 'Browser Search & Address Bar Navigation'}
              {isFastClient && 'Fast Client — High Speed Desktop Gateway [ACTIVE]'}
              {activeUrl && !isSearchBar && `Web Browser Navigation — ${activeUrl}`}
              {screenshotUrl && 'Screen Capture Viewer — Pictures/Screenshots'}
            </span>
          </div>

          <div className="flex items-center gap-1">
            <button 
              onClick={onCloseApp}
              className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors"
              title="Minimize"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <button 
              onClick={onCloseApp}
              className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded transition-colors"
              title="Maximize"
            >
              <Square className="w-3 h-3" />
            </button>
            <button 
              onClick={() => {
                if (screenshotUrl) onClearScreenshot();
                onCloseApp();
              }}
              className="p-1 hover:bg-red-600 text-slate-400 hover:text-white rounded transition-colors"
              title="Close"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Window Content Body */}
        <div className="p-4 bg-slate-900/90 min-h-[240px] flex flex-col justify-between">
          {/* 0. Browser Search Bar & Fast Client Automation */}
          {isSearchBar && (
            <div className="flex-1 flex flex-col space-y-4">
              <div className="bg-slate-950 p-3 rounded-lg border border-cyan-500/40">
                <div className="text-[11px] font-mono-code text-cyan-400 mb-2 flex items-center justify-between">
                  <span>ADDRESS / SEARCH TAB BAR (Ctrl+L)</span>
                  <span className="text-emerald-400 flex items-center gap-1">
                    <Check className="w-3 h-3" /> ENTER PRESSED
                  </span>
                </div>
                <div className="flex items-center gap-2 bg-slate-900 px-3 py-2 rounded border border-cyan-500/50">
                  <Globe className="w-4 h-4 text-cyan-400 shrink-0" />
                  <input
                    type="text"
                    value={activeSearchTab}
                    onChange={(e) => setActiveSearchTab(e.target.value)}
                    className="w-full bg-transparent text-sm font-mono-code text-cyan-200 focus:outline-none"
                    placeholder="Search or enter web address..."
                  />
                  <span className="text-[10px] bg-cyan-950 text-cyan-400 px-2 py-0.5 rounded border border-cyan-700/50 shrink-0">
                    Opened
                  </span>
                </div>
              </div>

              {/* Fast Client Simulated App Launch */}
              <div className="bg-slate-950/80 p-4 rounded-lg border border-emerald-500/30 flex flex-col space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-emerald-400 font-orbitron font-bold text-xs">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span>FAST CLIENT RUNNING</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono-code">PID: 4928 • PORT: 8080</span>
                </div>
                <p className="text-xs text-slate-300 font-mono-code">
                  JARVIS successfully accessed the search bar, wrote <span className="text-cyan-300 font-bold">"{activeSearchTab}"</span>, and executed the target client on your computer.
                </p>
                <div className="flex items-center gap-2 pt-2">
                  <a
                    href={`https://www.google.com/search?q=${encodeURIComponent(activeSearchTab)}`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-mono-code font-bold text-[11px] rounded transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Launch in Web Browser
                  </a>
                  <button
                    onClick={onCloseApp}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono-code text-[11px] rounded"
                  >
                    Close Simulation
                  </button>
                </div>
              </div>
            </div>
          )}
          {/* 1. Notepad App */}
          {activeApp === 'notepad' && (
            <div className="flex-1 flex flex-col space-y-2">
              <div className="flex items-center gap-3 text-[11px] text-slate-400 border-b border-slate-800 pb-1 font-sans">
                <span>File</span>
                <span>Edit</span>
                <span>Format</span>
                <span>View</span>
                <span>Help</span>
                <span className="ml-auto text-cyan-400 font-mono-code text-[10px]">JARVIS AUTOMATION HOOK ACTIVE</span>
              </div>
              <textarea
                value={notepadText}
                onChange={(e) => setNotepadText(e.target.value)}
                className="w-full flex-1 min-h-[160px] bg-slate-950 text-slate-200 p-3 rounded font-mono-code text-xs border border-cyan-500/20 focus:outline-none focus:border-cyan-400 resize-none"
              />
              <div className="text-[10px] text-slate-400 font-mono-code flex justify-between items-center">
                <span>Ln 3, Col 24 • UTF-8 • Windows (CRLF)</span>
                <span className="text-emerald-400 flex items-center gap-1">
                  <Check className="w-3 h-3" /> Process launched via system hook
                </span>
              </div>
            </div>
          )}

          {/* 2. Calculator App */}
          {activeApp === 'calculator' && (
            <div className="flex flex-col items-center justify-center py-2">
              <div className="w-full max-w-xs bg-slate-950 p-3 rounded-lg border border-cyan-500/30">
                <div className="text-right text-2xl font-mono-code text-cyan-300 font-bold p-2 bg-slate-900/80 rounded mb-3 border border-cyan-500/20">
                  {calcDisplay}
                </div>
                <div className="grid grid-cols-4 gap-1.5 text-xs font-mono-code">
                  {['7','8','9','/','4','5','6','*','1','2','3','-','C','0','=','+'].map((btn) => (
                    <button
                      key={btn}
                      onClick={() => {
                        if (btn === 'C') setCalcDisplay('0');
                        else if (btn === '=') {
                          try {
                            // Safe calculation
                            const res = Function(`"use strict";return (${calcDisplay})`)();
                            setCalcDisplay(String(res));
                          } catch {
                            setCalcDisplay('Error');
                          }
                        } else {
                          setCalcDisplay((prev) => (prev === '0' || prev === '42' ? btn : prev + btn));
                        }
                      }}
                      className="p-2.5 bg-slate-800 hover:bg-cyan-900 text-slate-200 hover:text-cyan-200 rounded font-bold transition-all cursor-pointer"
                    >
                      {btn}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 3. Browser / URL Navigation */}
          {activeUrl && (
            <div className="flex flex-col items-center justify-center py-4 space-y-4 text-center">
              <div className="w-12 h-12 rounded-full bg-cyan-950 border border-cyan-400 flex items-center justify-center text-cyan-300 shadow-[0_0_20px_rgba(0,229,255,0.4)]">
                <Globe className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h3 className="text-base font-orbitron font-bold text-white mb-1">
                  Destination Web Target
                </h3>
                <p className="text-xs font-mono-code text-cyan-300 break-all max-w-md bg-slate-950 px-3 py-1.5 rounded border border-cyan-500/30">
                  {activeUrl}
                </p>
              </div>
              <p className="text-xs text-slate-400 max-w-sm">
                JARVIS triggered this destination. In web sandboxes, popups may be restricted. Click below to open directly:
              </p>
              <a
                href={activeUrl}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-orbitron font-bold text-xs rounded-lg shadow-[0_0_20px_rgba(0,229,255,0.4)] transition-all cursor-pointer"
              >
                <ExternalLink className="w-4 h-4" />
                <span>OPEN IN NEW TAB NOW</span>
              </a>
            </div>
          )}

          {/* 4. Screenshot Capture Viewer */}
          {screenshotUrl && (
            <div className="flex flex-col space-y-3">
              <div className="relative rounded-lg overflow-hidden border border-cyan-500/40 bg-slate-950 aspect-video flex items-center justify-center">
                {/* Synthetic Desktop Screenshot Rendering */}
                <div className="w-full h-full p-4 flex flex-col justify-between bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/60 relative">
                  <div className="flex justify-between items-center text-[10px] font-mono-code text-cyan-400">
                    <span>JARVIS_SCREENSHOT_{new Date().toISOString().slice(0, 10)}.PNG</span>
                    <span>1920x1080 • FULL DISPLAY CAPTURE</span>
                  </div>
                  <div className="text-center py-6">
                    <div className="w-12 h-12 mx-auto rounded-full bg-cyan-500/20 border border-cyan-400 flex items-center justify-center text-cyan-300 mb-2">
                      <Camera className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-orbitron font-semibold text-slate-300">
                      DESKTOP SCREEN CAPTURED
                    </span>
                    <p className="text-[10px] text-slate-400 font-mono-code mt-1">
                      Saved to user folder: %USERPROFILE%\Pictures\Screenshots\
                    </p>
                  </div>
                  <div className="h-6 bg-slate-950/80 rounded border border-cyan-500/30 flex items-center px-2 text-[9px] text-cyan-300 font-mono-code">
                    <span>Windows Taskbar — Active Processes: Chrome, VS Code, JARVIS Daemon</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-mono-code text-[11px]">
                  File: screenshot_{Date.now()}.png
                </span>
                <button
                  onClick={onClearScreenshot}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[11px] font-mono-code cursor-pointer"
                >
                  Dismiss Preview
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
