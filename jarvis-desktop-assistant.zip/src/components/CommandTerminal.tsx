import React, { useState } from 'react';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Send, 
  Sparkles, 
  MessageSquare, 
  CheckCircle2, 
  AlertCircle,
  Play,
  Terminal,
  Radio
} from 'lucide-react';
import { JarvisState, ToolCallExecution } from '../types';
import { AudioWaveform } from './AudioWaveform';

interface CommandTerminalProps {
  state: JarvisState;
  currentCommand: string;
  responseOutput: string;
  lastToolCall: ToolCallExecution | null;
  micEnabled: boolean;
  audioLevel: number;
  wakeWordActive: boolean;
  conversationMode: boolean;
  onToggleMic: () => void;
  onToggleWakeWord: () => void;
  onToggleConversationMode: () => void;
  onTriggerPushToTalk: () => void;
  onSubmitCommand: (cmd: string) => void;
  onOpenVoiceDiagnostics: () => void;
  onTestSound?: () => void;
}

export const CommandTerminal: React.FC<CommandTerminalProps> = ({
  state,
  currentCommand,
  responseOutput,
  lastToolCall,
  micEnabled,
  audioLevel,
  wakeWordActive,
  conversationMode,
  onToggleMic,
  onToggleWakeWord,
  onToggleConversationMode,
  onTriggerPushToTalk,
  onSubmitCommand,
  onOpenVoiceDiagnostics,
  onTestSound,
}) => {
  const [manualInput, setManualInput] = useState('');

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualInput.trim()) return;
    onSubmitCommand(manualInput.trim());
    setManualInput('');
  };

  const getStateBadge = () => {
    switch (state) {
      case 'LISTENING':
        return {
          text: 'LISTENING FOR AUDIO...',
          style: 'bg-cyan-950/80 text-cyan-300 border-cyan-400 shadow-[0_0_12px_rgba(0,229,255,0.4)] animate-pulse',
        };
      case 'THINKING':
        return {
          text: 'AI REASONING & ROUTING...',
          style: 'bg-amber-950/80 text-amber-300 border-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.4)]',
        };
      case 'EXECUTING':
        return {
          text: 'EXECUTING OS ACTION...',
          style: 'bg-blue-950/80 text-blue-300 border-blue-400 shadow-[0_0_12px_rgba(59,130,246,0.4)]',
        };
      case 'SPEAKING':
        return {
          text: 'JARVIS RESPONDING (TTS)...',
          style: 'bg-cyan-950/80 text-cyan-200 border-cyan-300 shadow-[0_0_12px_rgba(0,229,255,0.6)] animate-pulse',
        };
      case 'ERROR':
        return {
          text: 'SYSTEM WARNING / ERROR',
          style: 'bg-red-950/80 text-red-300 border-red-500 shadow-[0_0_12px_rgba(239,68,68,0.5)]',
        };
      case 'IDLE':
      default:
        return {
          text: 'JARVIS ONLINE - STANDING BY',
          style: 'bg-slate-900/80 text-cyan-400 border-cyan-500/40',
        };
    }
  };

  const badge = getStateBadge();

  return (
    <div className="flex flex-col h-full bg-slate-900/60 border border-cyan-500/25 rounded-xl p-4 backdrop-blur-md relative overflow-hidden">
      {/* Top Status & Controls Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-cyan-500/20">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
          <span className={`px-2.5 py-0.5 rounded text-[11px] font-orbitron font-bold border tracking-wider ${badge.style}`}>
            {badge.text}
          </span>
        </div>

        {/* Action toggles */}
        <div className="flex items-center gap-1.5 text-xs">
          {/* Diagnostics Modal Button */}
          <button
            onClick={onOpenVoiceDiagnostics}
            title="Voice & Mic Diagnostics: Troubleshoot voice recognition, mic permissions, or test audio"
            className="flex items-center gap-1 px-2 py-1 rounded text-[11px] font-mono-code transition-all cursor-pointer border bg-cyan-950/60 hover:bg-cyan-900/70 text-cyan-300 border-cyan-400/60 shadow-[0_0_6px_rgba(0,229,255,0.2)]"
          >
            <Sparkles className="w-3 h-3 text-cyan-400" />
            <span>DIAGNOSTICS</span>
          </button>

          {/* Wake word toggle */}
          <button
            onClick={onToggleWakeWord}
            title={wakeWordActive ? "Wake word active ('Hey Jarvis')" : "Wake word listening disabled"}
            className={`flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-mono-code transition-all cursor-pointer border ${
              wakeWordActive 
                ? 'bg-cyan-950/60 text-cyan-300 border-cyan-400 shadow-[0_0_8px_rgba(0,229,255,0.3)]' 
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
          >
            <Radio className="w-3 h-3 text-cyan-400" />
            <span className="hidden sm:inline">WAKE:</span> <span>{wakeWordActive ? 'ON' : 'OFF'}</span>
          </button>

          {/* Conversation mode toggle */}
          <button
            onClick={onToggleConversationMode}
            title={conversationMode ? "Conversation mode: continues listening after speech" : "Single command mode"}
            className={`flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-mono-code transition-all cursor-pointer border ${
              conversationMode 
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.3)]' 
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}
          >
            <MessageSquare className="w-3 h-3" />
            <span className="hidden sm:inline">CONVO:</span> <span>{conversationMode ? 'ON' : 'OFF'}</span>
          </button>

          {/* Microphone Mute Toggle */}
          <button
            onClick={onToggleMic}
            title={micEnabled ? "Mute Microphone" : "Unmute / Authorize Microphone"}
            className={`flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-mono-code transition-all cursor-pointer border ${
              micEnabled
                ? 'bg-cyan-950/60 text-cyan-300 border-cyan-400'
                : 'bg-red-950/80 text-red-300 border-red-500 shadow-[0_0_8px_rgba(239,68,68,0.4)]'
            }`}
          >
            {micEnabled ? <Mic className="w-3 h-3 text-cyan-300" /> : <MicOff className="w-3 h-3 text-red-400" />}
            <span>{micEnabled ? 'MIC ON' : 'MUTED'}</span>
          </button>
        </div>
      </div>

      {/* Waveform Realtime Visualizer */}
      <div className="my-3">
        <AudioWaveform state={state} audioLevel={audioLevel} isMuted={!micEnabled} />
      </div>

      {/* Command & Response Terminal Display */}
      <div className="flex-1 flex flex-col justify-between bg-slate-950/80 rounded-lg p-3 border border-cyan-500/20 mb-3 space-y-3 min-h-[160px]">
        {/* User Command Line */}
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono-code text-cyan-400/70 uppercase tracking-wider mb-1">
            <Terminal className="w-3 h-3 text-cyan-400" />
            <span>Spoken / Input Command:</span>
          </div>
          <div className="text-sm sm:text-base font-orbitron font-semibold text-cyan-100 pl-4 border-l-2 border-cyan-400 py-0.5">
            {currentCommand || '"Hey Jarvis, open YouTube"'}
          </div>
        </div>

        {/* Tool Execution Badge (if any) */}
        {lastToolCall && (
          <div className="p-2 bg-slate-900/90 rounded border border-cyan-500/30 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-mono-code text-cyan-300 font-semibold">{lastToolCall.name}()</span>
              <span className="text-[10px] text-slate-400 font-mono-code hidden sm:inline">
                {JSON.stringify(lastToolCall.args)}
              </span>
            </div>
            <span className={`px-1.5 py-0.5 text-[9px] font-bold rounded ${
              lastToolCall.risk === 'HIGH' ? 'bg-red-950 text-red-400 border border-red-700' :
              lastToolCall.risk === 'MEDIUM' ? 'bg-amber-950 text-amber-300 border border-amber-700' :
              'bg-cyan-950 text-cyan-300 border border-cyan-700'
            }`}>
              {lastToolCall.risk} RISK
            </span>
          </div>
        )}

        {/* JARVIS Verbal Response */}
        <div>
          <div className="flex items-center gap-2 text-[10px] font-mono-code text-cyan-400/70 uppercase tracking-wider mb-1">
            <Sparkles className="w-3 h-3 text-cyan-400" />
            <span>JARVIS Vocal Output:</span>
          </div>
          <div className="text-sm sm:text-base text-slate-200 font-medium pl-4 border-l-2 border-cyan-500/40 py-0.5 leading-relaxed">
            {responseOutput || 'Certainly sir. Systems are primed and awaiting your instruction.'}
          </div>
        </div>
      </div>

      {/* Push-to-Talk and Manual Input Bar */}
      <div className="flex items-center gap-2 pt-2 border-t border-cyan-500/20">
        <button
          onClick={() => {
            if (!micEnabled) {
              onOpenVoiceDiagnostics();
            } else {
              onTriggerPushToTalk();
            }
          }}
          disabled={state === 'THINKING'}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-orbitron font-bold transition-all cursor-pointer whitespace-nowrap ${
            state === 'LISTENING'
              ? 'bg-cyan-400 text-slate-950 shadow-[0_0_20px_rgba(0,229,255,0.8)] animate-pulse'
              : !micEnabled
              ? 'bg-amber-950/70 hover:bg-amber-900/80 text-amber-300 border border-amber-500/50 shadow-[0_0_10px_rgba(245,158,11,0.2)]'
              : 'bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-400/60 shadow-[0_0_12px_rgba(0,229,255,0.2)]'
          }`}
          title={!micEnabled ? "Microphone is muted/needs permission - click to configure" : "Push to Talk: Hold or Click to Speak [Space]"}
        >
          <Mic className="w-4 h-4" />
          <span>
            {state === 'LISTENING'
              ? 'LISTENING... (SPEAK NOW)'
              : !micEnabled
              ? 'ENABLE MIC TO SPEAK'
              : 'PUSH TO TALK [SPACE]'}
          </span>
        </button>

        <form onSubmit={handleManualSubmit} className="flex-1 flex items-center gap-1.5">
          <input
            type="text"
            value={manualInput}
            onChange={(e) => setManualInput(e.target.value)}
            placeholder="Type command or speech alternative (e.g. 'open youtube', 'mute computer')..."
            className="flex-1 bg-slate-950/90 border border-cyan-500/30 focus:border-cyan-400 rounded-lg px-3 py-2 text-xs font-mono-code text-cyan-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-400 transition-all"
          />
          <button
            type="submit"
            className="p-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 rounded-lg transition-colors cursor-pointer"
            title="Send command"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
