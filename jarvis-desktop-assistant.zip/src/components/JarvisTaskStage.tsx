import React, { useState, useEffect } from 'react';
import { 
  X, 
  Minus, 
  Square, 
  Maximize2, 
  FileText, 
  Calculator as CalcIcon, 
  Globe, 
  Terminal, 
  Camera, 
  Sparkles, 
  Download, 
  Copy, 
  Check, 
  Search,
  ExternalLink,
  Volume2,
  VolumeX,
  Folder,
  Cpu,
  HardDrive,
  Activity,
  Laptop,
  Zap
} from 'lucide-react';

export interface JarvisTaskStageProps {
  activeTask: 'notepad' | 'calculator' | 'browser' | 'screenshot' | 'terminal' | 'intelligence' | 'system_info' | 'volume' | 'files' | null;
  taskData?: any;
  onClose: () => void;
  localBridgeConnected?: boolean;
  onOpenPcBridge?: () => void;
}

export const JarvisTaskStage: React.FC<JarvisTaskStageProps> = ({
  activeTask,
  taskData,
  onClose,
  localBridgeConnected = false,
  onOpenPcBridge,
}) => {
  // Notepad state
  const [noteContent, setNoteContent] = useState<string>(
    taskData?.initialText || 'Welcome to JARVIS Notepad.\nReady for your notes...'
  );
  const [copiedNote, setCopiedNote] = useState(false);

  // Sync taskData changes
  useEffect(() => {
    if (taskData?.initialText) {
      setNoteContent(taskData.initialText);
    }
  }, [taskData?.initialText]);

  // Calculator state
  const [calcInput, setCalcInput] = useState<string>('0');
  const [calcPrev, setCalcPrev] = useState<string>('');
  const [calcOp, setCalcOp] = useState<string | null>(null);

  // Intelligence panel copied state
  const [copiedIntel, setCopiedIntel] = useState(false);

  // Window minimized state
  const [isMinimized, setIsMinimized] = useState(false);

  if (!activeTask) return null;

  // Calculator handler
  const handleCalcBtn = (val: string) => {
    if (val === 'C') {
      setCalcInput('0');
      setCalcPrev('');
      setCalcOp(null);
    } else if (['+', '-', '*', '/'].includes(val)) {
      setCalcPrev(calcInput);
      setCalcOp(val);
      setCalcInput('0');
    } else if (val === '=') {
      try {
        const num1 = parseFloat(calcPrev);
        const num2 = parseFloat(calcInput);
        let res = 0;
        if (calcOp === '+') res = num1 + num2;
        else if (calcOp === '-') res = num1 - num2;
        else if (calcOp === '*') res = num1 * num2;
        else if (calcOp === '/') res = num2 !== 0 ? num1 / num2 : 0;
        setCalcInput(String(res));
        setCalcPrev('');
        setCalcOp(null);
      } catch (e) {
        setCalcInput('Error');
      }
    } else {
      setCalcInput((prev) => (prev === '0' ? val : prev + val));
    }
  };

  // Download note as .txt
  const downloadNote = () => {
    const blob = new Blob([noteContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `jarvis_note_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Copy note
  const copyNote = () => {
    navigator.clipboard.writeText(noteContent);
    setCopiedNote(true);
    setTimeout(() => setCopiedNote(false), 2000);
  };

  return (
    <div className="fixed top-16 right-5 z-40 w-96 max-w-[calc(100vw-40px)] rounded-xl overflow-hidden border border-amber-500/50 bg-black/90 backdrop-blur-xl shadow-[0_0_35px_rgba(255,140,0,0.3)] transition-all animate-in fade-in slide-in-from-right-6 duration-300">
      {/* Window Title Bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-gradient-to-r from-amber-950/80 via-neutral-900 to-black border-b border-amber-500/30 select-none">
        <div className="flex items-center gap-2">
          {activeTask === 'notepad' && <FileText className="w-4 h-4 text-amber-400" />}
          {activeTask === 'calculator' && <CalcIcon className="w-4 h-4 text-amber-400" />}
          {activeTask === 'browser' && <Globe className="w-4 h-4 text-amber-400" />}
          {activeTask === 'screenshot' && <Camera className="w-4 h-4 text-amber-400" />}
          {activeTask === 'terminal' && <Terminal className="w-4 h-4 text-amber-400" />}
          {activeTask === 'intelligence' && <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />}
          {activeTask === 'system_info' && <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />}
          {activeTask === 'volume' && <Volume2 className="w-4 h-4 text-amber-400" />}
          {activeTask === 'files' && <Folder className="w-4 h-4 text-amber-400" />}
          
          <span className="text-xs font-orbitron font-semibold text-amber-300 tracking-wider">
            {activeTask === 'notepad' && 'WINDOWS NOTEPAD'}
            {activeTask === 'calculator' && 'SYSTEM CALCULATOR'}
            {activeTask === 'browser' && 'JARVIS WEB BROWSER'}
            {activeTask === 'screenshot' && 'SCREENSHOT CAPTURE'}
            {activeTask === 'terminal' && 'POWERSHELL TERMINAL'}
            {activeTask === 'intelligence' && 'JARVIS INTEL DOSSIER'}
            {activeTask === 'system_info' && 'SYSTEM TELEMETRY & SPECS'}
            {activeTask === 'volume' && 'AUDIO MASTER CONTROL'}
            {activeTask === 'files' && 'FILE EXPLORER'}
          </span>
        </div>

        {/* Window Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 text-slate-400 hover:text-amber-300 hover:bg-neutral-800 rounded transition-colors"
            title="Minimize"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-red-400 hover:bg-red-950/40 rounded transition-colors"
            title="Close"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Execution Environment Status Banner */}
      <div className="px-3 py-1.5 bg-neutral-950/95 border-b border-amber-500/20 text-[10px] font-mono flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-amber-300">
          <span className={`w-2 h-2 rounded-full ${localBridgeConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
          <span className="font-semibold">
            {localBridgeConnected ? 'REAL PC APP RUNNING' : 'IN-BROWSER SIMULATION'}
          </span>
        </div>
        {!localBridgeConnected && onOpenPcBridge && (
          <button
            onClick={onOpenPcBridge}
            className="flex items-center gap-1 text-amber-400 hover:text-amber-200 underline cursor-pointer font-semibold"
            title="Click to learn how to open actual Windows apps"
          >
            <Zap className="w-3 h-3 text-amber-400" />
            <span>Open on Windows PC &rarr;</span>
          </button>
        )}
      </div>

      {/* Window Body (if not minimized) */}
      {!isMinimized && (
        <div className="p-3">
          {/* NOTEPAD */}
          {activeTask === 'notepad' && (
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-neutral-800 pb-1.5">
                <span>File  Edit  Format  View  Help</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={copyNote}
                    className="flex items-center gap-1 hover:text-amber-300 transition-colors"
                  >
                    {copiedNote ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedNote ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={downloadNote}
                    className="flex items-center gap-1 hover:text-amber-300 transition-colors"
                  >
                    <Download className="w-3 h-3" />
                    <span>Save .txt</span>
                  </button>
                </div>
              </div>
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                placeholder="Type notes here..."
                rows={9}
                className="w-full bg-neutral-950 text-amber-100 font-mono text-xs p-2.5 rounded border border-neutral-800 focus:border-amber-500/50 focus:outline-none resize-none"
              />
              <div className="flex justify-between text-[10px] text-amber-400/70 font-mono">
                <span>Characters: {noteContent.length}</span>
                <span>Lines: {noteContent.split('\n').length}</span>
              </div>
            </div>
          )}

          {/* CALCULATOR */}
          {activeTask === 'calculator' && (
            <div className="flex flex-col gap-2">
              <div className="p-3 bg-neutral-950 border border-neutral-800 rounded text-right font-mono text-lg font-bold text-amber-300 tracking-wider overflow-x-auto">
                {calcInput}
              </div>
              <div className="grid grid-cols-4 gap-1.5 text-xs font-orbitron">
                {['C', '/', '*', '-', '7', '8', '9', '+', '4', '5', '6', '=', '1', '2', '3', '0'].map((btn) => (
                  <button
                    key={btn}
                    onClick={() => handleCalcBtn(btn)}
                    className={`p-2.5 rounded font-bold transition-all cursor-pointer ${
                      btn === '='
                        ? 'bg-amber-500 text-black hover:bg-amber-400 col-span-1'
                        : btn === 'C'
                        ? 'bg-red-950/60 text-red-300 border border-red-500/40 hover:bg-red-900/60'
                        : ['+', '-', '*', '/'].includes(btn)
                        ? 'bg-amber-950/50 text-amber-300 border border-amber-500/40 hover:bg-amber-900/60'
                        : 'bg-neutral-900 text-slate-200 border border-neutral-800 hover:border-amber-500/40'
                    }`}
                  >
                    {btn}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* BROWSER / FAST CLIENT */}
          {activeTask === 'browser' && (
            <div className="flex flex-col gap-2 text-xs">
              <div className="flex items-center gap-1.5 p-1.5 bg-neutral-950 border border-neutral-800 rounded font-mono text-[11px] text-amber-300">
                <Search className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="truncate flex-1">
                  {taskData?.url || `https://www.google.com/search?q=${encodeURIComponent(taskData?.query || 'fast client')}`}
                </span>
                <a
                  href={taskData?.url || `https://www.google.com/search?q=${encodeURIComponent(taskData?.query || 'fast client')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="p-1 hover:text-white"
                  title="Open in new browser tab"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-amber-400" />
                </a>
              </div>
              <div className="p-3 bg-neutral-950/90 border border-neutral-800 rounded text-center py-6 flex flex-col items-center gap-2">
                <Globe className="w-8 h-8 text-amber-400 animate-pulse" />
                <div className="font-orbitron text-xs text-amber-200">
                  Navigated to '{taskData?.query || 'fast client'}'
                </div>
                <p className="text-[11px] text-slate-400 max-w-xs">
                  Search query executed. Click the link above to view in your main browser window.
                </p>
              </div>
            </div>
          )}

          {/* SCREENSHOT */}
          {activeTask === 'screenshot' && (
            <div className="flex flex-col gap-2">
              <div className="relative rounded border border-amber-500/40 overflow-hidden bg-neutral-950 p-2 text-center">
                <div className="w-full h-32 bg-gradient-to-br from-neutral-900 via-neutral-950 to-amber-950/40 rounded flex items-center justify-center border border-dashed border-amber-500/30">
                  <div className="flex flex-col items-center gap-1 text-amber-300">
                    <Camera className="w-6 h-6 text-amber-400 animate-bounce" />
                    <span className="text-[11px] font-mono">Capture Stored in Pictures/Screenshots</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TERMINAL */}
          {activeTask === 'terminal' && (
            <div className="flex flex-col gap-1.5 font-mono text-[11px] bg-black p-2.5 rounded border border-neutral-800">
              <div className="text-emerald-400">Windows PowerShell [Version 10.0.22631.3296]</div>
              <div className="text-slate-400">PS C:\Users\Admin&gt; {taskData?.command || 'Get-Process | Select-Object -First 5'}</div>
              <div className="text-amber-200/90 whitespace-pre-wrap bg-neutral-950 p-2 rounded max-h-36 overflow-y-auto">
                {taskData?.output || 'Handles  NPM(K)    PM(K)      WS(K)     CPU(s)     Id  ProcessName\n-------  ------    -----      -----     ------     --  -----------\n    240      14     4212      15420       0.14   1428  jarvis_daemon\n    512      32    18400      42180       1.25   3892  chrome\n    180      10     2100       8940       0.05   4104  notepad'}
              </div>
            </div>
          )}

          {/* INTELLIGENCE DOSSIER (General AI answers without blocking center sphere!) */}
          {activeTask === 'intelligence' && (
            <div className="flex flex-col gap-2 max-h-80 overflow-y-auto pr-1">
              <div className="text-xs text-amber-100 font-sans leading-relaxed whitespace-pre-wrap">
                {taskData?.text || 'All systems operational, sir. How may I be of service?'}
              </div>
            </div>
          )}

          {/* SYSTEM INFO & TELEMETRY */}
          {activeTask === 'system_info' && (
            <div className="flex flex-col gap-2.5 text-xs font-mono">
              {/* Power & Battery Status Card */}
              <div className="p-2.5 bg-amber-950/40 border border-amber-500/40 rounded-lg space-y-1.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-amber-300 font-semibold text-xs">
                    <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400 animate-pulse" />
                    <span>POWER & BATTERY MONITOR</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {taskData?.batteryLevel ?? 88}%
                  </span>
                </div>
                <div className="w-full bg-neutral-900 h-2 rounded-full overflow-hidden border border-neutral-800">
                  <div 
                    className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full transition-all duration-500" 
                    style={{ width: `${taskData?.batteryLevel ?? 88}%` }} 
                  />
                </div>
                <div className="flex justify-between text-[10px] pt-0.5">
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    {taskData?.isCharging !== false ? '⚡ AC CHARGER CONNECTED (CHARGING)' : 'DISCHARGING ON BATTERY'}
                  </span>
                  <span className="text-slate-400">Health: Optimal</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2 bg-neutral-950 border border-neutral-800 rounded">
                  <div className="flex items-center gap-1.5 text-slate-400 text-[10px]">
                    <Cpu className="w-3 h-3 text-emerald-400" />
                    <span>CPU LOAD</span>
                  </div>
                  <div className="text-emerald-400 font-bold text-sm mt-0.5">{taskData?.cpu || '18'}%</div>
                  <div className="w-full bg-neutral-800 h-1 rounded-full mt-1 overflow-hidden">
                    <div className="bg-emerald-400 h-full" style={{ width: `${taskData?.cpu || 18}%` }} />
                  </div>
                </div>

                <div className="p-2 bg-neutral-950 border border-neutral-800 rounded">
                  <div className="flex items-center gap-1.5 text-slate-400 text-[10px]">
                    <HardDrive className="w-3 h-3 text-amber-400" />
                    <span>RAM USED</span>
                  </div>
                  <div className="text-amber-300 font-bold text-sm mt-0.5">{taskData?.ram || '5.8 / 16 GB'}</div>
                  <div className="w-full bg-neutral-800 h-1 rounded-full mt-1 overflow-hidden">
                    <div className="bg-amber-400 h-full w-[42%]" />
                  </div>
                </div>
              </div>

              <div className="p-2 bg-neutral-950 border border-neutral-800 rounded text-[11px] space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>OS Platform:</span>
                  <span className="text-amber-200">{taskData?.os || 'Windows 11 Pro 64-bit'}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Power Status:</span>
                  <span className="text-emerald-400 font-semibold">{taskData?.isCharging !== false ? 'AC Power (Charging)' : `${taskData?.batteryLevel ?? 88}% Remaining`}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Security Mode:</span>
                  <span className="text-amber-400 font-semibold">GOD MODE (Full Automation)</span>
                </div>
              </div>
            </div>
          )}

          {/* AUDIO MASTER VOLUME */}
          {activeTask === 'volume' && (
            <div className="flex flex-col gap-3 p-1">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Volume2 className="w-5 h-5 text-amber-400 animate-pulse" />
                  <span className="text-xs font-mono text-amber-200">System Volume</span>
                </div>
                <span className="text-sm font-orbitron font-bold text-amber-400">{taskData?.level || 85}%</span>
              </div>
              <div className="w-full bg-neutral-900 h-3 rounded-full overflow-hidden border border-neutral-800 p-0.5">
                <div 
                  className="h-full bg-gradient-to-r from-emerald-500 via-amber-400 to-amber-500 rounded-full transition-all duration-300"
                  style={{ width: `${taskData?.level || 85}%` }}
                />
              </div>
              <div className="text-[10px] text-slate-400 font-mono text-center">
                Master audio hardware channel adjusted
              </div>
            </div>
          )}

          {/* FILE EXPLORER */}
          {activeTask === 'files' && (
            <div className="flex flex-col gap-2 text-xs">
              <div className="flex items-center gap-1.5 p-1.5 bg-neutral-950 border border-neutral-800 rounded font-mono text-[10px] text-slate-300">
                <Folder className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span className="truncate">C:\Users\Admin\{taskData?.folder || 'Documents'}</span>
              </div>
              <div className="space-y-1 max-h-40 overflow-y-auto pr-1 font-mono text-[11px]">
                {['Report_2026.docx', 'Project_Jarvis_Specs.pdf', 'Workstation_Config.json', 'Personal_Notes.txt'].map((f, i) => (
                  <div key={i} className="flex items-center justify-between p-1.5 rounded hover:bg-neutral-900/80 text-slate-300">
                    <span className="truncate">{f}</span>
                    <span className="text-[10px] text-slate-500">File</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
