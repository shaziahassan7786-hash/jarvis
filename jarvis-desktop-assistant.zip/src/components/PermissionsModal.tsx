import React from 'react';
import { Shield, ShieldAlert, ShieldCheck, Check, X, Lock } from 'lucide-react';
import { PermissionItem, RiskLevel } from '../types';

interface PermissionsModalProps {
  isOpen: boolean;
  permissions: PermissionItem[];
  onTogglePermission: (id: string) => void;
  onClose: () => void;
}

export const PermissionsModal: React.FC<PermissionsModalProps> = ({
  isOpen,
  permissions,
  onTogglePermission,
  onClose,
}) => {
  if (!isOpen) return null;

  const getRiskBadge = (risk: RiskLevel) => {
    switch (risk) {
      case 'LOW':
        return 'bg-emerald-950/80 text-emerald-400 border-emerald-700/60';
      case 'MEDIUM':
        return 'bg-amber-950/80 text-amber-400 border-amber-700/60';
      case 'HIGH':
        return 'bg-red-950/80 text-red-400 border-red-700/60';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-cyan-500/40 rounded-xl p-6 shadow-[0_0_40px_rgba(0,229,255,0.2)] max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-cyan-950/70 border border-cyan-500/40 rounded-lg text-cyan-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-orbitron font-bold text-white tracking-wide">
                JARVIS OS Permissions & Security
              </h2>
              <p className="text-xs text-slate-400">
                Grant or revoke computer control capabilities. OS permissions are strictly enforced.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Informative Security Notice */}
        <div className="my-4 p-3 bg-cyan-950/30 border border-cyan-500/20 rounded-lg text-xs text-cyan-200/90 leading-relaxed flex items-start gap-2.5">
          <Lock className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <span>
            JARVIS utilizes the operating system's normal permission mechanisms. It never bypasses Windows UAC, antivirus heuristics, application sandboxes, or user credentials.
          </span>
        </div>

        {/* Permissions List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
          {permissions.map((perm) => (
            <div
              key={perm.id}
              className="flex items-center justify-between p-3.5 bg-slate-950/60 border border-cyan-500/15 hover:border-cyan-500/40 rounded-lg transition-all"
            >
              <div className="flex-1 pr-4">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-orbitron text-xs font-semibold text-white">
                    {perm.name}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[9px] font-mono-code font-bold border ${getRiskBadge(
                      perm.risk
                    )}`}
                  >
                    {perm.risk} RISK
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono-code">
                    [{perm.category}]
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-normal">{perm.description}</p>
              </div>

              {/* Toggle Switch */}
              <button
                onClick={() => onTogglePermission(perm.id)}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  perm.granted ? 'bg-cyan-500 shadow-[0_0_10px_rgba(0,229,255,0.6)]' : 'bg-slate-800'
                }`}
                role="switch"
                aria-checked={perm.granted}
              >
                <span
                  aria-hidden="true"
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                    perm.granted ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-4 mt-4 border-t border-cyan-500/20 flex items-center justify-between text-xs text-slate-400">
          <span>Revoking a permission prevents the AI from calling corresponding tools.</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-orbitron font-bold rounded-lg transition-colors cursor-pointer"
          >
            DONE
          </button>
        </div>
      </div>
    </div>
  );
};
