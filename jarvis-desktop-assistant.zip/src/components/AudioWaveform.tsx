import React from 'react';
import { JarvisState } from '../types';

interface AudioWaveformProps {
  state: JarvisState;
  audioLevel: number;
  isMuted: boolean;
}

export const AudioWaveform: React.FC<AudioWaveformProps> = ({ state, audioLevel, isMuted }) => {
  const barCount = 32;

  return (
    <div className="flex items-center justify-center gap-[3px] h-12 px-4 py-2 bg-slate-900/60 backdrop-blur-md rounded-lg border border-cyan-500/20">
      {Array.from({ length: barCount }).map((_, i) => {
        // Compute dynamic height based on state and audioLevel
        const centerDistance = Math.abs(i - barCount / 2) / (barCount / 2);
        let height = 12;

        if (isMuted) {
          height = 4;
        } else if (state === 'LISTENING') {
          const wave = Math.sin(Date.now() / 150 + i * 0.4) * 0.5 + 0.5;
          height = Math.max(6, (audioLevel * 48 * (1 - centerDistance * 0.5) + wave * 16));
        } else if (state === 'SPEAKING') {
          const wave = Math.sin(Date.now() / 100 + i * 0.6) * 0.5 + 0.5;
          height = Math.max(8, 36 * wave * (1 - centerDistance * 0.3));
        } else if (state === 'THINKING') {
          const wave = Math.sin(Date.now() / 180 + i * 0.8) * 0.5 + 0.5;
          height = Math.max(6, 20 * wave);
        } else if (state === 'ERROR') {
          height = 6;
        } else {
          // IDLE gentle breathing wave
          const wave = Math.sin(Date.now() / 400 + i * 0.3) * 0.5 + 0.5;
          height = 6 + wave * 8;
        }

        const barColor = isMuted 
          ? 'bg-slate-700' 
          : state === 'ERROR' 
          ? 'bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)]' 
          : state === 'THINKING'
          ? 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]'
          : 'bg-cyan-400 shadow-[0_0_8px_rgba(0,229,255,0.6)]';

        return (
          <div
            key={i}
            className={`w-[3px] rounded-full transition-all duration-75 ${barColor}`}
            style={{ height: `${Math.min(44, Math.max(4, height))}px` }}
          />
        );
      })}
    </div>
  );
};
