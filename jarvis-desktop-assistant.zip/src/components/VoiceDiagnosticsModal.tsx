import React, { useState } from 'react';
import { 
  X, 
  Mic, 
  MicOff, 
  Volume2, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  Play, 
  Terminal,
  Sparkles,
  HelpCircle
} from 'lucide-react';
import { jarvisSound } from '../soundFx';

interface VoiceDiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  micEnabled: boolean;
  wakeWordActive: boolean;
  speechRecognitionSupported: boolean;
  micPermissionStatus: 'prompt' | 'granted' | 'denied' | 'unknown';
  onRequestMicPermission: () => Promise<void>;
  onTestVoice: () => void;
  onSimulateVoiceCommand: (cmd: string) => void;
}

export const VoiceDiagnosticsModal: React.FC<VoiceDiagnosticsModalProps> = ({
  isOpen,
  onClose,
  micEnabled,
  wakeWordActive,
  speechRecognitionSupported,
  micPermissionStatus,
  onRequestMicPermission,
  onTestVoice,
  onSimulateVoiceCommand,
}) => {
  const [requesting, setRequesting] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleMicRequest = async () => {
    setRequesting(true);
    setStatusMsg(null);
    try {
      await onRequestMicPermission();
      setStatusMsg('Microphone access verified successfully!');
      jarvisSound.playSuccessTone();
    } catch (err: any) {
      setStatusMsg(`Permission request failed: ${err.message || 'Permission denied'}`);
      jarvisSound.playAlertTone();
    } finally {
      setRequesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-lg bg-slate-900 border border-cyan-500/40 rounded-xl shadow-[0_0_40px_rgba(0,229,255,0.25)] overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-slate-950 border-b border-cyan-500/30">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-cyan-950 border border-cyan-500/50 text-cyan-400">
              <HelpCircle className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-orbitron font-bold text-white tracking-wider">
                VOICE & HARDWARE DIAGNOSTICS
              </h2>
              <p className="text-[10px] text-slate-400 font-mono-code">
                Verify speech recognition, microphone permissions, and vocal synthesizer
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4 overflow-y-auto font-sans">
          {/* Diagnostic Status Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* 1. Speech Recognition API */}
            <div className="p-3 bg-slate-950/80 rounded-lg border border-cyan-500/20 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-mono-code text-slate-300">Web Speech API</span>
                {speechRecognitionSupported ? (
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-950 text-emerald-400 border border-emerald-700 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> READY
                  </span>
                ) : (
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-amber-950 text-amber-400 border border-amber-700 flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3" /> FALLBACK
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 font-mono-code">
                {speechRecognitionSupported
                  ? 'Browser supports continuous voice recognition.'
                  : 'Speech API not active in this browser. Use buttons or typing.'}
              </p>
            </div>

            {/* 2. Microphone Permission */}
            <div className="p-3 bg-slate-950/80 rounded-lg border border-cyan-500/20 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-mono-code text-slate-300">Microphone Input</span>
                {micEnabled ? (
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-emerald-950 text-emerald-400 border border-emerald-700 flex items-center gap-1">
                    <Mic className="w-3 h-3" /> ACTIVE
                  </span>
                ) : (
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-red-950 text-red-400 border border-red-700 flex items-center gap-1">
                    <MicOff className="w-3 h-3" /> MUTED
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 font-mono-code">
                Status: {micPermissionStatus.toUpperCase()}
              </p>
            </div>
          </div>

          {/* Action Row */}
          <div className="flex flex-wrap gap-2.5">
            <button
              onClick={handleMicRequest}
              disabled={requesting}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-orbitron font-bold text-xs rounded-lg transition-all cursor-pointer shadow-[0_0_15px_rgba(0,229,255,0.3)] disabled:opacity-50"
            >
              <Mic className="w-4 h-4" />
              <span>{requesting ? 'REQUESTING PERMISSION...' : 'AUTHORIZE MICROPHONE'}</span>
            </button>

            <button
              onClick={() => {
                jarvisSound.playWakeChime();
                onTestVoice();
              }}
              className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-orbitron font-bold text-xs rounded-lg border border-cyan-500/30 transition-all cursor-pointer"
            >
              <Volume2 className="w-4 h-4 text-cyan-400" />
              <span>TEST VOCAL AUDIO</span>
            </button>
          </div>

          {statusMsg && (
            <div className="p-2.5 bg-slate-950 rounded border border-cyan-500/30 text-xs font-mono-code text-cyan-300">
              {statusMsg}
            </div>
          )}

          {/* Instant 1-Click Spoken Voice Simulation */}
          <div className="pt-2 border-t border-cyan-500/20">
            <div className="flex items-center gap-2 text-xs font-orbitron font-semibold text-slate-200 mb-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>INSTANT VOICE SIMULATOR (NO MIC REQUIRED)</span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono-code mb-2.5">
              Click any phrase below to simulate speaking it directly to JARVIS with full audio and tool execution:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
              {[
                'Hey Jarvis, open YouTube',
                'Hey Jarvis, open Notepad',
                'Hey Jarvis, take a screenshot',
                'Hey Jarvis, what time is it?',
                'Hey Jarvis, search Python tutorials',
                'Hey Jarvis, mute the computer',
              ].map((cmd, i) => (
                <button
                  key={i}
                  onClick={() => {
                    onSimulateVoiceCommand(cmd);
                    onClose();
                  }}
                  className="text-left px-3 py-2 bg-slate-950 hover:bg-cyan-950/70 border border-cyan-500/20 hover:border-cyan-400/60 rounded text-xs font-mono-code text-slate-300 hover:text-cyan-200 transition-all cursor-pointer flex items-center justify-between"
                >
                  <span className="truncate">"{cmd}"</span>
                  <Play className="w-3 h-3 text-cyan-400 ml-1 flex-shrink-0" />
                </button>
              ))}
            </div>
          </div>

          {/* Running on Real Windows Desktop */}
          <div className="p-3 bg-cyan-950/40 rounded-lg border border-cyan-500/30 text-xs">
            <div className="font-orbitron font-bold text-cyan-300 mb-1 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5" />
              RUNNING ON YOUR WINDOWS PC
            </div>
            <p className="text-[11px] text-slate-300 font-mono-code leading-relaxed">
              To have JARVIS control your actual local Windows desktop (launch local Notepad.exe, adjust hardware master volume, take native screenshots), download the Python package from the header <span className="text-cyan-300 font-bold">PYTHON CODE & ZIP</span> button and run <code className="text-cyan-300 bg-slate-900 px-1 py-0.5 rounded">python -m jarvis.main</code>.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end px-5 py-3 bg-slate-950 border-t border-cyan-500/30">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs font-orbitron cursor-pointer"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
