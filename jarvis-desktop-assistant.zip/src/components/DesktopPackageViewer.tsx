import React, { useState, useEffect } from 'react';
import { 
  Folder, 
  FileCode, 
  Download, 
  Copy, 
  Check, 
  X, 
  Terminal, 
  ExternalLink, 
  ShieldCheck, 
  Monitor, 
  Laptop, 
  Zap, 
  Play, 
  Info,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import JSZip from 'jszip';

interface PythonFile {
  path: string;
  name: string;
  content: string;
}

interface DesktopPackageViewerProps {
  isOpen?: boolean;
  onClose: () => void;
  localBridgeConnected?: boolean;
}

export const DesktopPackageViewer: React.FC<DesktopPackageViewerProps> = ({ 
  isOpen = true, 
  onClose,
  localBridgeConnected = false
}) => {
  const [activeTab, setActiveTab] = useState<'quickstart' | 'pwa' | 'standalone' | 'files'>('quickstart');
  const [files, setFiles] = useState<PythonFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<PythonFile | null>(null);
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isOpen) return;

    fetch('/api/python-files')
      .then((res) => res.json())
      .then((data) => {
        if (data.files && Array.isArray(data.files)) {
          setFiles(data.files);
          if (data.files.length > 0) {
            const mainOrReadme = data.files.find((f: PythonFile) => f.name === 'README.md') || data.files[0];
            setSelectedFile(mainOrReadme);
          }
        }
      })
      .catch((err) => console.error('Failed to load python files', err))
      .finally(() => setLoading(false));
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCopyCode = (text?: string) => {
    const toCopy = text || selectedFile?.content || '';
    if (!toCopy) return;
    navigator.clipboard.writeText(toCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setDownloading(true);
    try {
      const zip = new JSZip();
      files.forEach((f) => {
        zip.file(f.path, f.content);
      });

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'jarvis-pc-desktop-package.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Failed to generate zip', e);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl bg-neutral-950 border border-amber-500/50 rounded-2xl p-6 shadow-[0_0_50px_rgba(255,140,0,0.25)] h-[88vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-amber-500/20">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-950/80 border border-amber-500/50 rounded-xl text-amber-400">
              <Monitor className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-orbitron font-bold text-amber-200 tracking-wide">
                  RUN JARVIS ON YOUR WINDOWS PC
                </h2>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border flex items-center gap-1 ${
                  localBridgeConnected 
                    ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40' 
                    : 'bg-amber-950/80 text-amber-400 border-amber-500/40'
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${localBridgeConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                  {localBridgeConnected ? 'REAL PC BRIDGE CONNECTED' : 'BROWSER SIMULATION MODE'}
                </span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Execute real Windows tasks: launch <code className="text-amber-300">notepad.exe</code>, <code className="text-amber-300">calc.exe</code>, control volume, & type into active windows.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadZip}
              disabled={downloading || files.length === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-black font-orbitron font-bold text-xs rounded-lg shadow-[0_0_15px_rgba(255,140,0,0.3)] transition-all cursor-pointer disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{downloading ? 'PACKAGING...' : 'DOWNLOAD FULL ZIP'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 pt-3 border-b border-neutral-800">
          <button
            onClick={() => setActiveTab('quickstart')}
            className={`flex items-center gap-1.5 px-4 py-2 border-b-2 text-xs font-orbitron font-semibold transition-all cursor-pointer ${
              activeTab === 'quickstart'
                ? 'border-amber-400 text-amber-300 bg-amber-950/20'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>1-CLICK PC BRIDGE (EASIEST)</span>
          </button>
          <button
            onClick={() => setActiveTab('pwa')}
            className={`flex items-center gap-1.5 px-4 py-2 border-b-2 text-xs font-orbitron font-semibold transition-all cursor-pointer ${
              activeTab === 'pwa'
                ? 'border-amber-400 text-amber-300 bg-amber-950/20'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Laptop className="w-3.5 h-3.5" />
            <span>INSTALL DESKTOP APP (PWA)</span>
          </button>
          <button
            onClick={() => setActiveTab('standalone')}
            className={`flex items-center gap-1.5 px-4 py-2 border-b-2 text-xs font-orbitron font-semibold transition-all cursor-pointer ${
              activeTab === 'standalone'
                ? 'border-amber-400 text-amber-300 bg-amber-950/20'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>BUILD STANDALONE JARVIS.EXE</span>
          </button>
          <button
            onClick={() => setActiveTab('files')}
            className={`flex items-center gap-1.5 px-4 py-2 border-b-2 text-xs font-orbitron font-semibold transition-all cursor-pointer ${
              activeTab === 'files'
                ? 'border-amber-400 text-amber-300 bg-amber-950/20'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Folder className="w-3.5 h-3.5" />
            <span>PROJECT SOURCE FILES ({files.length})</span>
          </button>
        </div>

        {/* Tab 1: 1-Click PC Bridge */}
        {activeTab === 'quickstart' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {/* Why browser didn't open local notepad explanation */}
            <div className="bg-amber-950/30 border border-amber-500/40 rounded-xl p-4 flex items-start gap-3">
              <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div className="text-xs text-amber-100/90 space-y-1">
                <p className="font-semibold text-amber-300 text-sm">
                  Why didn't real Notepad open directly on your Windows desktop from the browser?
                </p>
                <p>
                  Web browsers (Chrome/Edge) run web pages in an isolated security sandbox. Chrome prevents websites on the internet from secretly executing <code className="bg-black/60 px-1 py-0.5 rounded text-amber-300">.exe</code> programs on your PC without your permission.
                </p>
                <p>
                  <strong>When JARVIS is running on your PC or connected to this 1-click bridge:</strong> It has 100% unrestricted God-Mode permissions to launch real <code className="bg-black/60 px-1 py-0.5 rounded text-amber-300">notepad.exe</code>, real <code className="bg-black/60 px-1 py-0.5 rounded text-amber-300">calc.exe</code>, type directly into whatever window is open on your screen, and change your actual PC speakers volume!
                </p>
              </div>
            </div>

            {/* 3 Simple Steps */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Step 1 */}
              <div className="bg-neutral-900/90 border border-neutral-800 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-400 font-bold font-orbitron flex items-center justify-center text-xs mb-3 border border-amber-500/40">
                    1
                  </div>
                  <h3 className="font-orbitron font-semibold text-amber-200 text-xs mb-1">
                    Download 1-Click Launcher
                  </h3>
                  <p className="text-[11px] text-neutral-400 mb-3">
                    Download the pre-configured Windows batch file and Python bridge to your PC.
                  </p>
                </div>
                <div className="space-y-2">
                  <a
                    href="/api/download/run_jarvis_admin.bat"
                    download="run_jarvis_admin.bat"
                    className="flex items-center justify-center gap-1.5 w-full py-2 bg-amber-500 hover:bg-amber-400 text-black font-orbitron font-bold text-xs rounded-lg transition-all"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download .BAT Launcher</span>
                  </a>
                  <a
                    href="/api/download/local_bridge.py"
                    download="local_bridge.py"
                    className="flex items-center justify-center gap-1.5 w-full py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-mono text-[11px] rounded-lg border border-neutral-700 transition-colors"
                  >
                    <Download className="w-3 h-3 text-amber-400" />
                    <span>Download local_bridge.py</span>
                  </a>
                </div>
              </div>

              {/* Step 2 */}
              <div className="bg-neutral-900/90 border border-neutral-800 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-400 font-bold font-orbitron flex items-center justify-center text-xs mb-3 border border-amber-500/40">
                    2
                  </div>
                  <h3 className="font-orbitron font-semibold text-amber-200 text-xs mb-1">
                    Double-Click to Run
                  </h3>
                  <p className="text-[11px] text-neutral-400 mb-2">
                    Put both files in the same folder and double-click <code className="text-amber-300">run_jarvis_admin.bat</code>.
                  </p>
                  <div className="bg-black p-2 rounded text-[10px] font-mono text-emerald-400 border border-neutral-800">
                    <div>JARVIS PC BRIDGE ACTIVE</div>
                    <div className="text-neutral-500">http://127.0.0.1:4999</div>
                    <div className="text-neutral-400">All permissions granted.</div>
                  </div>
                </div>
                <p className="text-[10px] text-neutral-500 mt-2">
                  Keep the black command window open in the background while using JARVIS.
                </p>
              </div>

              {/* Step 3 */}
              <div className="bg-neutral-900/90 border border-neutral-800 rounded-xl p-4 flex flex-col justify-between">
                <div>
                  <div className="w-7 h-7 rounded-full bg-amber-500/20 text-amber-400 font-bold font-orbitron flex items-center justify-center text-xs mb-3 border border-amber-500/40">
                    3
                  </div>
                  <h3 className="font-orbitron font-semibold text-amber-200 text-xs mb-1">
                    Say "Notepad Kholo"
                  </h3>
                  <p className="text-[11px] text-neutral-400 mb-3">
                    Speak or type any command. Watch the real application open immediately on your Windows desktop!
                  </p>
                  <div className="space-y-1 text-[11px] font-mono text-amber-300/80">
                    <div>• "notepad kholo" &rarr; opens real notepad.exe</div>
                    <div>• "calculator chalao" &rarr; opens real calc.exe</div>
                    <div>• "likho hello world" &rarr; types in window</div>
                    <div>• "awaz badhao" &rarr; increases PC volume</div>
                  </div>
                </div>
                <div className="mt-3 p-2 bg-emerald-950/40 border border-emerald-500/30 rounded text-[11px] text-emerald-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Zero latency execution</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: PWA Install */}
        {activeTab === 'pwa' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-xl p-5 space-y-3">
              <h3 className="font-orbitron font-bold text-amber-200 text-sm flex items-center gap-2">
                <Laptop className="w-4 h-4 text-amber-400" />
                <span>Install JARVIS as a Dedicated Windows Desktop App</span>
              </h3>
              <p className="text-xs text-neutral-300 leading-relaxed">
                You can install JARVIS directly into Windows with zero compilation using Progressive Web App (PWA) technology supported in Chrome, Edge, and Brave.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3 bg-black/60 border border-neutral-800 rounded-lg space-y-1.5">
                  <div className="text-xs font-semibold text-amber-300">In Google Chrome:</div>
                  <ol className="list-decimal list-inside text-xs text-neutral-400 space-y-1">
                    <li>Look at the right side of the address bar at the top</li>
                    <li>Click the <strong>Install JARVIS</strong> icon (computer with down arrow)</li>
                    <li>Click <strong>Install</strong></li>
                    <li>JARVIS is now a desktop app with its own taskbar icon and window!</li>
                  </ol>
                </div>

                <div className="p-3 bg-black/60 border border-neutral-800 rounded-lg space-y-1.5">
                  <div className="text-xs font-semibold text-amber-300">In Microsoft Edge:</div>
                  <ol className="list-decimal list-inside text-xs text-neutral-400 space-y-1">
                    <li>Click the <strong>...</strong> (three dots) menu in top right</li>
                    <li>Go to <strong>Apps</strong> &rarr; <strong>Install JARVIS</strong></li>
                    <li>Check "Pin to Taskbar" and "Create Desktop Shortcut"</li>
                    <li>Launches like native Windows software!</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Build Standalone JARVIS.exe */}
        {activeTab === 'standalone' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            <div className="bg-neutral-900/90 border border-neutral-800 rounded-xl p-5 space-y-3">
              <h3 className="font-orbitron font-bold text-amber-200 text-sm flex items-center gap-2">
                <Terminal className="w-4 h-4 text-amber-400" />
                <span>Build Standalone JARVIS.exe Executable with PyInstaller</span>
              </h3>
              <p className="text-xs text-neutral-300">
                This project includes complete native Python code with wake-word detection, system tray widget, audio synthesis, and a 1-click builder script.
              </p>

              <div className="space-y-2">
                <div className="text-xs font-semibold text-amber-300 font-mono">Commands to build JARVIS.exe on Windows:</div>
                <div className="bg-black p-3 rounded-lg border border-neutral-800 font-mono text-xs text-amber-100/90 relative group">
                  <pre className="overflow-x-auto whitespace-pre">
{`# 1. Download the full ZIP package and extract it
# 2. Open terminal in the extracted folder and run:
pip install -r requirements.txt

# 3. Compile standalone JARVIS.exe:
build_exe.bat

# Standalone executable will be created in:
dist/JARVIS/JARVIS.exe`}
                  </pre>
                  <button
                    onClick={() => handleCopyCode(`pip install -r requirements.txt\nbuild_exe.bat`)}
                    className="absolute top-2 right-2 p-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded text-xs transition-colors flex items-center gap-1"
                  >
                    {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: File Browser */}
        {activeTab === 'files' && (
          <div className="flex-1 flex overflow-hidden my-3 border border-amber-500/20 rounded-lg bg-neutral-950">
            {/* File Tree Sidebar */}
            <div className="w-64 border-r border-amber-500/20 bg-neutral-950/70 p-3 overflow-y-auto space-y-1">
              <div className="text-[10px] font-mono text-amber-400/80 uppercase tracking-wider mb-2 flex items-center gap-1">
                <Folder className="w-3.5 h-3.5 text-amber-400" />
                <span>Source Files ({files.length})</span>
              </div>

              {loading ? (
                <div className="text-xs text-neutral-500 p-2 font-mono">Loading files...</div>
              ) : (
                files.map((file) => (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-2 py-1.5 rounded text-xs font-mono transition-colors flex items-center gap-2 truncate cursor-pointer ${
                      selectedFile?.path === file.path
                        ? 'bg-amber-950 text-amber-300 border border-amber-500/40'
                        : 'text-neutral-400 hover:bg-neutral-900 hover:text-neutral-200'
                    }`}
                    title={file.path}
                  >
                    <FileCode className="w-3.5 h-3.5 shrink-0 text-amber-400/70" />
                    <span className="truncate">{file.path}</span>
                  </button>
                ))
              )}
            </div>

            {/* Code Viewer Panel */}
            <div className="flex-1 flex flex-col bg-neutral-950 overflow-hidden">
              {selectedFile ? (
                <>
                  <div className="flex items-center justify-between px-4 py-2 bg-neutral-900/80 border-b border-amber-500/20 text-xs">
                    <div className="font-mono text-amber-300 font-semibold flex items-center gap-2">
                      <span>{selectedFile.path}</span>
                      <span className="text-[10px] text-neutral-500 font-normal">
                        ({selectedFile.content.split('\n').length} lines)
                      </span>
                    </div>
                    <button
                      onClick={() => handleCopyCode(selectedFile.content)}
                      className="flex items-center gap-1 text-[11px] text-neutral-400 hover:text-amber-300 transition-colors"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                  <div className="flex-1 p-4 overflow-auto font-mono text-xs text-amber-100/90 leading-relaxed">
                    <pre className="whitespace-pre">{selectedFile.content}</pre>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center text-neutral-500 text-xs font-mono">
                  Select a file from the sidebar to inspect
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
