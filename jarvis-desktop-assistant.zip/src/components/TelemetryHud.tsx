import React, { useState, useEffect } from 'react';
import { 
  Cpu, 
  HardDrive, 
  Wifi, 
  Clock, 
  Battery, 
  BatteryCharging, 
  BatteryWarning, 
  Zap, 
  Plug 
} from 'lucide-react';
import { SystemTelemetry } from '../types';

interface TelemetryHudProps {
  telemetry: SystemTelemetry;
}

export const TelemetryHud: React.FC<TelemetryHudProps> = ({ telemetry }) => {
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setCurrentDate(now.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const batteryLevel = typeof telemetry.batteryLevel === 'number' ? telemetry.batteryLevel : 88;
  const isCharging = telemetry.isCharging ?? true;
  const powerSource = telemetry.powerSource || (isCharging ? 'AC' : 'BATTERY');

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 w-full">
      {/* 1. CPU Telemetry */}
      <div className="bg-slate-900/70 border border-cyan-500/20 rounded-lg p-3 backdrop-blur-md relative overflow-hidden group hover:border-cyan-400/50 transition-colors">
        <div className="flex items-center justify-between text-xs text-cyan-400/70 mb-1.5 font-orbitron tracking-wider">
          <span className="flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            CPU LOAD
          </span>
          <span className="font-mono-code font-bold text-cyan-300">{telemetry.cpuUsage}%</span>
        </div>
        <div className="w-full bg-slate-800/80 rounded-full h-1.5 overflow-hidden">
          <div
            className={`h-full transition-all duration-500 ${
              telemetry.cpuUsage > 80 ? 'bg-red-500' : telemetry.cpuUsage > 50 ? 'bg-amber-400' : 'bg-cyan-400'
            }`}
            style={{ width: `${Math.min(100, telemetry.cpuUsage)}%` }}
          />
        </div>
        <div className="mt-1.5 text-[10px] text-slate-400 font-mono-code flex justify-between">
          <span>CORES: 8 ACTIVE</span>
          <span>TEMP: 42°C</span>
        </div>
      </div>

      {/* 2. RAM Telemetry */}
      <div className="bg-slate-900/70 border border-cyan-500/20 rounded-lg p-3 backdrop-blur-md relative overflow-hidden group hover:border-cyan-400/50 transition-colors">
        <div className="flex items-center justify-between text-xs text-cyan-400/70 mb-1.5 font-orbitron tracking-wider">
          <span className="flex items-center gap-1.5">
            <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
            RAM USAGE
          </span>
          <span className="font-mono-code font-bold text-cyan-300">{telemetry.ramPercent}%</span>
        </div>
        <div className="w-full bg-slate-800/80 rounded-full h-1.5 overflow-hidden">
          <div
            className={`h-full transition-all duration-500 ${
              telemetry.ramPercent > 85 ? 'bg-red-500' : telemetry.ramPercent > 65 ? 'bg-amber-400' : 'bg-cyan-400'
            }`}
            style={{ width: `${Math.min(100, telemetry.ramPercent)}%` }}
          />
        </div>
        <div className="mt-1.5 text-[10px] text-slate-400 font-mono-code flex justify-between">
          <span>{telemetry.ramUsedGb} GB USED</span>
          <span>{telemetry.ramTotalGb} GB TOTAL</span>
        </div>
      </div>

      {/* 3. Power & Battery Status (Requested Feature) */}
      <div 
        id="hud-power-status"
        className={`bg-slate-900/70 border rounded-lg p-3 backdrop-blur-md relative overflow-hidden group transition-all duration-300 ${
          telemetry.healthHighlight 
            ? 'border-amber-400 ring-2 ring-amber-400/40 shadow-[0_0_15px_rgba(255,140,0,0.3)]' 
            : 'border-cyan-500/20 hover:border-amber-400/50'
        }`}
      >
        <div className="flex items-center justify-between text-xs text-amber-400/90 mb-1.5 font-orbitron tracking-wider">
          <span className="flex items-center gap-1.5 font-semibold text-amber-300">
            {isCharging ? (
              <BatteryCharging className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            ) : batteryLevel < 20 ? (
              <BatteryWarning className="w-3.5 h-3.5 text-red-400 animate-bounce" />
            ) : (
              <Battery className="w-3.5 h-3.5 text-amber-400" />
            )}
            POWER STATUS
          </span>
          <span className="font-mono-code font-bold text-amber-200 flex items-center gap-0.5">
            {isCharging && <Zap className="w-3 h-3 text-amber-400 fill-amber-400 inline" />}
            {batteryLevel}%
          </span>
        </div>
        <div className="w-full bg-slate-800/80 rounded-full h-1.5 overflow-hidden">
          <div
            className={`h-full transition-all duration-500 ${
              isCharging 
                ? 'bg-gradient-to-r from-amber-500 to-emerald-400' 
                : batteryLevel <= 20 
                  ? 'bg-red-500' 
                  : 'bg-amber-400'
            }`}
            style={{ width: `${Math.min(100, batteryLevel)}%` }}
          />
        </div>
        <div className="mt-1.5 text-[10px] font-mono-code flex justify-between items-center">
          <span className="flex items-center gap-1 text-emerald-400 font-semibold">
            {isCharging ? (
              <>
                <Plug className="w-2.5 h-2.5" />
                <span>CHARGING (AC)</span>
              </>
            ) : (
              <span className="text-neutral-300">DISCHARGING</span>
            )}
          </span>
          <span className="text-amber-300/80">
            {batteryLevel >= 95 && isCharging ? 'FULL' : isCharging ? 'OPTIMAL' : `${batteryLevel}% LEFT`}
          </span>
        </div>
      </div>

      {/* 4. Network Telemetry */}
      <div className="bg-slate-900/70 border border-cyan-500/20 rounded-lg p-3 backdrop-blur-md relative overflow-hidden group hover:border-cyan-400/50 transition-colors">
        <div className="flex items-center justify-between text-xs text-cyan-400/70 mb-1.5 font-orbitron tracking-wider">
          <span className="flex items-center gap-1.5">
            <Wifi className="w-3.5 h-3.5 text-cyan-400" />
            NETWORK
          </span>
          <span className="font-mono-code text-[11px] font-semibold text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            {telemetry.networkStatus}
          </span>
        </div>
        <div className="mt-2 text-[10px] text-slate-300 font-mono-code flex justify-between items-center">
          <span className="text-cyan-400/80">PING: {telemetry.pingMs} ms</span>
          <span className="text-slate-400">UP: 120 Mbps</span>
        </div>
        <div className="text-[10px] text-slate-400 font-mono-code">
          PROT: TLS 1.3 SECURE
        </div>
      </div>

      {/* 5. Military Time & OS */}
      <div className="bg-slate-900/70 border border-cyan-500/20 rounded-lg p-3 backdrop-blur-md relative overflow-hidden group hover:border-cyan-400/50 transition-colors">
        <div className="flex items-center justify-between text-xs text-cyan-400/70 mb-1 font-orbitron tracking-wider">
          <span className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            SYSTEM TIME
          </span>
          <span className="text-[10px] text-slate-400 font-mono-code">UTC-7</span>
        </div>
        <div className="font-orbitron text-base font-bold text-cyan-200 tracking-wider">
          {currentTime || '12:00:00'}
        </div>
        <div className="text-[10px] text-slate-400 font-mono-code truncate">
          {currentDate || 'Loading date...'}
        </div>
      </div>
    </div>
  );
};
