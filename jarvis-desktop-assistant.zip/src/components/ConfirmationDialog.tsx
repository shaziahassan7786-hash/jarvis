import React from 'react';
import { AlertTriangle, ShieldAlert, Check, X } from 'lucide-react';
import { ToolCallExecution } from '../types';

interface ConfirmationDialogProps {
  pendingAction: ToolCallExecution | null;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmationDialog: React.FC<ConfirmationDialogProps> = ({
  pendingAction,
  onConfirm,
  onCancel,
}) => {
  if (!pendingAction) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border-2 border-red-500/80 rounded-xl p-6 shadow-[0_0_50px_rgba(239,68,68,0.4)] glow-red">
        {/* Header with warning badge */}
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 bg-red-950/60 border border-red-500/50 rounded-lg text-red-400">
            <ShieldAlert className="w-8 h-8" />
          </div>
          <div>
            <span className="text-[10px] font-mono-code tracking-widest text-red-400 uppercase font-bold">
              SECURITY LEVEL: HIGH RISK DETECTED
            </span>
            <h2 className="text-xl font-orbitron font-bold text-white tracking-wide">
              Authorization Required
            </h2>
          </div>
        </div>

        {/* Prompt inquiry */}
        <div className="p-4 bg-slate-950/70 border border-red-500/30 rounded-lg mb-4">
          <p className="text-sm font-semibold text-red-200 mb-1">
            "Are you sure you want me to do this?"
          </p>
          <p className="text-xs text-slate-300 leading-relaxed">
            JARVIS has intercepted a high-risk system request. Explicit manual authorization is mandatory to prevent unauthorized modifications.
          </p>
        </div>

        {/* Action Details */}
        <div className="space-y-2 mb-6">
          <div className="flex items-center justify-between text-xs py-1 border-b border-slate-800">
            <span className="text-slate-400">Action:</span>
            <span className="font-mono-code font-bold text-cyan-300">{pendingAction.name}</span>
          </div>
          <div className="flex items-center justify-between text-xs py-1 border-b border-slate-800">
            <span className="text-slate-400">Risk Assessment:</span>
            <span className="px-2 py-0.5 text-[10px] font-bold rounded bg-red-950 text-red-400 border border-red-800">
              HIGH RISK
            </span>
          </div>
          <div className="text-xs py-1">
            <span className="text-slate-400 block mb-1">Parameters:</span>
            <pre className="p-2 bg-slate-950 rounded text-[11px] font-mono-code text-cyan-200 overflow-x-auto max-h-24">
              {JSON.stringify(pendingAction.args, null, 2)}
            </pre>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-3">
          <button
            onClick={onCancel}
            className="flex items-center gap-2 px-4 py-2 text-xs font-orbitron text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
            ABORT (NO)
          </button>
          <button
            onClick={onConfirm}
            className="flex items-center gap-2 px-5 py-2 text-xs font-orbitron font-bold text-white bg-red-600 hover:bg-red-500 rounded-lg shadow-[0_0_15px_rgba(239,68,68,0.5)] transition-all cursor-pointer"
          >
            <Check className="w-4 h-4" />
            AUTHORIZE (YES)
          </button>
        </div>
      </div>
    </div>
  );
};
