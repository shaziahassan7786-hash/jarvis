# JARVIS Desktop Assistant

A fast, low-resource background AI voice assistant inspired by Tony Stark's JARVIS. Designed for Windows 10/11 with local wake-word detection, safe computer automation tools, speech synthesis, and a futuristic holographic interface.

---

## Architecture Overview

JARVIS separates functionality into isolated, asynchronous components to maintain low CPU (< 1.5%) and RAM (< 85 MB) overhead:

```
+-------------------------------------------------------------------+
|                        JARVIS ARCHITECTURE                        |
+-------------------------------------------------------------------+
| 1. Wake-Word Engine  | Local listening ("Hey Jarvis")             |
|                      | Releases mic hardware when idle.           |
+----------------------+--------------------------------------------+
| 2. Speech-to-Text    | Captures spoken command upon wake word     |
|                      | or Push-to-Talk [Enter / Space].           |
+----------------------+--------------------------------------------+
| 3. Security Router   | Enforces LOW, MEDIUM, and HIGH risk rules. |
|                      | Whitelists applications and URLs.          |
+----------------------+--------------------------------------------+
| 4. AI Reasoning      | Zero-latency local regex matcher + Gemini  |
|                      | function calling for complex commands.     |
+----------------------+--------------------------------------------+
| 5. Tool Automation   | Direct safe OS automation via Windows API, |
|                      | PyAutoGUI, pycaw, and webbrowser.          |
+----------------------+--------------------------------------------+
| 6. Text-to-Speech    | Zero-latency local SAPI5 British voice.    |
+----------------------+--------------------------------------------+
| 7. HUD Interface     | Holographic glowing arc reactor dashboard. |
+-------------------------------------------------------------------+
```

---

## Core Voice Commands

| Spoken Voice Command | Interpreted Intent | Action Executed |
| :--- | :--- | :--- |
| `"Hey Jarvis, open YouTube"` | `open_url` | Opens default browser to `https://www.youtube.com` |
| `"Hey Jarvis, open Google Chrome"` | `open_application` | Launches Chrome browser |
| `"Hey Jarvis, open Notepad"` | `open_application` | Launches Notepad |
| `"Hey Jarvis, search Google for Python tutorials"` | `search_web` | Searches Google for query |
| `"Hey Jarvis, play music on YouTube"` | `search_web` | Opens YouTube search for music |
| `"Hey Jarvis, take a screenshot"` | `take_screenshot` | Saves screenshot to `Pictures/Screenshots` |
| `"Hey Jarvis, increase the volume"` | `set_system_volume` | Adjusts master volume level |
| `"Hey Jarvis, mute the computer"` | `mute_audio` | Mutes master audio output |
| `"Hey Jarvis, what time is it?"` | `get_current_time` | Speaks current local time & date aloud |
| `"Hey Jarvis, open my Downloads folder"` | `open_folder` | Opens user Downloads folder in Explorer |

---

## Windows Installation Instructions

### Prerequisites
- **Windows 10 or Windows 11** (64-bit recommended)
- **Python 3.10 to 3.12** installed with "Add Python to PATH" checked
- Working microphone and speakers

### Step-by-Step Setup
1. **Clone or Extract the Project:**
   ```powershell
   git clone <repo-url>
   cd jarvis-desktop-assistant
   ```

2. **Create a Virtual Environment:**
   ```powershell
   python -m venv venv
   .\venv\Scripts\Activate.ps1
   ```

3. **Install Dependencies:**
   ```powershell
   pip install --upgrade pip
   pip install -r requirements.txt
   ```
   *(Note: If `PyAudio` fails on Windows, install `pip install pipwin && pipwin install pyaudio`)*

4. **Configure Environment:**
   ```powershell
   copy .env.example .env
   ```
   Provide your Gemini API key in `.env` if cloud function calling is desired. Fast local pattern matching works out-of-the-box without an API key!

---

## Running in Development Mode

Run the main background engine with system tray integration:
```powershell
python jarvis/main.py
```

### Controls in Terminal:
- Say **"Hey Jarvis"** into your microphone
- Press **[Enter]** at any time for **Push-to-Talk**
- Type commands directly (e.g. `open youtube` or `take a screenshot`)
- Type `exit` to cleanly quit

---

## Building an Executable (.EXE)

To bundle JARVIS into a standalone Windows application that starts minimized to the system tray:
```powershell
# Using the automated build script:
.\build_exe.bat

# Or run PyInstaller manually:
pyinstaller --noconfirm --onedir --windowed --name "JARVIS" jarvis/main.py
```
The resulting executable will be created in `dist/JARVIS/JARVIS.exe`.

---

## Security & Permission Model

JARVIS divides all computer control actions into strict security tiers:

### Low Risk (Automatic Execution)
- Open applications (`notepad`, `chrome`, `calc`, etc.)
- Open whitelisted websites & web searches
- Adjust master volume or mute audio
- Take screenshots and save to `Pictures/Screenshots`
- Read system telemetry (CPU, RAM, time)

### Medium Risk (Policy Governed)
- Typing text into active windows
- Mouse movements and clicks
- File search within user directories

### High Risk (Explicit Confirmation Required)
- Permanent file deletion
- Terminal shell command execution
- Modifying security settings

Whenever a HIGH RISK action is detected, JARVIS pauses and asks:
> *"Are you sure you want me to do this?"*
Execution will not proceed until explicit user confirmation is granted.

---

## Troubleshooting Guide

1. **Microphone Not Detected:**
   - Verify Windows Settings > Privacy & Security > Microphone > Allow desktop apps to access your microphone.
2. **PyAudio Compilation Error on Windows:**
   - Run `pip install pipwin` followed by `pipwin install pyaudio`, or download the pre-compiled `.whl` from Gohlke's unofficial binaries.
3. **No Audio Output from TTS:**
   - Make sure Windows SAPI5 voice engine is active. `pyttsx3` will automatically fall back to console text if audio devices are disabled.
4. **Volume Adjustment Permissions:**
   - On Windows, `pycaw` requires standard user permissions. Running as Administrator is **never** required.
